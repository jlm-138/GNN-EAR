"""
图构建和处理工具
包含k-NN图构建、邻接矩阵归一化等功能
"""

import numpy as np
import torch
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances
from typing import Tuple


def build_knn_graph(features: np.ndarray, k: int = 5,
                    metric: str = 'cosine') -> Tuple[np.ndarray, torch.Tensor]:
    """
    使用k-NN构建图的邻接矩阵

    Args:
        features: 特征矩阵 [N, F]
        k: 近邻数量
        metric: 距离度量方式 ('cosine' 或 'euclidean')

    Returns:
        adj_matrix: 邻接矩阵 [N, N]
        edge_index: PyG格式的边索引 [2, E]
    """
    n_samples = features.shape[0]

    # 使用sklearn的NearestNeighbors直接找k近邻
    if metric == 'cosine':
        knn = NearestNeighbors(n_neighbors=k+1, metric='cosine')
    else:
        knn = NearestNeighbors(n_neighbors=k+1, metric='euclidean')

    knn.fit(features)
    neighbor_indices = knn.kneighbors(features, return_distance=False)

    # 构建邻接矩阵（对称）
    adj_matrix = np.zeros((n_samples, n_samples))
    for i in range(n_samples):
        for j in neighbor_indices[i][1:]:  # 跳过第一个（自己）
            adj_matrix[i, j] = 1
            adj_matrix[j, i] = 1  # 对称

    # 转换为PyG的edge_index格式
    edge_index = np.array(np.where(adj_matrix > 0))
    edge_index = torch.tensor(edge_index, dtype=torch.long)

    return adj_matrix, edge_index


def normalize_adjacency(adj_matrix: np.ndarray) -> np.ndarray:
    """
    对邻接矩阵进行对称归一化: D^{-1/2} A D^{-1/2}

    Args:
        adj_matrix: 邻接矩阵

    Returns:
        norm_adj: 归一化后的邻接矩阵
    """
    # 添加自环
    adj_with_self_loops = adj_matrix + np.eye(adj_matrix.shape[0])

    # 计算度矩阵
    degrees = np.sum(adj_with_self_loops, axis=1)

    # D^{-1/2}
    d_inv_sqrt = np.power(degrees, -0.5)
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
    d_matrix_inv_sqrt = np.diag(d_inv_sqrt)

    # D^{-1/2} A D^{-1/2}
    norm_adj = d_matrix_inv_sqrt @ adj_with_self_loops @ d_matrix_inv_sqrt

    return norm_adj

