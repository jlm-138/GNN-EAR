"""
通用工具函数
包含随机种子设置和结果保存等功能
"""

import numpy as np
import torch
import pandas as pd
from typing import Dict


def set_seed(seed: int):
    """
    设置随机种子以保证实验可重复性

    Args:
        seed: 随机种子值
    """
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def save_results(results: Dict, save_path: str):
    """
    保存实验结果到CSV文件

    Args:
        results: 结果字典
        save_path: 保存路径
    """
    df = pd.DataFrame([results])
    df.to_csv(save_path, index=False)
    print(f"结果已保存至: {save_path}")

