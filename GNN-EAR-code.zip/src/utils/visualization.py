"""
可视化工具
包含嵌入空间和图结构的可视化功能
"""

import numpy as np
import networkx as nx
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


def visualize_embeddings(embeddings: np.ndarray, labels: np.ndarray,
                         title: str = "Embedding Visualization",
                         save_path: str = None):
    """
    使用t-SNE可视化嵌入空间

    Args:
        embeddings: 嵌入向量 [N, D]
        labels: 标签 [N]
        title: 图标题
        save_path: 保存路径（可选）
    """
    # t-SNE降维
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    embeddings_2d = tsne.fit_transform(embeddings)

    # 绘图
    plt.figure(figsize=(10, 8))
    unique_labels = np.unique(labels)
    colors = plt.cm.rainbow(np.linspace(0, 1, len(unique_labels)))

    for label, color in zip(unique_labels, colors):
        mask = labels == label
        plt.scatter(embeddings_2d[mask, 0], embeddings_2d[mask, 1],
                   c=[color], label=f'Class {label}', alpha=0.6, s=30)

    plt.title(title, fontsize=14)
    plt.xlabel('t-SNE Dimension 1')
    plt.ylabel('t-SNE Dimension 2')
    plt.legend()
    plt.grid(True, alpha=0.3)

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()


def visualize_graph_structure(adj_matrix: np.ndarray, labels: np.ndarray,
                               max_nodes: int = 200,
                               save_path: str = None):
    """
    可视化图结构

    Args:
        adj_matrix: 邻接矩阵
        labels: 节点标签
        max_nodes: 最大显示节点数（避免图太复杂）
        save_path: 保存路径（可选）
    """
    # 如果节点太多，只显示一部分
    if adj_matrix.shape[0] > max_nodes:
        indices = np.random.choice(adj_matrix.shape[0], max_nodes, replace=False)
        adj_matrix = adj_matrix[np.ix_(indices, indices)]
        labels = labels[indices]

    # 创建NetworkX图
    G = nx.from_numpy_array(adj_matrix)

    # 布局
    pos = nx.spring_layout(G, k=0.5, iterations=50)

    # 绘图
    plt.figure(figsize=(12, 10))
    unique_labels = np.unique(labels)
    colors = plt.cm.rainbow(np.linspace(0, 1, len(unique_labels)))

    for label, color in zip(unique_labels, colors):
        node_list = [i for i, l in enumerate(labels) if l == label]
        nx.draw_networkx_nodes(G, pos, nodelist=node_list,
                              node_color=[color], label=f'Class {label}',
                              node_size=100, alpha=0.7)

    nx.draw_networkx_edges(G, pos, alpha=0.2, width=0.5)

    plt.title("Graph Structure Visualization", fontsize=14)
    plt.legend()
    plt.axis('off')

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()

