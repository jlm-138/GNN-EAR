"""
数据处理工具
包含数据集创建、划分、统计等功能
"""

import numpy as np
import torch
import pandas as pd
from typing import Tuple


def create_imbalanced_dataset(features: np.ndarray, labels: np.ndarray,
                              minority_class: int,
                              imbalance_ratio: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    创建不平衡数据集

    Args:
        features: 原始特征
        labels: 原始标签
        minority_class: 少数类标签
        imbalance_ratio: 少数类占比

    Returns:
        imb_features: 不平衡特征
        imb_labels: 不平衡标签
        imb_indices: 保留的样本索引
    """
    minority_indices = np.where(labels == minority_class)[0]
    majority_indices = np.where(labels != minority_class)[0]

    # 计算要保留的少数类样本数量
    n_minority_keep = int(len(minority_indices) * imbalance_ratio)
    n_majority = len(majority_indices)

    # 随机选择少数类样本
    selected_minority = np.random.choice(minority_indices, n_minority_keep, replace=False)

    # 合并索引
    imb_indices = np.concatenate([selected_minority, majority_indices])
    np.random.shuffle(imb_indices)

    imb_features = features[imb_indices]
    imb_labels = labels[imb_indices]

    return imb_features, imb_labels, imb_indices


def split_data(n_samples: int, train_ratio: float = 0.7,
               val_ratio: float = 0.1, test_ratio: float = 0.2,
               random_state: int = 42) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    划分训练集、验证集和测试集

    Args:
        n_samples: 样本总数
        train_ratio: 训练集比例
        val_ratio: 验证集比例
        test_ratio: 测试集比例
        random_state: 随机种子

    Returns:
        train_mask: 训练集掩码
        val_mask: 验证集掩码
        test_mask: 测试集掩码
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "比例之和必须为1"

    indices = np.arange(n_samples)
    np.random.seed(random_state)
    np.random.shuffle(indices)

    train_end = int(n_samples * train_ratio)
    val_end = train_end + int(n_samples * val_ratio)

    train_mask = np.zeros(n_samples, dtype=bool)
    val_mask = np.zeros(n_samples, dtype=bool)
    test_mask = np.zeros(n_samples, dtype=bool)

    train_mask[indices[:train_end]] = True
    val_mask[indices[train_end:val_end]] = True
    test_mask[indices[val_end:]] = True

    return train_mask, val_mask, test_mask


def compute_class_weights(labels: np.ndarray) -> torch.Tensor:
    """
    计算类别权重（用于处理不平衡）

    Args:
        labels: 标签数组

    Returns:
        class_weights: 类别权重张量
    """
    unique_labels, counts = np.unique(labels, return_counts=True)
    total = len(labels)

    # 反比例权重
    weights = total / (len(unique_labels) * counts)

    class_weights = torch.zeros(len(unique_labels))
    for i, label in enumerate(unique_labels):
        class_weights[int(label)] = weights[i]

    return class_weights


def print_dataset_statistics(features: np.ndarray, labels: np.ndarray,
                             adj_matrix: np.ndarray = None):
    """
    打印数据集统计信息

    Args:
        features: 特征矩阵
        labels: 标签
        adj_matrix: 邻接矩阵（可选）
    """
    print("\n" + "=" * 60)
    print("数据集统计信息")
    print("=" * 60)
    print(f"节点数量: {features.shape[0]}")
    print(f"特征维度: {features.shape[1]}")

    unique_labels, counts = np.unique(labels, return_counts=True)
    print(f"类别数量: {len(unique_labels)}")
    print("\n类别分布:")
    for label, count in zip(unique_labels, counts):
        ratio = count / len(labels) * 100
        print(f"  类别 {int(label)}: {count} 样本 ({ratio:.2f}%)")

    # 计算不平衡率
    if len(counts) > 1:
        ir = counts.max() / counts.min()
        print(f"\n不平衡率 (IR): {ir:.2f}")

    if adj_matrix is not None:
        n_edges = np.sum(adj_matrix) / 2  # 无向图
        avg_degree = np.mean(np.sum(adj_matrix, axis=1))
        print(f"\n边数量: {int(n_edges)}")
        print(f"平均度: {avg_degree:.2f}")

    print("=" * 60 + "\n")


def load_data_from_csv(file_path: str, label_col: str = 'label') -> Tuple[np.ndarray, np.ndarray]:
    """
    从CSV文件加载数据

    Args:
        file_path: CSV文件路径
        label_col: 标签列名

    Returns:
        features: 特征矩阵
        labels: 标签数组
    """
    df = pd.read_csv(file_path)

    # 分离特征和标签
    labels = df[label_col].values
    features = df.drop(columns=[label_col]).values

    return features, labels

