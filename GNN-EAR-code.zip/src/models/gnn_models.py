"""
GNN模型模块
包含GCN、GAT等图神经网络编码器
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, GATConv, SAGEConv
from typing import Optional


class GCNEncoder(nn.Module):
    """GCN编码器"""

    def __init__(self, in_dim: int, hidden_dim: int, embedding_dim: int,
                 num_layers: int = 2, dropout: float = 0.5):
        """
        初始化GCN编码器

        Args:
            in_dim: 输入特征维度
            hidden_dim: 隐藏层维度
            embedding_dim: 嵌入维度
            num_layers: GCN层数
            dropout: Dropout率
        """
        super(GCNEncoder, self).__init__()

        self.num_layers = num_layers
        self.dropout = dropout

        # 构建GCN层
        self.convs = nn.ModuleList()

        # 第一层
        self.convs.append(GCNConv(in_dim, hidden_dim))

        # 中间层
        for _ in range(num_layers - 2):
            self.convs.append(GCNConv(hidden_dim, hidden_dim))

        # 最后一层
        if num_layers > 1:
            self.convs.append(GCNConv(hidden_dim, embedding_dim))
        else:
            self.convs[0] = GCNConv(in_dim, embedding_dim)

        # Batch Normalization
        self.bns = nn.ModuleList([
            nn.BatchNorm1d(hidden_dim if i < num_layers - 1 else embedding_dim)
            for i in range(num_layers)
        ])

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            x: 节点特征 [N, in_dim]
            edge_index: 边索引 [2, E]

        Returns:
            embeddings: 节点嵌入 [N, embedding_dim]
        """
        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)
            x = self.bns[i](x)

            if i < len(self.convs) - 1:
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)

        return x


class GATEncoder(nn.Module):
    """GAT (Graph Attention Network) 编码器"""

    def __init__(self, in_dim: int, hidden_dim: int, embedding_dim: int,
                 num_layers: int = 2, num_heads: int = 4, dropout: float = 0.5):
        """
        初始化GAT编码器

        Args:
            in_dim: 输入特征维度
            hidden_dim: 隐藏层维度
            embedding_dim: 嵌入维度
            num_layers: GAT层数
            num_heads: 注意力头数
            dropout: Dropout率
        """
        super(GATEncoder, self).__init__()

        self.num_layers = num_layers
        self.dropout = dropout

        self.convs = nn.ModuleList()

        # 第一层
        self.convs.append(GATConv(in_dim, hidden_dim, heads=num_heads, dropout=dropout))

        # 中间层
        for _ in range(num_layers - 2):
            self.convs.append(GATConv(hidden_dim * num_heads, hidden_dim,
                                     heads=num_heads, dropout=dropout))

        # 最后一层（单头输出）
        if num_layers > 1:
            self.convs.append(GATConv(hidden_dim * num_heads, embedding_dim,
                                     heads=1, concat=False, dropout=dropout))
        else:
            self.convs[0] = GATConv(in_dim, embedding_dim, heads=1,
                                   concat=False, dropout=dropout)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            x: 节点特征 [N, in_dim]
            edge_index: 边索引 [2, E]

        Returns:
            embeddings: 节点嵌入 [N, embedding_dim]
        """
        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)

            if i < len(self.convs) - 1:
                x = F.elu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)

        return x


class GraphSAGEEncoder(nn.Module):
    """GraphSAGE编码器"""

    def __init__(self, in_dim: int, hidden_dim: int, embedding_dim: int,
                 num_layers: int = 2, dropout: float = 0.5):
        """
        初始化GraphSAGE编码器

        Args:
            in_dim: 输入特征维度
            hidden_dim: 隐藏层维度
            embedding_dim: 嵌入维度
            num_layers: SAGE层数
            dropout: Dropout率
        """
        super(GraphSAGEEncoder, self).__init__()

        self.num_layers = num_layers
        self.dropout = dropout

        self.convs = nn.ModuleList()

        # 第一层
        self.convs.append(SAGEConv(in_dim, hidden_dim))

        # 中间层
        for _ in range(num_layers - 2):
            self.convs.append(SAGEConv(hidden_dim, hidden_dim))

        # 最后一层
        if num_layers > 1:
            self.convs.append(SAGEConv(hidden_dim, embedding_dim))
        else:
            self.convs[0] = SAGEConv(in_dim, embedding_dim)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            x: 节点特征 [N, in_dim]
            edge_index: 边索引 [2, E]

        Returns:
            embeddings: 节点嵌入 [N, embedding_dim]
        """
        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)

            if i < len(self.convs) - 1:
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)

        return x


class MLPDecoder(nn.Module):
    """MLP解码器：将嵌入映射回特征空间"""

    def __init__(self, embedding_dim: int, hidden_dim: int, output_dim: int,
                 num_layers: int = 2, dropout: float = 0.5):
        """
        初始化MLP解码器

        Args:
            embedding_dim: 嵌入维度
            hidden_dim: 隐藏层维度
            output_dim: 输出特征维度
            num_layers: MLP层数
            dropout: Dropout率
        """
        super(MLPDecoder, self).__init__()

        self.num_layers = num_layers
        self.dropout = dropout

        self.layers = nn.ModuleList()

        # 第一层
        self.layers.append(nn.Linear(embedding_dim, hidden_dim))

        # 中间层
        for _ in range(num_layers - 2):
            self.layers.append(nn.Linear(hidden_dim, hidden_dim))

        # 输出层
        if num_layers > 1:
            self.layers.append(nn.Linear(hidden_dim, output_dim))
        else:
            self.layers[0] = nn.Linear(embedding_dim, output_dim)

    def forward(self, embeddings: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            embeddings: 节点嵌入 [N, embedding_dim]

        Returns:
            features: 重构的特征 [N, output_dim]
        """
        x = embeddings

        for i, layer in enumerate(self.layers):
            x = layer(x)

            if i < len(self.layers) - 1:
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)

        return x


class Classifier(nn.Module):
    """分类器"""

    def __init__(self, embedding_dim: int, num_classes: int, hidden_dim: Optional[int] = None):
        """
        初始化分类器

        Args:
            embedding_dim: 嵌入维度
            num_classes: 类别数
            hidden_dim: 隐藏层维度（可选）
        """
        super(Classifier, self).__init__()

        if hidden_dim is not None:
            self.fc1 = nn.Linear(embedding_dim, hidden_dim)
            self.fc2 = nn.Linear(hidden_dim, num_classes)
            self.use_hidden = True
        else:
            self.fc = nn.Linear(embedding_dim, num_classes)
            self.use_hidden = False

    def forward(self, embeddings: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            embeddings: 节点嵌入 [N, embedding_dim]

        Returns:
            logits: 分类logits [N, num_classes]
        """
        if self.use_hidden:
            x = F.relu(self.fc1(embeddings))
            x = self.fc2(x)
        else:
            x = self.fc(embeddings)

        return x


class EdgePredictor(nn.Module):
    """边预测器：预测新生成节点的边"""

    def __init__(self, embedding_dim: int, hidden_dim: int = 64):
        """
        初始化边预测器

        Args:
            embedding_dim: 嵌入维度
            hidden_dim: 隐藏层维度
        """
        super(EdgePredictor, self).__init__()

        # 使用双线性层预测边
        self.fc1 = nn.Linear(embedding_dim * 2, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, 1)

    def forward(self, src_embeddings: torch.Tensor,
                dst_embeddings: torch.Tensor) -> torch.Tensor:
        """
        前向传播

        Args:
            src_embeddings: 源节点嵌入 [N_src, embedding_dim]
            dst_embeddings: 目标节点嵌入 [N_dst, embedding_dim]

        Returns:
            edge_probs: 边存在概率 [N_src, N_dst]
        """
        # 计算所有节点对的拼接
        n_src = src_embeddings.size(0)
        n_dst = dst_embeddings.size(0)

        # 扩展维度
        src_expanded = src_embeddings.unsqueeze(1).expand(n_src, n_dst, -1)
        dst_expanded = dst_embeddings.unsqueeze(0).expand(n_src, n_dst, -1)

        # 拼接
        pairs = torch.cat([src_expanded, dst_expanded], dim=-1)  # [N_src, N_dst, 2*embedding_dim]

        # 预测
        x = F.relu(self.fc1(pairs))
        edge_logits = self.fc2(x).squeeze(-1)  # [N_src, N_dst]
        edge_probs = torch.sigmoid(edge_logits)

        return edge_probs


def build_encoder(gnn_type: str, in_dim: int, hidden_dim: int, embedding_dim: int,
                  num_layers: int = 2, num_heads: int = 4, dropout: float = 0.5):
    """
    构建GNN编码器的工厂函数

    Args:
        gnn_type: GNN类型 ('GCN', 'GAT', 'GraphSAGE')
        in_dim: 输入维度
        hidden_dim: 隐藏层维度
        embedding_dim: 嵌入维度
        num_layers: 层数
        num_heads: 注意力头数（仅GAT）
        dropout: Dropout率

    Returns:
        encoder: GNN编码器
    """
    if gnn_type.upper() == 'GCN':
        return GCNEncoder(in_dim, hidden_dim, embedding_dim, num_layers, dropout)
    elif gnn_type.upper() == 'GAT':
        return GATEncoder(in_dim, hidden_dim, embedding_dim, num_layers, num_heads, dropout)
    elif gnn_type.upper() == 'GRAPHSAGE':
        return GraphSAGEEncoder(in_dim, hidden_dim, embedding_dim, num_layers, dropout)
    else:
        raise ValueError(f"未知的GNN类型: {gnn_type}")

