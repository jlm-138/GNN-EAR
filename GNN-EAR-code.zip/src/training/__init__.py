"""
训练模块
包含训练器和评估工具
"""

from .trainer import Trainer

__all__ = [
    'Trainer'
]

