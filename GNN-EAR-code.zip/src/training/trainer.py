"""
训练器模块
负责模型训练、验证和测试
"""

import torch
import torch.optim as optim
import numpy as np
from tqdm import tqdm
from typing import Dict, Tuple
import os
from sklearn.metrics import f1_score, roc_auc_score, precision_score, recall_score, confusion_matrix


class Trainer:
    """训练器类"""

    def __init__(self, model, rule_loss_fn, combined_loss_fn, device: str = 'cuda'):
        """
        初始化训练器

        Args:
            model: RG-GraphSMOTE模型
            rule_loss_fn: 规则损失函数
            combined_loss_fn: 组合损失函数（已包含类别权重）
            device: 计算设备
        """
        self.model = model.to(device)
        self.rule_loss_fn = rule_loss_fn
        self.combined_loss_fn = combined_loss_fn
        self.device = device

        self.optimizer = None
        self.best_val_f1 = 0.0
        self.patience_counter = 0

    def setup_optimizer(self, learning_rate: float = 0.001, weight_decay: float = 5e-4):
        """
        设置优化器

        Args:
            learning_rate: 学习率
            weight_decay: 权重衰减
        """
        self.optimizer = optim.Adam(self.model.parameters(),
                                   lr=learning_rate,
                                   weight_decay=weight_decay)

    def train_epoch(self, x: torch.Tensor, edge_index: torch.Tensor,
                   labels: torch.Tensor, train_mask: torch.Tensor,
                   minority_class: int, num_synthetic: int = 0) -> Dict:
        """
        训练一个epoch

        Args:
            x: 节点特征
            edge_index: 边索引
            labels: 标签
            train_mask: 训练掩码
            minority_class: 少数类标签
            num_synthetic: 每个epoch生成的合成样本数

        Returns:
            metrics: 训练指标字典
        """
        self.model.train()

        # 前向传播
        logits_all, x_syn, h_syn, edge_probs = self.model(
            x, edge_index, labels, minority_class, num_synthetic
        )

        # 准备标签（包含合成样本）
        if num_synthetic > 0:
            labels_syn = torch.full((num_synthetic,), minority_class,
                                   dtype=labels.dtype, device=self.device)
            labels_extended = torch.cat([labels, labels_syn], dim=0)

            # 扩展训练掩码
            train_mask_extended = torch.cat([
                train_mask,
                torch.ones(num_synthetic, dtype=torch.bool, device=self.device)
            ], dim=0)
        else:
            labels_extended = labels
            train_mask_extended = train_mask

        # 选择训练样本
        logits_train = logits_all[train_mask_extended]
        labels_train = labels_extended[train_mask_extended]

        # 计算规则损失
        if x_syn is not None and self.rule_loss_fn is not None:
            rule_loss = self.rule_loss_fn(x_syn)
        else:
            rule_loss = None

        # 计算边损失（简化：假设合成节点应该连接到少数类节点）
        edge_loss = None
        if edge_probs is not None:
            # 创建目标边（连接到少数类）
            minority_mask = (labels == minority_class)
            target_edges = minority_mask.float().unsqueeze(0).expand(num_synthetic, -1)
            edge_loss = torch.nn.functional.binary_cross_entropy(edge_probs, target_edges)

        # 重构损失（合成样本应接近原始少数类样本）
        x_minority = x[labels == minority_class]

        # 计算总损失
        total_loss, loss_dict = self.combined_loss_fn(
            logits_train, labels_train, x_syn, x_minority, rule_loss, edge_loss
        )

        # 反向传播
        self.optimizer.zero_grad()
        total_loss.backward()
        self.optimizer.step()

        # 计算准确率
        with torch.no_grad():
            preds = logits_train.argmax(dim=1)
            acc = (preds == labels_train).float().mean().item()

        loss_dict['acc'] = acc

        return loss_dict

    @torch.no_grad()
    def evaluate(self, x: torch.Tensor, edge_index: torch.Tensor,
                labels: torch.Tensor, mask: torch.Tensor,
                minority_class: int) -> Dict:
        """
        评估模型

        Args:
            x: 节点特征
            edge_index: 边索引
            labels: 标签
            mask: 评估掩码
            minority_class: 少数类标签

        Returns:
            metrics: 评估指标字典
        """
        self.model.eval()

        # 前向传播（不生成合成样本）
        logits, _, _, _ = self.model(x, edge_index, labels, minority_class, num_synthetic=0)

        # 选择评估样本
        logits_eval = logits[mask]
        labels_eval = labels[mask]

        # 预测
        preds = logits_eval.argmax(dim=1)
        probs = torch.softmax(logits_eval, dim=1)

        # 转换为numpy
        preds_np = preds.cpu().numpy()
        labels_np = labels_eval.cpu().numpy()
        probs_np = probs.cpu().numpy()

        # 计算指标
        acc = (preds_np == labels_np).mean()

        # F1 scores
        f1_macro = f1_score(labels_np, preds_np, average='macro', zero_division=0)
        f1_micro = f1_score(labels_np, preds_np, average='micro', zero_division=0)
        f1_minority = f1_score(labels_np, preds_np, labels=[minority_class],
                              average='macro', zero_division=0)

        # Precision and Recall
        precision = precision_score(labels_np, preds_np, average='macro', zero_division=0)
        recall = recall_score(labels_np, preds_np, average='macro', zero_division=0)

        # AUC (if binary)
        num_classes = probs_np.shape[1]
        if num_classes == 2:
            try:
                auc = roc_auc_score(labels_np, probs_np[:, 1])
            except:
                auc = 0.0
        else:
            try:
                auc = roc_auc_score(labels_np, probs_np, multi_class='ovr', average='macro')
            except:
                auc = 0.0

        # Confusion Matrix
        cm = confusion_matrix(labels_np, preds_np)

        metrics = {
            'acc': acc,
            'f1_macro': f1_macro,
            'f1_micro': f1_micro,
            'f1_minority': f1_minority,
            'precision': precision,
            'recall': recall,
            'auc': auc,
            'confusion_matrix': cm
        }

        return metrics

    def train(self, x: torch.Tensor, edge_index: torch.Tensor,
             labels: torch.Tensor, train_mask: torch.Tensor,
             val_mask: torch.Tensor, minority_class: int,
             num_epochs: int = 200, num_synthetic: int = 100,
             patience: int = 20, log_interval: int = 10,
             save_path: str = None) -> Dict:
        """
        完整训练流程

        Args:
            x: 节点特征
            edge_index: 边索引
            labels: 标签
            train_mask: 训练掩码
            val_mask: 验证掩码
            minority_class: 少数类标签
            num_epochs: 训练轮数
            num_synthetic: 每轮生成的合成样本数
            patience: 早停耐心值
            log_interval: 日志打印间隔
            save_path: 模型保存路径

        Returns:
            history: 训练历史
        """
        print("\n" + "=" * 60)
        print("开始训练 RG-GraphSMOTE")
        print("=" * 60)

        history = {
            'train_loss': [],
            'train_acc': [],
            'val_f1_macro': [],
            'val_f1_minority': [],
            'best_epoch': 0
        }

        for epoch in range(num_epochs):
            # 训练
            train_metrics = self.train_epoch(
                x, edge_index, labels, train_mask, minority_class, num_synthetic
            )

            # 验证
            val_metrics = self.evaluate(x, edge_index, labels, val_mask, minority_class)

            # 记录历史
            history['train_loss'].append(train_metrics['total'])
            history['train_acc'].append(train_metrics['acc'])
            history['val_f1_macro'].append(val_metrics['f1_macro'])
            history['val_f1_minority'].append(val_metrics['f1_minority'])

            # 打印日志
            if (epoch + 1) % log_interval == 0:
                print(f"Epoch {epoch+1}/{num_epochs} | "
                      f"Loss: {train_metrics['total']:.4f} | "
                      f"Train Acc: {train_metrics['acc']:.4f} | "
                      f"Val F1-Macro: {val_metrics['f1_macro']:.4f} | "
                      f"Val F1-Minority: {val_metrics['f1_minority']:.4f}")

            # 早停检查
            if val_metrics['f1_macro'] > self.best_val_f1:
                self.best_val_f1 = val_metrics['f1_macro']
                self.patience_counter = 0
                history['best_epoch'] = epoch + 1  # 记录最佳epoch

                # 保存最佳模型
                if save_path:
                    self.save_model(save_path)
            else:
                self.patience_counter += 1

            if self.patience_counter >= patience:
                print(f"\n早停触发 (Patience={patience})")
                break

        print(f"\n训练完成！最佳验证F1: {self.best_val_f1:.4f}")
        print("=" * 60 + "\n")

        return history

    def save_model(self, path: str):
        """保存模型"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'best_val_f1': self.best_val_f1
        }, path)
        print(f">> 模型已保存至: {path}")

    def load_model(self, path: str):
        """加载模型"""
        checkpoint = torch.load(path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        if self.optimizer:
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.best_val_f1 = checkpoint['best_val_f1']
        print(f">> 模型已加载: {path}")

    def get_embeddings(self, x: torch.Tensor, edge_index: torch.Tensor) -> np.ndarray:
        """
        获取节点嵌入（用于可视化）

        Args:
            x: 节点特征
            edge_index: 边索引

        Returns:
            embeddings: 节点嵌入
        """
        self.model.eval()
        with torch.no_grad():
            embeddings = self.model.encoder(x, edge_index)
        return embeddings.cpu().numpy()

    def get_predictions(self, x: torch.Tensor, edge_index: torch.Tensor,
                       labels: torch.Tensor, minority_class: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        获取预测结果

        Args:
            x: 节点特征
            edge_index: 边索引
            labels: 标签（用于确定少数类）
            minority_class: 少数类标签

        Returns:
            preds: 预测标签
            probs: 预测概率
        """
        self.model.eval()
        with torch.no_grad():
            logits, _, _, _ = self.model(x, edge_index, labels, minority_class, num_synthetic=0)
            preds = logits.argmax(dim=1)
            probs = torch.softmax(logits, dim=1)

        return preds.cpu().numpy(), probs.cpu().numpy()

