"""
GNN-EAR
"""


