"""
数据加载模块
支持加载Cora, Citeseer, Pubmed等数据集，以及自定义CSV数据
"""

import torch
import numpy as np
import pandas as pd
from typing import Tuple, Optional
import os
from torch_geometric.datasets import Planetoid
from torch_geometric.utils import to_dense_adj
from ..utils import build_knn_graph, create_imbalanced_dataset, print_dataset_statistics
import pickle


class DataLoader:
    """数据加载器"""

    def __init__(self, dataset_name: str = 'cora', data_path: str = './data/', graph_metric: str = 'cosine'):
        """
        初始化数据加载器

        Args:
            dataset_name: 数据集名称
            data_path: 数据路径
        """
        alias_map = {
            'new-thyroid2': 'newthyroid2',
        }
        normalized_name = dataset_name.lower()
        self.dataset_name = alias_map.get(normalized_name, normalized_name)
        resolved_data_path = os.path.abspath(data_path)
        if not os.path.exists(resolved_data_path):
            project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
            normalized_rel = data_path.replace('\\', os.sep).replace('/', os.sep).lstrip('.\\/')
            candidate = os.path.abspath(os.path.join(project_root, normalized_rel))
            if os.path.exists(candidate):
                resolved_data_path = candidate
        self.data_path = resolved_data_path
        self.graph_metric = graph_metric
        self._pickle_cache = {}

    def load_csv_dataset(self, file_path: str, label_col: str = 'label',
                        k: int = 5, metric: str = 'cosine') -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        从CSV文件加载数据并构建图

        Args:
            file_path: CSV文件路径
            label_col: 标签列名
            k: k-NN的k值
            metric: 距离度量

        Returns:
            features: 特征矩阵
            labels: 标签数组
            adj_matrix: 邻接矩阵
        """
        print(f"\n从CSV加载数据: {file_path}")

        # 读取CSV
        df = pd.read_csv(file_path)

        # 分离特征和标签
        if label_col not in df.columns:
            raise ValueError(f"标签列 '{label_col}' 不存在于数据中")

        labels = df[label_col].values
        features = df.drop(columns=[label_col]).values

        print(f">> CSV数据加载完成")

        # 构建k-NN图
        print(f"\n使用k-NN (k={k}, metric={metric}) 构建图...")
        adj_matrix, _ = build_knn_graph(features, k=k, metric=metric)

        print(f">> 图构建完成")
        print_dataset_statistics(features, labels, adj_matrix)

        return features, labels, adj_matrix

    def _load_pickle_dataset(self, filename: str, knn_k: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        path = os.path.join(self.data_path, filename)
        print(f"\n加载{filename}数据集: {path}")
        if path in self._pickle_cache:
            data = self._pickle_cache[path]
        else:
            with open(path, 'rb') as f:
                data = pickle.load(f)
            self._pickle_cache[path] = data

        x = data['X'] if 'X' in data else data.get('features')
        y = data['y'] if 'y' in data else data.get('labels')
        if hasattr(x, 'values'):
            x = x.values
        if hasattr(y, 'values'):
            y = y.values
        features = np.asarray(x, dtype=np.float32)
        labels = np.asarray(y, dtype=np.int64)

        from sklearn.preprocessing import StandardScaler
        features = StandardScaler().fit_transform(features)
        adj_matrix, _ = build_knn_graph(features, k=knn_k, metric=self.graph_metric)

        print(f">> {filename} 数据加载完成")
        print_dataset_statistics(features, labels, adj_matrix)
        return features, labels, adj_matrix

    def _load_keel_dataset(self, filename: str, knn_k: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        加载KEEL格式数据集

        Args:
            filename: 数据文件名（.dat文件）
            knn_k: k-NN图构建参数

        Returns:
            features: 特征矩阵
            labels: 标签数组
            adj_matrix: 邻接矩阵
        """
        candidate_filenames = [filename]
        if 'new-thyroid2' in filename:
            candidate_filenames.append(filename.replace('new-thyroid2', 'newthyroid2'))
        if 'newthyroid2' in filename:
            candidate_filenames.append(filename.replace('newthyroid2', 'new-thyroid2'))

        candidate_paths = []
        for fn in candidate_filenames:
            candidate_paths.extend([
                os.path.join(self.data_path, 'keel', fn),
                os.path.join(self.data_path, 'keel1', fn),
                os.path.join(self.data_path, fn),
            ])

        path = next((p for p in candidate_paths if os.path.exists(p)), None)
        if path is None:
            searched = '\n'.join(f'  - {p}' for p in dict.fromkeys(candidate_paths))
            raise FileNotFoundError(f"找不到KEEL数据文件: {filename}\n已搜索路径:\n{searched}")

        print(f"\n加载KEEL数据集: {path}")

        data = []
        labels_list = []
        in_data_section = False

        with open(path, 'r') as f:
            for line in f:
                line = line.strip()

                # 检查是否到达数据部分
                if line.startswith('@data'):
                    in_data_section = True
                    continue

                # 跳过头部和空行
                if not in_data_section or not line or line.startswith('@'):
                    continue

                # 解析数据行
                parts = line.split(',')
                # 提取特征（除最后一个）
                features_row = [float(x.strip()) for x in parts[:-1]]
                # 提取标签（最后一个元素）
                label = parts[-1].strip()

                data.append(features_row)
                labels_list.append(label)

        # 转换为numpy数组
        features = np.array(data, dtype=np.float32)

        # 将标签转换为数值
        unique_labels = sorted(set(labels_list))
        if set(unique_labels) == {'positive', 'negative'} or set(unique_labels) == {'negative', 'positive'}:
            # 标准二分类KEEL格式: positive=1, negative=0
            label_map = {'positive': 1, 'negative': 0}
        else:
            # 其他标签格式: 自动分配数值编码
            label_map = {label: idx for idx, label in enumerate(unique_labels)}
        print(f"  标签映射: {label_map}")
        labels = np.array([label_map[label] for label in labels_list], dtype=np.int64)

        # 归一化特征
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        features = scaler.fit_transform(features)

        # 构建k-NN图
        print(f"使用k-NN (k={knn_k}) 构建图...")
        adj_matrix, _ = build_knn_graph(features, k=knn_k, metric=self.graph_metric)

        print(f">> KEEL数据加载完成")
        print_dataset_statistics(features, labels, adj_matrix)

        return features, labels, adj_matrix

    def load(self, imbalance_ratio: Optional[float] = None,
            minority_class: Optional[int] = None,
            csv_path: Optional[str] = None,
            label_col: str = 'label',
            knn_k: int = 5) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        统一加载接口

        Args:
            imbalance_ratio: 不平衡比例（可选）
            minority_class: 少数类标签（可选）
            csv_path: CSV文件路径（用于custom数据集）
            label_col: 标签列名
            knn_k: k-NN的k值

        Returns:
            features: 特征矩阵
            labels: 标签数组
            adj_matrix: 邻接矩阵
        """
        # 根据数据集类型加载

        if self.dataset_name == 'custom':
            if csv_path is None:
                raise ValueError("自定义数据集需要提供csv_path参数")
            features, labels, adj_matrix = self.load_csv_dataset(
                csv_path, label_col, knn_k
            )


        elif self.dataset_name == 'ecoli1':
            features, labels, adj_matrix = self._load_pickle_dataset('ecoli1.pkl', knn_k)

        # KEEL数据集支持
        # elif self.dataset_name in ['ecoli2', 'ecoli3', 'glass0', 'glass1', 'yeast1',
        #                             'yeast3', 'yeast4', 'yeast5', 'yeast6',
        #                             'abalone9-18', 'page-blocks0', 'pima', 'vehicle0']:
        elif self.dataset_name in ['balance', 'cleveland-0_vs_4', 'glass', 'glass0', 'haberman', 'hayes-roth', 'new-thyroid',
    'new-thyroid1', 'newthyroid2', 'page-blocks-1-3_vs_4', 'poker', 'segment0', 'shuttle-6_vs_2-3', 'vowel0', 'wine',
    'winequality-red-8_vs_6', 'winequality-white-3_vs_7', 'winequality-white-9_vs_4', 'wisconsin', 'pima', 'vehicle0',
    'yeast1', 'ecoli1', 'ecoli2', 'ecoli3']:
            features, labels, adj_matrix = self._load_keel_dataset(f'{self.dataset_name}.dat', knn_k)

        else:
            raise ValueError(f"不支持的数据集类型: {self.dataset_name}")

        # 创建不平衡数据集（如果指定）
        if imbalance_ratio is not None and minority_class is not None:
            print(f"\n创建不平衡数据集 (比例={imbalance_ratio}, 少数类={minority_class})...")

            features, labels, selected_indices = create_imbalanced_dataset(
                features, labels, minority_class, imbalance_ratio
            )

            # 更新邻接矩阵
            adj_matrix = adj_matrix[np.ix_(selected_indices, selected_indices)]

            print(f">> 不��衡数据集创建完成")
            print_dataset_statistics(features, labels, adj_matrix)

        return features, labels, adj_matrix

    def to_torch(self, features: np.ndarray, labels: np.ndarray,
                adj_matrix: np.ndarray, device: str = 'cuda') -> Tuple:
        """
        转换为PyTorch张量

        Args:
            features: 特征矩阵
            labels: 标签数组
            adj_matrix: 邻接矩阵
            device: 设备

        Returns:
            x: 特征张量
            y: 标签张量
            edge_index: 边索引张量
        """
        # 转换为张量
        x = torch.FloatTensor(features).to(device)
        y = torch.LongTensor(labels).to(device)

        # 邻接矩阵 -> 边索引
        edge_index = np.array(np.where(adj_matrix > 0))
        edge_index = torch.LongTensor(edge_index).to(device)

        return x, y, edge_index


def load_segment0_data(data_path: str = './datas/segment0.dat',
                      k: int = 5) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    加载KEEL Segment0数据集

    Args:
        data_path: 数据文件路径
        k: k-NN的k值

    Returns:
        features: 特征矩阵
        labels: 标签数组
        adj_matrix: 邻接矩阵
    """
    print(f"\n加载Segment0数据集: {data_path}")

    # 读取KEEL格式数据文件
    data = []
    labels_list = []
    in_data_section = False

    with open(data_path, 'r') as f:
        for line in f:
            line = line.strip()

            # 检查是否到达数据部分
            if line.startswith('@data'):
                in_data_section = True
                continue

            # 跳过头部和空行
            if not in_data_section or not line or line.startswith('@'):
                continue

            # 解析数据行
            parts = line.split(',')
            # 提取特征（除最后一个）
            features_row = [float(x.strip()) for x in parts[:-1]]
            # 提取标签（最后一个元素）
            label = parts[-1].strip()

            data.append(features_row)
            labels_list.append(label)

    # 转换为numpy数组
    features = np.array(data, dtype=np.float32)

    # 将标签转换为数值（positive=1, negative=0）
    label_map = {'positive': 1, 'negative': 0}
    labels = np.array([label_map[label] for label in labels_list], dtype=np.int64)

    # 归一化特征
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    features = scaler.fit_transform(features)

    # 构建k-NN图
    print(f"使用k-NN (k={k}) 构建图...")
    adj_matrix, _ = build_knn_graph(features, k=k, metric='cosine')

    print(f">> Segment0数据加载完成")
    print_dataset_statistics(features, labels, adj_matrix)

    return features, labels, adj_matrix


def load_synthetic_data(n_samples: int = 1000, n_features: int = 20,
                       n_classes: int = 2, imbalance_ratio: float = 0.1,
                       k: int = 5) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    生成合成数据集（用于测试）

    Args:
        n_samples: 样本数量
        n_features: 特征数量
        n_classes: 类别数量
        imbalance_ratio: 少数类占比
        k: k-NN的k值

    Returns:
        features: 特征矩阵
        labels: 标签数组
        adj_matrix: 邻接矩阵
    """
    from sklearn.datasets import make_classification

    print(f"\n生成合成数据集 (n_samples={n_samples}, n_features={n_features}, n_classes={n_classes})")

    # 生成分类数据
    features, labels = make_classification(
        n_samples=n_samples,
        n_features=n_features,
        n_informative=int(n_features * 0.7),
        n_redundant=int(n_features * 0.2),
        n_classes=n_classes,
        n_clusters_per_class=2,
        weights=[imbalance_ratio] + [(1 - imbalance_ratio) / (n_classes - 1)] * (n_classes - 1),
        flip_y=0.01,
        random_state=42
    )

    # 归一化特征
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    features = scaler.fit_transform(features)

    # 构建k-NN图
    print(f"使用k-NN (k={k}) 构建图...")
    adj_matrix, _ = build_knn_graph(features, k=k, metric='cosine')

    print(f">> 合成数据生成完成")
    print_dataset_statistics(features, labels, adj_matrix)

    return features, labels, adj_matrix


# 示例使用
if __name__ == "__main__":
    # 测试数据加载

    # 1. 加载Cora数据集
    loader = DataLoader('cora', './data/')
    features, labels, adj_matrix = loader.load(
        imbalance_ratio=0.1,
        minority_class=0
    )

    # 2. 转换为PyTorch张量
    x, y, edge_index = loader.to_torch(features, labels, adj_matrix, device='cpu')
    print(f"\nPyTorch张量:")
    print(f"  x: {x.shape}")
    print(f"  y: {y.shape}")
    print(f"  edge_index: {edge_index.shape}")

    # 3. 生成合成数据
    features_syn, labels_syn, adj_syn = load_synthetic_data(
        n_samples=500,
        n_features=20,
        n_classes=2,
        imbalance_ratio=0.1
    )
