"""
规则引导的GraphSMOTE模块
实现嵌入空间插值、规则约束损失和边生成
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import List, Tuple, Optional
from sklearn.neighbors import NearestNeighbors


class GraphSMOTEGenerator(nn.Module):
    """GraphSMOTE生成器"""

    def __init__(self, k: int = 5, interpolation_method: str = 'linear'):
        """
        初始化GraphSMOTE生成器

        Args:
            k: k近邻数量
            interpolation_method: 插值方法 ('linear' 或 'gaussian')
        """
        super(GraphSMOTEGenerator, self).__init__()
        self.k = k
        self.interpolation_method = interpolation_method

    def generate_synthetic_embeddings(self, embeddings: torch.Tensor,
                                      num_samples: int,
                                      device: str = 'cuda') -> torch.Tensor:
        """
        在嵌入空间生成合成样本

        Args:
            embeddings: 少数类样本的嵌入 [N_minority, embedding_dim]
            num_samples: 要生成的样本数量
            device: 设备

        Returns:
            synthetic_embeddings: 合成样本嵌入 [num_samples, embedding_dim]
        """
        n_minority = embeddings.size(0)
        embedding_dim = embeddings.size(1)

        # 转换为numpy进行k-NN
        embeddings_np = embeddings.cpu().detach().numpy()

        # 构建k-NN
        knn = NearestNeighbors(n_neighbors=min(self.k + 1, n_minority))
        knn.fit(embeddings_np)

        synthetic_list = []

        for _ in range(num_samples):
            # 随机选择一个少数类样本
            idx = np.random.randint(0, n_minority)
            sample = embeddings[idx]

            # 找到k个最近邻
            distances, indices = knn.kneighbors([embeddings_np[idx]])
            neighbor_indices = indices[0][1:]  # 排除自己

            if len(neighbor_indices) == 0:
                # 如果没有邻居，直接复制
                synthetic = sample
            else:
                # 随机选择一个邻居
                neighbor_idx = np.random.choice(neighbor_indices)
                neighbor = embeddings[neighbor_idx]

                # 插值
                if self.interpolation_method == 'linear':
                    # 线性插值: x_new = x + λ * (x_neighbor - x)
                    lambda_val = np.random.random()
                    synthetic = sample + lambda_val * (neighbor - sample)

                elif self.interpolation_method == 'gaussian':
                    # 高斯插值: 在两点之间采样
                    mean = (sample + neighbor) / 2
                    std = torch.norm(neighbor - sample) / 4
                    noise = torch.randn_like(sample) * std
                    synthetic = mean + noise

                else:
                    synthetic = sample

            synthetic_list.append(synthetic)

        synthetic_embeddings = torch.stack(synthetic_list, dim=0)

        return synthetic_embeddings.to(device)

    def forward(self, embeddings: torch.Tensor, num_samples: int) -> torch.Tensor:
        """
        前向传播（生成合成嵌入）

        Args:
            embeddings: 少数类嵌入
            num_samples: 生成数量

        Returns:
            synthetic_embeddings: 合成嵌入
        """
        return self.generate_synthetic_embeddings(embeddings, num_samples,
                                                   device=embeddings.device)


class RuleLoss(nn.Module):
    """
    规则一致性损失

    改进要点：
    1. 保留原有的逐特征边界惩罚（向后兼容）
    2. 新增分组约束：将同一条规则的多个特征条件绑定为一组，
       当合成样本同时违反同一规则的多个条件时施加更强的惩罚，
       体现规则前件的合取（AND）语义
    """

    def __init__(self, constraints: List[Tuple[int, float, float]],
                 grouped_constraints: List[List[Tuple[int, float, float]]] = None):
        """
        初始化规则损失

        Args:
            constraints: 约束列表 [(feature_idx, lower_bound, upper_bound), ...]
            grouped_constraints: 分组约束（每组代表一条规则的合取条件）
                                 [[(...), (...)], [...], ...]
                                 如果为 None，则只使用独立约束
        """
        super(RuleLoss, self).__init__()
        self.constraints = constraints
        self.grouped_constraints = grouped_constraints or []

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """
        计算规则一致性损失

        Args:
            features: 生成的特征 [N, F]

        Returns:
            loss: 规则损失（标量）
        """
        if len(self.constraints) == 0 and len(self.grouped_constraints) == 0:
            return torch.tensor(0.0, device=features.device)

        total_loss = torch.tensor(0.0, device=features.device)
        n_terms = 0

        # ===== 1. 独立约束惩罚（向后兼容） =====
        if self.constraints:
            for feat_idx, lower_bound, upper_bound in self.constraints:
                if feat_idx >= features.shape[1]:
                    continue
                feat_values = features[:, feat_idx]
                lower_violation = F.relu(lower_bound - feat_values)
                upper_violation = F.relu(feat_values - upper_bound)
                total_loss = total_loss + lower_violation.mean() + upper_violation.mean()
                n_terms += 1

        # ===== 2. 分组（合取）约束惩罚 =====
        if self.grouped_constraints:
            for group in self.grouped_constraints:
                # 对每个样本，计算该规则组中所有条件的违反程度之和
                # 如果一个样本违反了多个条件，惩罚应当更强（超线性）
                group_violation = torch.zeros(features.shape[0], device=features.device)
                valid_conditions = 0
                for feat_idx, lower_bound, upper_bound in group:
                    if feat_idx >= features.shape[1]:
                        continue
                    feat_values = features[:, feat_idx]
                    violation = F.relu(lower_bound - feat_values) + F.relu(feat_values - upper_bound)
                    group_violation = group_violation + violation
                    valid_conditions += 1

                if valid_conditions > 0:
                    # 超线性惩罚：violation^1.5 使得同时违反多个条件的样本受到更重的惩罚
                    total_loss = total_loss + torch.pow(group_violation + 1e-8, 1.5).mean()
                    n_terms += 1

        if n_terms > 0:
            total_loss = total_loss / n_terms

        return total_loss

    def update_constraints(self, new_constraints: List[Tuple[int, float, float]],
                           new_grouped_constraints: List[List[Tuple[int, float, float]]] = None):
        """更新约束"""
        self.constraints = new_constraints
        if new_grouped_constraints is not None:
            self.grouped_constraints = new_grouped_constraints


class EdgeGenerationLoss(nn.Module):
    """边生成损失"""

    def __init__(self):
        """初始化边生成损失"""
        super(EdgeGenerationLoss, self).__init__()

    def forward(self, pred_edges: torch.Tensor, true_edges: torch.Tensor) -> torch.Tensor:
        """
        计算边预测损失

        Args:
            pred_edges: 预测的边概率 [N_syn, N_total]
            true_edges: 真实边（0或1） [N_syn, N_total]

        Returns:
            loss: BCE损失
        """
        loss = F.binary_cross_entropy(pred_edges, true_edges)
        return loss


class RuleGuidedGraphSMOTE(nn.Module):
    """规则引导的GraphSMOTE（完整模型）"""

    def __init__(self, encoder, decoder, classifier, edge_predictor,
                 smote_k: int = 5, interpolation_method: str = 'linear'):
        """
        初始化RG-GraphSMOTE

        Args:
            encoder: GNN编码器
            decoder: MLP解码器
            classifier: 分类器
            edge_predictor: 边预测器
            smote_k: SMOTE的k值
            interpolation_method: 插值方法
        """
        super(RuleGuidedGraphSMOTE, self).__init__()

        self.encoder = encoder
        self.decoder = decoder
        self.classifier = classifier
        self.edge_predictor = edge_predictor

        self.smote_generator = GraphSMOTEGenerator(smote_k, interpolation_method)
        self.rule_loss_fn = None  # 将在训练时设置

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor,
                labels: torch.Tensor, minority_class: int,
                num_synthetic: int = 0) -> Tuple:
        """
        前向传播

        Args:
            x: 节点特征 [N, F]
            edge_index: 边索引 [2, E]
            labels: 标签 [N]
            minority_class: 少数类标签
            num_synthetic: 生成的合成样本数量

        Returns:
            logits: 分类logits（包含合成样本）
            x_syn: 合成特征
            h_syn: 合成嵌入
            edge_probs: 边概率
        """
        # 1. 编码所有节点
        h = self.encoder(x, edge_index)

        # 2. 分类原始节点
        logits_original = self.classifier(h)

        if num_synthetic == 0:
            # 不生成合成样本
            return logits_original, None, None, None

        # 3. 获取少数类样本的嵌入
        minority_mask = (labels == minority_class)
        h_minority = h[minority_mask]

        # 4. 在嵌入空间生成合成样本
        h_syn = self.smote_generator(h_minority, num_synthetic)

        # 5. 解码到特征空间
        x_syn = self.decoder(h_syn)

        # 6. 分类合成样本
        logits_syn = self.classifier(h_syn)

        # 7. 合并原始和合成样本的logits
        logits_all = torch.cat([logits_original, logits_syn], dim=0)

        # 8. 预测合成节点的边
        edge_probs = self.edge_predictor(h_syn, h)

        return logits_all, x_syn, h_syn, edge_probs

    def generate_balanced_data(self, x: torch.Tensor, edge_index: torch.Tensor,
                               labels: torch.Tensor, minority_class: int,
                               balance_ratio: float = 1.0) -> Tuple:
        """
        生成平衡数据集

        Args:
            x: 原始特征
            edge_index: 原始边索引
            labels: 原始标签
            minority_class: 少数类标签
            balance_ratio: 平衡比例（1.0表示完全平衡）

        Returns:
            x_balanced: 平衡后的特征
            edge_index_balanced: 平衡后的边索引
            labels_balanced: 平衡后的标签
        """
        self.eval()
        with torch.no_grad():
            # 统计类别数量
            unique_labels, counts = torch.unique(labels, return_counts=True)
            n_minority = counts[unique_labels == minority_class].item()
            n_majority = counts[unique_labels != minority_class].sum().item()

            # 计算需要生成的样本数量
            num_synthetic = int((n_majority * balance_ratio) - n_minority)
            num_synthetic = max(0, num_synthetic)

            if num_synthetic == 0:
                print("数据已平衡，无需生成合成样本")
                return x, edge_index, labels

            # 生成合成样本
            _, x_syn, h_syn, edge_probs = self.forward(
                x, edge_index, labels, minority_class, num_synthetic
            )

            # 合并数据
            x_balanced = torch.cat([x, x_syn], dim=0)
            labels_syn = torch.full((num_synthetic,), minority_class,
                                   dtype=labels.dtype, device=labels.device)
            labels_balanced = torch.cat([labels, labels_syn], dim=0)

            # 生成新边（基于边预测概率）
            n_original = x.size(0)
            threshold = 0.5  # 边存在的阈值

            new_edges_list = []
            for i in range(num_synthetic):
                # 找到概率大于阈值的边
                node_idx = n_original + i
                probs = edge_probs[i]
                connected_nodes = torch.where(probs > threshold)[0]

                # 添加边（双向）
                for j in connected_nodes:
                    new_edges_list.append([node_idx, j.item()])
                    new_edges_list.append([j.item(), node_idx])

            # 合并边
            if len(new_edges_list) > 0:
                new_edges = torch.tensor(new_edges_list, dtype=edge_index.dtype,
                                        device=edge_index.device).t()
                edge_index_balanced = torch.cat([edge_index, new_edges], dim=1)
            else:
                edge_index_balanced = edge_index

            print(f">> 生成了 {num_synthetic} 个合成样本")
            print(f">> 平衡后数据: {x_balanced.size(0)} 节点, {edge_index_balanced.size(1)} 条边")

        return x_balanced, edge_index_balanced, labels_balanced


class CombinedLoss(nn.Module):
    """组合损失函数"""

    def __init__(self, lambda_class: float = 1.0, lambda_recon: float = 0.5,
                 lambda_rule: float = 0.3, lambda_edge: float = 0.2,
                 class_weights=None):
        """
        初始化组合损失

        Args:
            lambda_class: 分类损失权重
            lambda_recon: 重构损失权重
            lambda_rule: 规则损失权重
            lambda_edge: 边损失权重
            class_weights: 类别权重张量（用于平衡损失）
        """
        super(CombinedLoss, self).__init__()

        self.lambda_class = lambda_class
        self.lambda_recon = lambda_recon
        self.lambda_rule = lambda_rule
        self.lambda_edge = lambda_edge

        if class_weights is not None:
            self.class_loss_fn = nn.CrossEntropyLoss(weight=class_weights)
        else:
            self.class_loss_fn = nn.CrossEntropyLoss()
        self.recon_loss_fn = nn.MSELoss()

    def forward(self, logits: torch.Tensor, labels: torch.Tensor,
                x_syn: Optional[torch.Tensor], x_minority: Optional[torch.Tensor],
                rule_loss: Optional[torch.Tensor],
                edge_loss: Optional[torch.Tensor]) -> Tuple[torch.Tensor, dict]:
        """
        计算总损失

        Args:
            logits: 分类logits
            labels: 标签
            x_syn: 合成特征
            x_minority: 少数类原始特征（用于重构损失）
            rule_loss: 规则损失
            edge_loss: 边损失

        Returns:
            total_loss: 总损失
            loss_dict: 各项损失的字典
        """
        # 分类损失
        loss_class = self.class_loss_fn(logits, labels)

        total_loss = self.lambda_class * loss_class
        loss_dict = {'class': loss_class.item()}

        # 重构损失（如果有合成样本）
        if x_syn is not None and x_minority is not None:
            # 如果合成样本数量大于少数类样本数量，循环使用少数类样本
            if x_syn.size(0) > x_minority.size(0):
                # 重复少数类样本以匹配合成样本数量
                repeat_times = (x_syn.size(0) + x_minority.size(0) - 1) // x_minority.size(0)
                x_minority_repeated = x_minority.repeat(repeat_times, 1)[:x_syn.size(0)]
                loss_recon = self.recon_loss_fn(x_syn, x_minority_repeated)
            else:
                # 计算合成样本与原始少数类特征的相似度
                loss_recon = self.recon_loss_fn(x_syn, x_minority[:x_syn.size(0)])
            total_loss += self.lambda_recon * loss_recon
            loss_dict['recon'] = loss_recon.item()

        # 规则损失
        if rule_loss is not None:
            total_loss += self.lambda_rule * rule_loss
            loss_dict['rule'] = rule_loss.item()

        # 边损失
        if edge_loss is not None:
            total_loss += self.lambda_edge * edge_loss
            loss_dict['edge'] = edge_loss.item()

        loss_dict['total'] = total_loss.item()

        return total_loss, loss_dict

