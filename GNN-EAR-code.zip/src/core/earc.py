"""
EARC (Evidential Association Rule Classification) 模块
实现模糊化、Apriori频繁项挖掘、规则提取和证据推理
"""

import numpy as np
from typing import List, Tuple, Dict, Set
from itertools import combinations
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')


class FuzzySet:
    """模糊集合类"""

    def __init__(self, name: str, params: Tuple[float, float, float], fuzz_type: str = 'triangular'):
        """
        初始化模糊集

        Args:
            name: 模糊集名称 (如 'Low', 'Medium', 'High')
            params: 隶属函数参数 (a, b, c) 对于三角形或 (mean, std) 对于高斯
            fuzz_type: 模糊类型 'triangular' 或 'gaussian'
        """
        self.name = name
        self.params = params
        self.fuzz_type = fuzz_type

    def membership(self, x: float) -> float:
        """
        计算隶属度

        Args:
            x: 输入值

        Returns:
            隶属度 [0, 1]
        """
        if self.fuzz_type == 'triangular':
            a, b, c = self.params
            if x <= a or x >= c:
                return 0.0
            elif a < x <= b:
                return (x - a) / (b - a) if b != a else 1.0
            else:  # b < x < c
                return (c - x) / (c - b) if c != b else 1.0

        elif self.fuzz_type == 'gaussian':
            mean, std = self.params
            return np.exp(-((x - mean) ** 2) / (2 * std ** 2))

        return 0.0


class FeatureFuzzifier:
    """特征模糊化器"""

    def __init__(self, num_sets: int = 3, fuzz_type: str = 'triangular'):
        """
        初始化模糊化器

        Args:
            num_sets: 每个特征的模糊集数量
            fuzz_type: 模糊类型
        """
        self.num_sets = num_sets
        self.fuzz_type = fuzz_type
        self.fuzzy_sets = {}  # {feature_idx: [FuzzySet]}
        self.feature_ranges = {}  # {feature_idx: (min, max)}

    def fit(self, features: np.ndarray):
        """
        根据数据拟合模糊集

        Args:
            features: 特征矩阵 [N, F]
        """
        n_features = features.shape[1]

        for feat_idx in range(n_features):
            feat_values = features[:, feat_idx]
            min_val, max_val = feat_values.min(), feat_values.max()
            self.feature_ranges[feat_idx] = (min_val, max_val)

            # 创建模糊集
            fuzzy_sets = []
            if self.num_sets == 3:
                names = ['Low', 'Medium', 'High']
            else:
                names = [f'Set_{i}' for i in range(self.num_sets)]

            if self.fuzz_type == 'triangular':
                # 三角形模糊集
                step = (max_val - min_val) / (self.num_sets - 1)
                for i, name in enumerate(names):
                    if i == 0:
                        # Low: 左边界延伸
                        params = (min_val - step, min_val, min_val + step)
                    elif i == self.num_sets - 1:
                        # High: 右边界延伸
                        params = (max_val - step, max_val, max_val + step)
                    else:
                        # Medium
                        center = min_val + i * step
                        params = (center - step, center, center + step)

                    fuzzy_sets.append(FuzzySet(name, params, self.fuzz_type))

            elif self.fuzz_type == 'gaussian':
                # 高斯模糊集
                centers = np.linspace(min_val, max_val, self.num_sets)
                std = (max_val - min_val) / (2 * self.num_sets)

                for i, name in enumerate(names):
                    params = (centers[i], std)
                    fuzzy_sets.append(FuzzySet(name, params, self.fuzz_type))

            self.fuzzy_sets[feat_idx] = fuzzy_sets

    def transform(self, features: np.ndarray) -> np.ndarray:
        """
        将特征转换为模糊隶属度矩阵

        Args:
            features: 特征矩阵 [N, F]

        Returns:
            fuzzy_features: 模糊特征矩阵 [N, F * num_sets]
        """
        n_samples, n_features = features.shape
        fuzzy_features = np.zeros((n_samples, n_features * self.num_sets))

        for feat_idx in range(n_features):
            feat_values = features[:, feat_idx]
            for set_idx, fuzzy_set in enumerate(self.fuzzy_sets[feat_idx]):
                col_idx = feat_idx * self.num_sets + set_idx
                fuzzy_features[:, col_idx] = np.array([
                    fuzzy_set.membership(val) for val in feat_values
                ])

        return fuzzy_features

    def get_fuzzy_item_name(self, item_idx: int) -> str:
        """
        获取模糊项的名称

        Args:
            item_idx: 项索引

        Returns:
            项名称 (如 'Feature_0_is_Low')
        """
        feat_idx = item_idx // self.num_sets
        set_idx = item_idx % self.num_sets
        fuzzy_set = self.fuzzy_sets[feat_idx][set_idx]
        return f"Feature_{feat_idx}_is_{fuzzy_set.name}"


class AprioriRuleMiner:
    """Apriori算法规则挖掘器"""

    def __init__(self, min_support: float = 0.1, min_confidence: float = 0.8,
                 max_rule_length: int = 3, support_decay: float = 1.0,
                 min_support_floor: float = 0.0):
        """
        初始化Apriori挖掘器

        Args:
            min_support: 最小支持度
            min_confidence: 最小置信度
            max_rule_length: 最大规则长度
        """
        self.min_support = min_support
        self.min_confidence = min_confidence
        self.max_rule_length = max_rule_length
        self.frequent_itemsets = []
        self.rules = []
        self.activation_threshold = 1e-3
        self.train_features = None
        self.train_labels = None
        self.class_values = None
        self.num_classes = 0
        self._eps = 1e-12
        self.support_decay = support_decay
        self.min_support_floor = min_support_floor

    def _get_support(self, itemset: frozenset, transactions: List[Set]) -> float:
        """计算项集的支持度"""
        count = sum(1 for trans in transactions if itemset.issubset(trans))
        return count / len(transactions)

    def _generate_candidates(self, prev_itemsets: List[frozenset], k: int) -> List[frozenset]:
        """生成k项候选集"""
        candidates = []
        n = len(prev_itemsets)

        for i in range(n):
            for j in range(i + 1, n):
                # 合并两个(k-1)项集
                union = prev_itemsets[i] | prev_itemsets[j]
                if len(union) == k:
                    candidates.append(union)

        return list(set(candidates))

    def fit(self, fuzzy_features: np.ndarray, labels: np.ndarray, threshold: float = 0.1):
        """
        挖掘频繁项集和证据化关联规则（Evidential CAR）

        改进策略（解决不平衡问题）：
        1. 分类挖掘候选集：对每个类别的数据分别运行Apriori，找出在该类内部频繁的项集。
           这样可以确保即使是少数类，也能挖掘出只要在该类内部频繁的规则。
        2. 全局评估：将所有候选项集在整个数据集上进行评估，计算置信规则。
        3. 规则筛选：筛选出满足最小置信度的规则。对于少数类规则，适当放宽置信度要求。

        Args:
            fuzzy_features: 模糊特征矩阵 [N, F*num_sets]
            labels: 标签 [N]
            threshold: 模糊隶属度阈值（低于此值视为0）
        """
        self.train_features = fuzzy_features
        self.train_labels = labels
        self.class_values, inverse_idx = np.unique(labels, return_inverse=True)
        self.num_classes = len(self.class_values)

        # 统计类别数量，识别少数类
        class_counts = np.bincount(inverse_idx, minlength=self.num_classes)
        avg_count = len(labels) / self.num_classes
        # 定义少数类：样本数少于平均值的类
        self.minority_classes = set(np.where(class_counts < avg_count)[0])

        n_samples, n_items = fuzzy_features.shape

        # 将模糊特征转换为事务
        transactions = []
        for i in range(n_samples):
            trans = set()
            for j in range(n_items):
                if fuzzy_features[i, j] > threshold:
                    trans.add(j)
            transactions.append(trans)

        # ========== 阶段1: 分类候选集挖掘 ==========

        # 按类别分组事务
        class_transactions = defaultdict(list)
        for i, label in enumerate(inverse_idx): # 使用inverse_idx确保索引0..K
            class_transactions[label].append(transactions[i])

        candidate_itemsets = set()

        # 对每个类别分别挖掘频繁项集
        for label_idx, cls_trans in class_transactions.items():
            if not cls_trans:
                continue

            # 使用类内支持度挖掘
            # 对于极不平衡的少数类，可以考虑进一步降低min_support，但百分比机制通常足够
            cls_frequent = self._mine_frequent_itemsets(cls_trans)
            candidate_itemsets.update(cls_frequent.keys())

        if not candidate_itemsets:
            self.rules = []
            return

        # ========== 阶段2: 证据化规则后件生成及全局评估 ==========

        self.rules = []

        for antecedent in candidate_itemsets:
            if len(antecedent) < 1:
                continue

            # 计算规则的全局支持度 (ant_support)
            ant_support = self._get_support(antecedent, transactions)

            # 计算每个样本对该前件的匹配度（几何平均，论文Eq.12）
            matching_degrees = []
            sample_classes = []

            # 优化：只检查激活的样本，但这里需要遍历所有样本才能知道谁激活
            # 不过我们可以预先知道哪些样本包含antecedent的所有items（事务视角）
            # 但这里是模糊特征，必须看隶属度。
            # 这里的性能瓶颈可以通过矩阵运算优化，但保持逻辑清晰先。

            for idx in range(n_samples):
                # 快速检查：如果样本事务不包含antecedent的所有项，直接跳过
                # 注意：transactions是硬阈值截断的，如果要求精确模糊匹配度，
                # 可能会有 marginal case (0.1以下但非0)，但通常忽略不计。
                if not antecedent.issubset(transactions[idx]):
                   continue

                memberships = []
                for item_idx in antecedent:
                    memberships.append(fuzzy_features[idx, item_idx])

                geo_mean = np.prod(memberships) ** (1.0 / len(memberships))
                matching_degrees.append(geo_mean)
                sample_classes.append(inverse_idx[idx])

            if len(matching_degrees) == 0:
                continue

            matching_degrees = np.array(matching_degrees)
            sample_classes = np.array(sample_classes)

            # 按类别分组
            class_memberships = [[] for _ in range(self.num_classes)]
            for mu, cls_idx in zip(matching_degrees, sample_classes):
                class_memberships[cls_idx].append(mu)

            # === 阶段2.1: 同类证据合成（Intra-class, 论文Eq.16） ===
            intra_class_mass = []
            for c in range(self.num_classes):
                mus = class_memberships[c]
                if len(mus) == 0:
                    intra_class_mass.append({'class': 0.0, 'Theta': 1.0})
                else:
                    prod_complement = np.prod([1.0 - mu for mu in mus])
                    m_class = 1.0 - prod_complement
                    m_theta = prod_complement
                    intra_class_mass.append({'class': m_class, 'Theta': m_theta})

            # === 阶段2.2: 异类证据折扣 + 合成（Inter-class, 论文Eq.19） ===
            total_samples = len(matching_degrees)
            mass_vector = np.zeros(self.num_classes + 1)
            mass_vector[-1] = 1.0

            for c in range(self.num_classes):
                n_c = len(class_memberships[c])
                if n_c == 0:
                    continue

                discount_factor = n_c / total_samples
                m_c = discount_factor * intra_class_mass[c]['class']
                m_theta_c = discount_factor * intra_class_mass[c]['Theta'] + (1.0 - discount_factor)

                class_mass = np.zeros(self.num_classes + 1)
                class_mass[c] = m_c
                class_mass[-1] = m_theta_c

                mass_vector = self._dempster_combination_simple(mass_vector, class_mass)

            # === 阶段2.3: 计算置信支持度和置信度 ===
            belief_mass = mass_vector[:-1]
            ignorance = mass_vector[-1]
            pignistic_prob = belief_mass + ignorance / self.num_classes

            class_supports = np.array([
                np.sum(class_memberships[c]) / n_samples if len(class_memberships[c]) > 0 else 0.0
                for c in range(self.num_classes)
            ])

            evidential_support = np.sum(pignistic_prob * class_supports)
            evidential_conf = evidential_support / (ant_support + self._eps)

            # 确定规则主要预测的类别
            predicted_class = np.argmax(pignistic_prob)

            # 计算提升度 (Lift) 用于辅助筛选
            # Lift = P(Class|Rule) / P(Class)
            # 这里 P(Class|Rule) 近似为 pignistic_prob[predicted_class]
            # P(Class) = class_counts[predicted_class] / n_samples
            prior_prob = class_counts[predicted_class] / n_samples
            lift = pignistic_prob[predicted_class] / (prior_prob + self._eps)

            rule = {
                'antecedent': antecedent,
                'support': ant_support,
                'confidence': evidential_conf,
                'lift': lift,
                'mass': belief_mass.copy(),
                'ignorance': ignorance,
                'class_support': class_supports,
                'num_activated': len(matching_degrees),
                'class_distribution': [len(class_memberships[c]) for c in range(self.num_classes)],
                'predicted_class': predicted_class # 记录主要预测类别，用于筛选
            }

            # 动态置信度阈值：对于少数类规则，放宽阈值
            current_threshold = self.min_confidence
            if predicted_class in self.minority_classes:
                # 少数类规则：允许较低的置信度 (例如降低20%)
                current_threshold = self.min_confidence * 0.8

            if evidential_conf >= current_threshold:
                self.rules.append(rule)

        # 初始排序
        self.rules.sort(key=lambda x: x['confidence'], reverse=True)

    def _mine_frequent_itemsets(self, transactions: List[Set]) -> Dict[frozenset, float]:
        """helper: 在给定事务列表上挖掘频繁项集"""
        n_trans = len(transactions)
        if n_trans == 0:
            return {}

        # 1-项集
        item_counts = defaultdict(int)
        for t in transactions:
            for item in t:
                item_counts[item] += 1

        frequent_itemsets = {}
        frequent_1 = []

        for item, count in item_counts.items():
            support = count / n_trans
            if support >= self.min_support:
                itemset = frozenset([item])
                frequent_1.append(itemset)
                frequent_itemsets[itemset] = support

        all_frequent = [frequent_1]

        k = 2
        # 支持度衰减：随着规则变长，允许支持度略微降低？
        # 目前的逻辑：support_k = max(floor, min_support * decay)
        support_k = self.min_support * self.support_decay
        support_k = max(self.min_support_floor, support_k)

        while k <= self.max_rule_length and len(all_frequent[-1]) > 0:
            candidates_k = self._generate_candidates(all_frequent[-1], k)
            frequent_k = []

            # 使用列表推导式可能内存占用大，改为迭代
            for itemset in candidates_k:
                # 优化: 只有当支持度足够才保留
                # _get_support是昂贵的，因为它要扫描所有事务
                support = self._get_support(itemset, transactions)
                if support >= support_k:
                    frequent_k.append(itemset)
                    frequent_itemsets[itemset] = support

            if len(frequent_k) > 0:
                all_frequent.append(frequent_k)
            else:
                break

            support_k = max(self.min_support_floor, support_k * self.support_decay)
            k += 1

        return frequent_itemsets

    def get_top_rules(self, top_k: int = 20) -> List[Dict]:
        """
        获取top-k规则，保证类别覆盖

        策略：
        1. 优先为每个类别保留一定数量的最高置信度规则（Guarantee Coverage）
        2. 剩余名额由全局最高置信度规则填充（Global Best）
        """
        if not self.rules:
            return []

        if self.num_classes <= 1:
            return self.rules[:top_k]

        # 按预测类别分组
        class_rules = defaultdict(list)
        for rule in self.rules:
            # 确保只使用有意义的规则（mass > 0）
            if np.max(rule['mass']) > 0.1:
                class_rules[rule['predicted_class']].append(rule)

        # 计算每个类别的保底名额
        # 例如：如果我们有20个名额，2个类，每个类保底3-5个比较合理
        # 这里设置为 top_k / (2 * num_classes) 或者是固定的比如3
        min_quota = max(1, int(top_k / (2 * self.num_classes)))

        selected_indices = set()
        selected_rules = []

        # 1. 每一类先选出 Top-Quota
        for c in range(self.num_classes):
            if c in class_rules:
                # 该类规则已按confidence排好序（因为self.rules是有序的，group的时候保持了顺序）
                # 再次排序确保万无一失
                c_rules = sorted(class_rules[c], key=lambda x: x['confidence'], reverse=True)

                # 取前 min_quota 个
                take_cnt = min(len(c_rules), min_quota)
                for i in range(take_cnt):
                    rule = c_rules[i]
                    # 我们需要唯一标识规则，这里简单用对象ID或antecedent
                    # 由于规则对象是唯一的，直接用对象ID判断
                    rule_id = id(rule)
                    if rule_id not in selected_indices:
                        selected_rules.append(rule)
                        selected_indices.add(rule_id)

        # 2. 剩下的名额由全局 Top 填充
        remaining_slots = top_k - len(selected_rules)
        if remaining_slots > 0:
            count = 0
            for rule in self.rules:
                rule_id = id(rule)
                if rule_id not in selected_indices:
                    selected_rules.append(rule)
                    selected_indices.add(rule_id)
                    count += 1
                    if count >= remaining_slots:
                        break

        # 再次按置信度排序返回
        selected_rules.sort(key=lambda x: x['confidence'], reverse=True)
        return selected_rules

    def _dempster_combination_simple(self, mass1: np.ndarray, mass2: np.ndarray) -> np.ndarray:
        """
        简化的Dempster-Shafer组合规则（用于规则生成）

        Args:
            mass1: 第一个质量函数 [num_classes + 1]
            mass2: 第二个质量函数 [num_classes + 1]

        Returns:
            combined: 组合后的质量函数 [num_classes + 1]
        """
        combined = np.zeros_like(mass1)

        # 计算冲突质量
        conflict = 0.0
        for i in range(self.num_classes):
            for j in range(self.num_classes):
                if i != j:
                    conflict += mass1[i] * mass2[j]

        denom = 1.0 - conflict
        if denom <= self._eps:
            # 完全冲突，返回均匀分布
            combined[:-1] = 1.0 / self.num_classes
            combined[-1] = 0.0
            return combined

        # Dempster组合公式
        # m(A) = [m1(A)*m2(A) + m1(A)*m2(Theta) + m1(Theta)*m2(A)] / (1 - conflict)
        for c in range(self.num_classes):
            combined[c] = (
                mass1[c] * mass2[c] +           # 两个都支持c
                mass1[c] * mass2[-1] +          # mass1支持c，mass2不确定
                mass1[-1] * mass2[c]            # mass1不确定，mass2支持c
            ) / denom

        # 不确定性组合
        combined[-1] = (mass1[-1] * mass2[-1]) / denom

        return combined


class RuleExtractor:
    """规则提取器：从频繁项集中提取数值约束"""

    def __init__(self, fuzzifier: FeatureFuzzifier):
        """
        初始化规则提取器

        Args:
            fuzzifier: 特征模糊化器
        """
        self.fuzzifier = fuzzifier

    def extract_constraints(self, rules: List[Dict]) -> List[Tuple[int, float, float]]:
        """
        从规则中提取特征约束（数值范围）

        Args:
            rules: 规则列表

        Returns:
            constraints: 约束列表 [(feature_idx, lower_bound, upper_bound), ...]
        """
        constraints = []

        for rule in rules:
            for item_idx in rule['antecedent']:
                feat_idx = item_idx // self.fuzzifier.num_sets
                set_idx = item_idx % self.fuzzifier.num_sets

                fuzzy_set = self.fuzzifier.fuzzy_sets[feat_idx][set_idx]

                if fuzzy_set.fuzz_type == 'triangular':
                    a, b, c = fuzzy_set.params
                    lower_bound = a
                    upper_bound = c
                elif fuzzy_set.fuzz_type == 'gaussian':
                    mean, std = fuzzy_set.params
                    lower_bound = mean - 2 * std
                    upper_bound = mean + 2 * std
                else:
                    continue

                feat_min, feat_max = self.fuzzifier.feature_ranges[feat_idx]
                lower_bound = max(lower_bound, feat_min)
                upper_bound = min(upper_bound, feat_max)

                constraints.append((feat_idx, lower_bound, upper_bound))

        # 去重并合并同一特征的约束
        constraint_dict = defaultdict(list)
        for feat_idx, lb, ub in constraints:
            constraint_dict[feat_idx].append((lb, ub))

        merged_constraints = []
        for feat_idx, bounds_list in constraint_dict.items():
            lower_bound = min([lb for lb, ub in bounds_list])
            upper_bound = max([ub for lb, ub in bounds_list])
            merged_constraints.append((feat_idx, lower_bound, upper_bound))

        return merged_constraints

    def extract_grouped_constraints(self, rules: List[Dict]) -> List[List[Tuple[int, float, float]]]:
        """
        提取分组约束：每条规则的前件条件组成一组（用于合取感知的 RuleLoss）

        每组约束代表一条规则的完整 AND 条件，只有样本同时满足
        组内所有条件才算符合该规则。

        Args:
            rules: 规则列表

        Returns:
            grouped: [[条件1, 条件2, ...], ...]，每个子列表对应一条规则
        """
        grouped = []
        for rule in rules:
            group = []
            for item_idx in rule['antecedent']:
                feat_idx = item_idx // self.fuzzifier.num_sets
                set_idx = item_idx % self.fuzzifier.num_sets
                fuzzy_set = self.fuzzifier.fuzzy_sets[feat_idx][set_idx]

                if fuzzy_set.fuzz_type == 'triangular':
                    a, b, c = fuzzy_set.params
                    lower_bound, upper_bound = a, c
                elif fuzzy_set.fuzz_type == 'gaussian':
                    mean, std = fuzzy_set.params
                    lower_bound = mean - 2 * std
                    upper_bound = mean + 2 * std
                else:
                    continue

                feat_min, feat_max = self.fuzzifier.feature_ranges[feat_idx]
                lower_bound = max(lower_bound, feat_min)
                upper_bound = min(upper_bound, feat_max)
                group.append((feat_idx, lower_bound, upper_bound))

            if group:
                grouped.append(group)
        return grouped


class EvidentialReasoner:
    """证据推理器（基于Dempster-Shafer理论）"""

    def __init__(self, num_classes: int):
        """
        初始化证据推理器

        Args:
            num_classes: 类别数量
        """
        self.num_classes = num_classes
        self._eps = 1e-12
        self.rule_reliability = 1.0

    def set_reliability(self, reliability: float):
        """设置规则可靠度 (0-1)"""
        self.rule_reliability = max(0.0, min(1.0, reliability))

    def compute_mass_from_rules(self, sample: np.ndarray, rules: List[Dict],
                                 fuzzy_features: np.ndarray) -> np.ndarray:
        """
        根据规则计算质量函数（Mass）

        Args:
            sample: 样本的模糊特征 [F*num_sets]
            rules: 规则列表
            fuzzy_features: 用于归一化的全局模糊特征

        Returns:
            mass: 各类别的质量 [num_classes + 1] (最后一维是不确定性)
        """
        mass = np.zeros(self.num_classes + 1)
        mass[-1] = 1.0  # 初始化为完全不确定

        for rule in rules:
            antecedent = rule['antecedent']
            if len(antecedent) == 0:
                continue
            
            # 计算样本与规则前件的匹配度
            memberships = np.array([sample[item_idx] for item_idx in antecedent])
            if np.any(memberships <= 0):
                continue
            
            # 使用几何平均作为匹配度
            geo_mean = np.prod(memberships) ** (1.0 / len(antecedent))
            association = min(1.0, geo_mean * rule['confidence'])
            if association <= self._eps:
                continue

            # 构建新的证据质量函数
            rule_mass = np.append(rule['mass'], rule['ignorance'])
            new_mass = np.zeros(self.num_classes + 1)
            new_mass[:-1] = association * rule_mass[:-1]
            new_mass[-1] = association * rule_mass[-1] + (1.0 - association)

            # Dempster组合
            mass = self._dempster_combination(mass, new_mass)

        return mass

    def _dempster_combination(self, mass1: np.ndarray, mass2: np.ndarray) -> np.ndarray:
        """
        Dempster-Shafer组合规则

        Args:
            mass1: 第一个质量函数
            mass2: 第二个质量函数

        Returns:
            combined_mass: 组合后的质量函数
        """
        combined = np.zeros_like(mass1)

        conflict = 0.0
        for i in range(self.num_classes):
            for j in range(self.num_classes):
                if i != j:
                    conflict += mass1[i] * mass2[j]

        denom = 1.0 - conflict
        if denom <= self._eps:
            return combined if combined.sum() > 0 else mass1

        for c in range(self.num_classes):
            combined[c] = (
                mass1[c] * mass2[c]
                + mass1[c] * mass2[-1]
                + mass1[-1] * mass2[c]
            ) / denom
        combined[-1] = (mass1[-1] * mass2[-1]) / denom

        return combined

    def fuse_with_gnn(self, mass_rules: np.ndarray, prob_gnn: np.ndarray,
                      alpha: float = 0.5, return_weights: bool = False):
        """
        融合EARC规则推理和GNN预测（简单加权融合）

        Args:
            mass_rules: 规则推理的质量函数 [num_classes + 1]
            prob_gnn: GNN的预测概率 [num_classes]
            alpha: 融合权重参数 (0-1)，表示GNN的权重，规则权重为(1-alpha)
            return_weights: 是否返回权重诊断信息

        Returns:
            final_prob: 最终预测概率 [num_classes]
            或 (final_prob, weight_info) if return_weights=True
        """
        # 提取类别质量（去除不确定性）
        mass_class = mass_rules[:-1]
        belief = mass_class.sum()
        uncertainty = mass_rules[-1]

        # 如果规则证据太弱，直接使用GNN
        if belief <= self._eps:
            if return_weights:
                return prob_gnn.copy(), {
                    'w_rules': 0.0,
                    'w_gnn': 1.0,
                    'reason': 'no_evidence',
                    'belief': float(belief),
                    'uncertainty': float(uncertainty)
                }
            return prob_gnn.copy()
        
        # 将质量转换为概率分布（Pignistic转换）
        rule_prob = mass_class / belief
        
        # 简单加权融合: alpha * GNN + (1-alpha) * Rules
        weight_gnn = alpha
        weight_rules = 1.0 - alpha

        # 加权融合
        fused = weight_gnn * prob_gnn + weight_rules * rule_prob

        # 归一化
        fused_sum = fused.sum()
        if fused_sum <= self._eps:
            if return_weights:
                return prob_gnn / prob_gnn.sum(), {
                    'w_rules': 0.0,
                    'w_gnn': 1.0,
                    'reason': 'norm_fail',
                    'belief': float(belief),
                    'uncertainty': float(uncertainty)
                }
            return prob_gnn / prob_gnn.sum()
        
        fused = fused / fused_sum
        
        if return_weights:
            weight_info = {
                'w_rules': float(weight_rules),
                'w_gnn': float(weight_gnn),
                'belief': float(belief),
                'uncertainty': float(uncertainty),
                'alpha': float(alpha),
                'rule_reliability': float(self.rule_reliability)
            }

            return fused, weight_info

        return fused


class EARCClassifier:
    """EARC分类器（完整流程）"""

    def __init__(self, num_fuzzy_sets: int = 3, min_support: float = 0.1,
                 min_confidence: float = 0.8, max_rule_length: int = 3,
                 top_k_rules: int = 20, support_decay: float = 1.0,
                 min_support_floor: float = 0.0,
                 enable_rule_selection: bool = False,
                 target_sparsity: float = 0.5,
                 rule_selection_epochs: int = 100):
        """
        初始化EARC分类器

        Args:
            num_fuzzy_sets: 模糊集数量
            min_support: 最小支持度
            min_confidence: 最小置信度
            max_rule_length: 最大规则长度
            top_k_rules: 保留的规则数量
            support_decay: 支持度衰减
            min_support_floor: 支持度下限
            enable_rule_selection: 是否启用规则自动选择优化
            target_sparsity: 目标规则保留比例（0-1）
            rule_selection_epochs: 规则选择优化的训练轮数
        """
        self.fuzzifier = FeatureFuzzifier(num_fuzzy_sets)
        self.rule_miner = AprioriRuleMiner(min_support, min_confidence,
                                           max_rule_length, support_decay,
                                           min_support_floor)
        self.rule_extractor = None
        self.evidential_reasoner = None
        self.rules = []
        self.original_rules = []  # 保存原始规则（选择前）
        self.minority_rules = []  # 为了兼容性保留，指向少数类规则子集
        self.majority_rules = []  # 为了兼容性保留，指向多数类规则子集
        self.constraints = []
        self.grouped_constraints = []
        self.rule_reliability = 0.0
        self.top_k_rules = top_k_rules

        # 规则选择相关
        self.enable_rule_selection = enable_rule_selection
        self.target_sparsity = target_sparsity
        self.rule_selection_epochs = rule_selection_epochs
        self.rule_selector = None
        self.rule_selection_scores = None

    def fit(self, features: np.ndarray, labels: np.ndarray, minority_class: int = None,
            device: str = 'cpu'):
        """
        训练EARC分类器

        Args:
            features: 特征矩阵
            labels: 标签
            minority_class: 少数类标签 (用于统计信息，可选)
            device: 计算设备（用于规则选择）
        """
        # 1. 模糊化
        self.fuzzifier.fit(features)
        fuzzy_features = self.fuzzifier.transform(features)

        # 2. 规则挖掘 (使用改进的平衡挖掘策略)
        self.rule_miner.fit(fuzzy_features, labels)
        self.original_rules = self.rule_miner.get_top_rules(self.top_k_rules)
        self.rules = self.original_rules.copy()

        # 统计和分类规则（用于日志和分析）
        unique_classes = np.unique(labels)
        num_classes = len(unique_classes)

        if minority_class is not None and minority_class in unique_classes:
            self.minority_rules = [r for r in self.rules if r['predicted_class'] == minority_class]
            self.majority_rules = [r for r in self.rules if r['predicted_class'] != minority_class]
            print(f">> 规则挖掘完成: 总规则 {len(self.rules)} 条 (少数类: {len(self.minority_rules)}, 其他: {len(self.majority_rules)})")
        else:
            print(f">> 规则挖掘完成: 总规则 {len(self.rules)} 条")

        # 3. 初始化证据推理器（在规则选择之前需要）
        self.evidential_reasoner = EvidentialReasoner(num_classes)

        # 4. 规则自动选择优化（如果启用）
        if self.enable_rule_selection and len(self.rules) > 0:
            self.rules = self._optimize_rule_selection(
                features, fuzzy_features, labels, num_classes, device
            )
            # 更新少数类/多数类规则统计
            if minority_class is not None and minority_class in unique_classes:
                self.minority_rules = [r for r in self.rules if r['predicted_class'] == minority_class]
                self.majority_rules = [r for r in self.rules if r['predicted_class'] != minority_class]

        # 5. 提取约束
        self.rule_extractor = RuleExtractor(self.fuzzifier)
        self.constraints = self.rule_extractor.extract_constraints(self.rules)
        self.grouped_constraints = self.rule_extractor.extract_grouped_constraints(self.rules)

        # 6. 评估规则可靠度
        self.rule_reliability = self._estimate_rule_reliability(fuzzy_features, labels)

        print(f"EARC训练完成: 提取了 {len(self.rules)} 条规则和 {len(self.constraints)} 个约束 (规则可靠度={self.rule_reliability:.3f})")

    def _optimize_rule_selection(self, features: np.ndarray, fuzzy_features: np.ndarray,
                                  labels: np.ndarray, num_classes: int,
                                  device: str = 'cpu') -> List[Dict]:
        """
        使用异构图神经网络优化规则选择

        Args:
            features: 原始特征矩阵
            fuzzy_features: 模糊特征矩阵
            labels: 标签
            num_classes: 类别数
            device: 计算设备

        Returns:
            selected_rules: 选中的规则列表
        """
        from .hetero_graph import RuleSelector, RuleSampleHeteroGraph

        print(f"\n>> 开始规则自动选择优化...")
        print(f"   候选规则数: {len(self.original_rules)}")
        print(f"   目标保留比例: {self.target_sparsity:.1%}")

        # 构建激活矩阵
        hetero_graph = RuleSampleHeteroGraph(
            rules=self.original_rules,
            fuzzy_features=fuzzy_features,
            labels=labels,
            num_classes=num_classes
        )
        activation_matrix = hetero_graph.activation_matrix

        # 初始化规则选择器
        sample_dim = features.shape[1]
        self.rule_selector = RuleSelector(
            sample_dim=sample_dim,
            num_classes=num_classes,
            hidden_dim=64,
            rule_feat_dim=32,
            num_layers=2,
            sparsity_weight=0.1,
            target_sparsity=self.target_sparsity,
            device=device
        )

        # 训练规则选择器
        selected_rules = self.rule_selector.fit(
            sample_features=features,
            labels=labels,
            rules=self.original_rules,
            activation_matrix=activation_matrix,
            num_epochs=self.rule_selection_epochs,
            patience=20,
            verbose=True
        )

        # 保存选择分数
        self.rule_selection_scores = self.rule_selector.get_selection_scores()

        # 评估选择效果
        eval_metrics = self.rule_selector.evaluate(
            sample_features=features,
            labels=labels,
            rules=self.original_rules,
            activation_matrix=activation_matrix
        )
        print(f"\n>> 规则选择优化完成:")
        print(f"   原始规则数: {eval_metrics['num_rules_original']}")
        print(f"   选中规则数: {len(selected_rules)}")
        print(f"   压缩率: {eval_metrics['compression_ratio']:.1%}")
        print(f"   分类准确率: {eval_metrics['accuracy']:.4f}")
        print(f"   F1-Macro: {eval_metrics['f1_macro']:.4f}")

        return selected_rules

    def _estimate_rule_reliability(self, fuzzy_features: np.ndarray, labels: np.ndarray,
                                   rules: List[Dict] = None) -> float:
        """
        估算规则可靠度

        注意：此方法在训练数据上评估（因为没有额外的验证集），
        结果可能偏高。为缓解过拟合估计，使用 Laplace 平滑。

        对于大数据集（>1000样本），随机采样以降低计算成本。

        Args:
            fuzzy_features: 模糊特征矩阵
            labels: 标签
            rules: 规则列表（None 则使用 self.rules）

        Returns:
            reliability: 规则可靠度 [0, 1]
        """
        if rules is None:
            rules = self.rules

        if len(rules) == 0:
            return 0.0

        n_total = len(labels)
        n_classes = len(np.unique(labels))

        # 对大数据集采样以降低计算量
        max_eval_samples = 1000
        if n_total > max_eval_samples:
            indices = np.random.choice(n_total, max_eval_samples, replace=False)
            fuzzy_features = fuzzy_features[indices]
            labels = labels[indices]
            n_total = max_eval_samples

        correct = 0
        for sample, label in zip(fuzzy_features, labels):
            mass = self.evidential_reasoner.compute_mass_from_rules(sample, rules, fuzzy_features)
            pred = np.argmax(mass[:-1]) if mass[:-1].sum() > self.evidential_reasoner._eps else label
            if pred == label:
                correct += 1

        # Laplace 平滑：(correct + 1) / (total + n_classes)
        # 防止在小数据集上得到 1.0 的过度自信估计
        reliability = (correct + 1) / (n_total + n_classes)
        return reliability

    def predict(self, features: np.ndarray, gnn_probs: np.ndarray = None,
                alpha: float = 0.5) -> np.ndarray:
        """
        预测

        Args:
            features: 特征矩阵
            gnn_probs: GNN预测概率（可选）
            alpha: 融合权重

        Returns:
            predictions: 预测标签
        """
        fuzzy_features = self.fuzzifier.transform(features)
        n_samples = features.shape[0]
        predictions = np.zeros(n_samples)

        for i in range(n_samples):
            mass = self.evidential_reasoner.compute_mass_from_rules(
                fuzzy_features[i], self.rules, fuzzy_features
            )

            if gnn_probs is not None:
                final_prob = self.evidential_reasoner.fuse_with_gnn(
                    mass, gnn_probs[i], alpha
                )
            else:
                final_prob = mass[:-1]

            predictions[i] = np.argmax(final_prob)

        return predictions

    def get_constraints(self) -> List[Tuple[int, float, float]]:
        """获取提取的约束（用于GraphSMOTE）"""
        return self.constraints

    def get_grouped_constraints(self) -> List[List[Tuple[int, float, float]]]:
        """获取分组约束（每组对应一条规则的合取条件，用于 RuleLoss）"""
        return getattr(self, 'grouped_constraints', [])

    def get_rule_selection_info(self) -> Dict:
        """获取规则选择的详细信息"""
        if not self.enable_rule_selection:
            return {'enabled': False}

        return {
            'enabled': True,
            'original_rules_count': len(self.original_rules),
            'selected_rules_count': len(self.rules),
            'compression_ratio': 1 - len(self.rules) / len(self.original_rules) if len(self.original_rules) > 0 else 0,
            'target_sparsity': self.target_sparsity,
            'selection_scores': self.rule_selection_scores
        }
