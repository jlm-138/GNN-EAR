"""
构建样本-规则异构图神经网络并实现规则自动选择优化

核心功能：
1. 构建样本节点和规则节点的异构图
2. 使用异构图神经网络学习规则重要性
3. 自动选择最优规则子集，在保证分类精度的同时最小化规则库规模
"""

from typing import List, Dict, Tuple, Optional
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import softmax


class RuleSampleHeteroGraph:
    """将样本与EARC规则连接成异构图，并估计规则可靠度"""

    def __init__(self, rules: List[Dict], fuzzy_features: np.ndarray,
                 labels: np.ndarray, num_classes: int, activation_threshold: float = 1e-3):
        self.rules = rules
        self.fuzzy_features = fuzzy_features
        self.labels = labels
        self.num_classes = num_classes
        self.activation_threshold = activation_threshold
        self.activation_matrix = self._build_activation_matrix()

    def _build_activation_matrix(self) -> np.ndarray:
        n_samples = self.fuzzy_features.shape[0]
        n_rules = len(self.rules)
        activation = np.zeros((n_samples, n_rules), dtype=np.float32)

        for r_idx, rule in enumerate(self.rules):
            antecedent = rule['antecedent']
            if len(antecedent) == 0:
                continue
            feat_indices = list(antecedent)
            memberships = self.fuzzy_features[:, feat_indices]
            match = np.prod(memberships, axis=1)
            match[match < self.activation_threshold] = 0.0
            activation[:, r_idx] = match

        return activation

    def compute_rule_reliability(self) -> Tuple[np.ndarray, float]:
        """计算每条规则可靠度以及整体平均可靠度"""
        if len(self.rules) == 0:
            return np.array([]), 0.0

        eps = 1e-12
        activation = self.activation_matrix
        rule_strength = activation.sum(axis=0)
        if np.all(rule_strength <= eps):
            return np.zeros(len(self.rules)), 0.0

        label_onehot = np.eye(self.num_classes)[self.labels]
        class_support = activation.T @ label_onehot  # shape: [rules, classes]
        rule_totals = rule_strength[:, None] + eps
        class_prob = class_support / rule_totals

        confidence = class_prob.max(axis=1)  # 每条规则的最佳类别置信度
        coverage = rule_strength / (rule_strength.max() + eps)
        reliability = confidence * coverage
        reliability = np.clip(reliability, 0.0, 1.0)

        global_rel = float(np.mean(reliability))
        return reliability, global_rel


class HeteroRuleEncoder(nn.Module):
    """
    异构图中的规则节点编码器
    将规则的统计特征（支持度、置信度、mass等）编码为向量
    """

    def __init__(self, num_classes: int, rule_feat_dim: int = 32):
        super(HeteroRuleEncoder, self).__init__()
        # 规则原始特征: support, confidence, lift, ignorance, num_activated, mass(num_classes)
        # 总维度: 5 + num_classes
        input_dim = 5 + num_classes
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, rule_feat_dim),
            nn.ReLU(),
            nn.Linear(rule_feat_dim, rule_feat_dim),
            nn.LayerNorm(rule_feat_dim)
        )
        self.num_classes = num_classes

    def forward(self, rules: List[Dict], device: str = 'cpu') -> torch.Tensor:
        """
        编码规则列表为特征矩阵

        Args:
            rules: 规则列表
            device: 计算设备

        Returns:
            rule_features: [num_rules, rule_feat_dim]
        """
        if len(rules) == 0:
            return torch.zeros(0, self.encoder[0].out_features, device=device)

        features = []
        for rule in rules:
            feat = [
                rule.get('support', 0.0),
                rule.get('confidence', 0.0),
                rule.get('lift', 1.0),
                rule.get('ignorance', 1.0),
                rule.get('num_activated', 0) / 100.0,  # 归一化
            ]
            # 添加mass向量
            mass = rule.get('mass', np.zeros(self.num_classes))
            feat.extend(mass.tolist())
            features.append(feat)

        features = torch.tensor(features, dtype=torch.float32, device=device)
        return self.encoder(features)


class SampleToRuleConv(MessagePassing):
    """
    样本到规则的消息传递层
    聚合被规则激活的样本信息到规则节点
    """

    def __init__(self, sample_dim: int, rule_dim: int, out_dim: int):
        super(SampleToRuleConv, self).__init__(aggr='mean')
        self.lin_sample = nn.Linear(sample_dim, out_dim)
        self.lin_rule = nn.Linear(rule_dim, out_dim)
        self.lin_edge = nn.Linear(1, out_dim)  # 激活度作为边特征
        self.out_dim = out_dim

    def forward(self, x_sample: torch.Tensor, x_rule: torch.Tensor,
                edge_index: torch.Tensor, edge_attr: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x_sample: 样本特征 [num_samples, sample_dim]
            x_rule: 规则特征 [num_rules, rule_dim]
            edge_index: 边索引 [2, num_edges] (sample -> rule)
            edge_attr: 边属性（激活度） [num_edges, 1]

        Returns:
            updated_rule: 更新后的规则特征 [num_rules, out_dim]
        """
        # 变换样本和规则特征
        x_sample_proj = self.lin_sample(x_sample)

        # 消息传递
        out = self.propagate(edge_index, x=x_sample_proj, edge_attr=edge_attr,
                             size=(x_sample.size(0), x_rule.size(0)))

        # 残差连接
        out = out + self.lin_rule(x_rule)
        return out

    def message(self, x_j: torch.Tensor, edge_attr: torch.Tensor) -> torch.Tensor:
        # 使用激活度加权样本信息
        edge_weight = torch.sigmoid(self.lin_edge(edge_attr))
        return x_j * edge_weight


class RuleToSampleConv(MessagePassing):
    """
    规则到样本的消息传递层
    将规则的预测信息传递给样本
    """

    def __init__(self, rule_dim: int, sample_dim: int, out_dim: int):
        super(RuleToSampleConv, self).__init__(aggr='mean')
        self.lin_rule = nn.Linear(rule_dim, out_dim)
        self.lin_sample = nn.Linear(sample_dim, out_dim)
        self.lin_edge = nn.Linear(1, out_dim)
        self.out_dim = out_dim

    def forward(self, x_rule: torch.Tensor, x_sample: torch.Tensor,
                edge_index: torch.Tensor, edge_attr: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x_rule: 规则特征 [num_rules, rule_dim]
            x_sample: 样本特征 [num_samples, sample_dim]
            edge_index: 边索引 [2, num_edges] (rule -> sample)
            edge_attr: 边属性（激活度） [num_edges, 1]

        Returns:
            updated_sample: 更新后的样本特征 [num_samples, out_dim]
        """
        x_rule_proj = self.lin_rule(x_rule)

        out = self.propagate(edge_index, x=x_rule_proj, edge_attr=edge_attr,
                             size=(x_rule.size(0), x_sample.size(0)))

        out = out + self.lin_sample(x_sample)
        return out

    def message(self, x_j: torch.Tensor, edge_attr: torch.Tensor) -> torch.Tensor:
        edge_weight = torch.sigmoid(self.lin_edge(edge_attr))
        return x_j * edge_weight


class RuleSelectionGNN(nn.Module):
    """
    规则选择异构图神经网络

    网络结构：
    1. 编码层：将样本和规则编码为向量
    2. 异构消息传递层：样本<->规则双向消息传递
    3. 规则重要性预测层：预测每条规则的选择概率
    4. 分类层：基于选中规则进行分类
    """

    def __init__(self, sample_dim: int, num_classes: int,
                 hidden_dim: int = 64, rule_feat_dim: int = 32,
                 num_layers: int = 2, dropout: float = 0.3,
                 sparsity_weight: float = 0.1):
        """
        Args:
            sample_dim: 样本特征维度
            num_classes: 类别数
            hidden_dim: 隐藏层维度
            rule_feat_dim: 规则特征维度
            num_layers: 消息传递层数
            dropout: Dropout率
            sparsity_weight: 稀疏性正则化权重（控制规则选择的稀疏程度）
        """
        super(RuleSelectionGNN, self).__init__()

        self.num_classes = num_classes
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.dropout = dropout
        self.sparsity_weight = sparsity_weight

        # 规则编码器
        self.rule_encoder = HeteroRuleEncoder(num_classes, rule_feat_dim)

        # 样本特征变换
        self.sample_transform = nn.Sequential(
            nn.Linear(sample_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        # 规则特征变换
        self.rule_transform = nn.Sequential(
            nn.Linear(rule_feat_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        # 异构消息传递层
        self.s2r_convs = nn.ModuleList()
        self.r2s_convs = nn.ModuleList()
        for _ in range(num_layers):
            self.s2r_convs.append(SampleToRuleConv(hidden_dim, hidden_dim, hidden_dim))
            self.r2s_convs.append(RuleToSampleConv(hidden_dim, hidden_dim, hidden_dim))

        # 规则重要性预测（输出每条规则的选择分数）
        self.rule_importance = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )

        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, num_classes)
        )

    def build_hetero_graph(self, activation_matrix: np.ndarray,
                           device: str = 'cpu') -> Tuple[torch.Tensor, torch.Tensor]:
        """
        构建异构图的边索引和边属性

        Args:
            activation_matrix: 激活矩阵 [num_samples, num_rules]
            device: 计算设备

        Returns:
            edge_index_s2r: 样本->规则的边索引 [2, num_edges]
            edge_attr_s2r: 边属性（激活度） [num_edges, 1]
        """
        # 找到所有非零激活
        sample_indices, rule_indices = np.where(activation_matrix > 0)
        activations = activation_matrix[sample_indices, rule_indices]

        # 样本->规则 边
        edge_index_s2r = torch.tensor(
            np.stack([sample_indices, rule_indices], axis=0),
            dtype=torch.long, device=device
        )
        edge_attr_s2r = torch.tensor(
            activations.reshape(-1, 1),
            dtype=torch.float32, device=device
        )

        return edge_index_s2r, edge_attr_s2r

    def forward(self, sample_features: torch.Tensor, rules: List[Dict],
                activation_matrix: np.ndarray, return_selection: bool = False):
        """
        前向传播

        Args:
            sample_features: 样本特征 [num_samples, sample_dim]
            rules: 规则列表
            activation_matrix: 激活矩阵 [num_samples, num_rules]
            return_selection: 是否返回规则选择信息

        Returns:
            logits: 分类logits [num_samples, num_classes]
            rule_scores: 规则重要性分数 [num_rules] (if return_selection)
            selected_mask: 选中的规则掩码 [num_rules] (if return_selection)
        """
        device = sample_features.device
        num_samples = sample_features.size(0)
        num_rules = len(rules)

        if num_rules == 0:
            # 没有规则，直接用样本特征分类
            x_sample = self.sample_transform(sample_features)
            logits = self.classifier(x_sample)
            if return_selection:
                return logits, torch.tensor([]), torch.tensor([])
            return logits

        # 1. 编码规则
        x_rule = self.rule_encoder(rules, device)  # [num_rules, rule_feat_dim]
        x_rule = self.rule_transform(x_rule)  # [num_rules, hidden_dim]

        # 2. 变换样本特征
        x_sample = self.sample_transform(sample_features)  # [num_samples, hidden_dim]

        # 3. 构建异构图
        edge_index_s2r, edge_attr_s2r = self.build_hetero_graph(activation_matrix, device)

        # 规则->样本的边（反向边）
        edge_index_r2s = edge_index_s2r.flip(0)
        edge_attr_r2s = edge_attr_s2r

        # 4. 异构消息传递
        for i in range(self.num_layers):
            # 样本 -> 规则
            x_rule_new = self.s2r_convs[i](x_sample, x_rule, edge_index_s2r, edge_attr_s2r)
            x_rule_new = F.relu(x_rule_new)
            x_rule_new = F.dropout(x_rule_new, p=self.dropout, training=self.training)

            # 规则 -> 样本
            x_sample_new = self.r2s_convs[i](x_rule, x_sample, edge_index_r2s, edge_attr_r2s)
            x_sample_new = F.relu(x_sample_new)
            x_sample_new = F.dropout(x_sample_new, p=self.dropout, training=self.training)

            x_rule = x_rule_new
            x_sample = x_sample_new

        # 5. 预测规则重要性分数
        rule_scores = self.rule_importance(x_rule).squeeze(-1)  # [num_rules]

        # 可微分的二值规则选择（Straight-Through Bernoulli Estimator）
        # 训练时：sigmoid 前向 + 直通梯度估计
        # 推理时：硬阈值选择
        selection_probs = torch.sigmoid(rule_scores)

        if self.training:
            # Straight-through estimator: 前向用硬选择，反向用 sigmoid 梯度
            hard_selection = (selection_probs > 0.5).float()
            # straight-through: 前向用 hard_selection，梯度流过 selection_probs
            selection_weights = hard_selection - selection_probs.detach() + selection_probs
        else:
            selection_weights = (selection_probs > 0.5).float()

        # 6. 根据规则选择权重加权规则对样本的影响
        # 构建加权的规则表示传递给样本
        weighted_rule_influence = self._compute_weighted_rule_influence(
            x_rule, selection_weights, activation_matrix, device
        )

        # 7. 融合样本特征和规则影响进行分类
        x_final = x_sample + weighted_rule_influence
        logits = self.classifier(x_final)

        if return_selection:
            # 计算选中的规则（阈值0.5）
            with torch.no_grad():
                selected_mask = (selection_weights > 0.5).float()
            return logits, rule_scores, selected_mask

        return logits

    def _compute_weighted_rule_influence(self, x_rule: torch.Tensor,
                                         selection_weights: torch.Tensor,
                                         activation_matrix: np.ndarray,
                                         device: str) -> torch.Tensor:
        """
        计算加权的规则对样本的影响

        Args:
            x_rule: 规则特征 [num_rules, hidden_dim]
            selection_weights: 规则选择权重 [num_rules]
            activation_matrix: 激活矩阵 [num_samples, num_rules]
            device: 设备

        Returns:
            influence: 规则对样本的加权影响 [num_samples, hidden_dim]
        """
        num_samples = activation_matrix.shape[0]
        num_rules = x_rule.size(0)

        # 激活矩阵转为tensor
        activation = torch.tensor(activation_matrix, dtype=torch.float32, device=device)

        # 加权激活 = 激活度 * 规则选择权重
        weighted_activation = activation * selection_weights.unsqueeze(0)  # [num_samples, num_rules]

        # 归一化
        activation_sum = weighted_activation.sum(dim=1, keepdim=True) + 1e-12
        weighted_activation = weighted_activation / activation_sum

        # 聚合规则特征
        influence = torch.matmul(weighted_activation, x_rule)  # [num_samples, hidden_dim]

        return influence

    def compute_loss(self, logits: torch.Tensor, labels: torch.Tensor,
                     rule_scores: torch.Tensor, target_sparsity: float = 0.5) -> Tuple[torch.Tensor, Dict]:
        """
        计算总损失（分类损失 + 稀疏性正则化）

        改进：使用 BCE 形式的稀疏性惩罚代替原来的 MSE + L1 组合。
        BCE 惩罚对称地将平均选择概率拉向目标稀疏度，不会像 L1 那样
        一味地将所有规则推向"不选择"。

        Args:
            logits: 分类logits [num_samples, num_classes]
            labels: 真实标签 [num_samples]
            rule_scores: 规则重要性分数 [num_rules]
            target_sparsity: 目标稀疏度（希望保留的规则比例）

        Returns:
            total_loss: 总损失
            loss_dict: 各项损失
        """
        # 分类损失
        cls_loss = F.cross_entropy(logits, labels)

        # 稀疏性正则化：BCE 形式
        # 将平均选择概率拉向 target_sparsity
        if len(rule_scores) > 0:
            selection_probs = torch.sigmoid(rule_scores)
            mean_prob = selection_probs.mean()
            # BCE(mean_prob, target) = -[t*log(p) + (1-t)*log(1-p)]
            target_t = torch.tensor(target_sparsity, device=logits.device)
            sparsity_loss = F.binary_cross_entropy(
                mean_prob.clamp(1e-6, 1 - 1e-6), target_t
            )

            total_loss = cls_loss + self.sparsity_weight * sparsity_loss
        else:
            sparsity_loss = torch.tensor(0.0, device=logits.device)
            total_loss = cls_loss

        loss_dict = {
            'cls_loss': cls_loss.item(),
            'sparsity_loss': sparsity_loss.item() if isinstance(sparsity_loss, torch.Tensor) else sparsity_loss,
            'total_loss': total_loss.item()
        }

        return total_loss, loss_dict


class RuleSelector:
    """
    规则自动选择器

    使用异构图神经网络自动选择最优规则子集，
    在保证分类精度的同时最小化规则库规模。
    """

    def __init__(self, sample_dim: int, num_classes: int,
                 hidden_dim: int = 64, rule_feat_dim: int = 32,
                 num_layers: int = 2, sparsity_weight: float = 0.1,
                 target_sparsity: float = 0.5, device: str = 'cpu'):
        """
        Args:
            sample_dim: 样本特征维度
            num_classes: 类别数
            hidden_dim: 隐藏层维度
            rule_feat_dim: 规则特征维度
            num_layers: GNN层数
            sparsity_weight: 稀疏性正则化权重
            target_sparsity: 目标规则保留比例
            device: 计算设备
        """
        self.device = device
        self.target_sparsity = target_sparsity
        self.num_classes = num_classes

        self.gnn = RuleSelectionGNN(
            sample_dim=sample_dim,
            num_classes=num_classes,
            hidden_dim=hidden_dim,
            rule_feat_dim=rule_feat_dim,
            num_layers=num_layers,
            sparsity_weight=sparsity_weight
        ).to(device)

        self.optimizer = None
        self.selected_rules = []
        self.selection_scores = None

    def setup_optimizer(self, lr: float = 0.001, weight_decay: float = 1e-4):
        """设置优化器"""
        self.optimizer = torch.optim.Adam(
            self.gnn.parameters(), lr=lr, weight_decay=weight_decay
        )

    def fit(self, sample_features: np.ndarray, labels: np.ndarray,
            rules: List[Dict], activation_matrix: np.ndarray,
            num_epochs: int = 100, patience: int = 20,
            verbose: bool = True) -> List[Dict]:
        """
        训练规则选择器并返回选中的规则

        Args:
            sample_features: 样本特征 [num_samples, sample_dim]
            labels: 标签 [num_samples]
            rules: 候选规则列表
            activation_matrix: 激活矩阵 [num_samples, num_rules]
            num_epochs: 训练轮数
            patience: 早停耐心值
            verbose: 是否打印训练信息

        Returns:
            selected_rules: 选中的规则列表
        """
        if len(rules) == 0:
            print(">> 没有候选规则，跳过规则选择")
            return []

        if self.optimizer is None:
            self.setup_optimizer()

        # 转换为tensor
        x = torch.tensor(sample_features, dtype=torch.float32, device=self.device)
        y = torch.tensor(labels, dtype=torch.long, device=self.device)

        # 分析规则的类别分布
        unique_classes = np.unique(labels)
        class_counts = {c: (labels == c).sum() for c in unique_classes}
        minority_class = min(class_counts, key=class_counts.get)

        # 按预测类别分组规则
        minority_rule_indices = []
        majority_rule_indices = []
        for i, rule in enumerate(rules):
            pred_class = rule.get('predicted_class', 0)
            if pred_class == minority_class:
                minority_rule_indices.append(i)
            else:
                majority_rule_indices.append(i)

        if verbose:
            print(f"\n>> 开始规则选择优化 (候选规则: {len(rules)}条, 目标保留比例: {self.target_sparsity:.1%})")
            print(f"   少数类规则: {len(minority_rule_indices)}条, 多数类规则: {len(majority_rule_indices)}条")

        best_loss = float('inf')
        patience_counter = 0
        best_selection = None

        for epoch in range(num_epochs):
            self.gnn.train()
            self.optimizer.zero_grad()

            # 前向传播
            logits, rule_scores, _ = self.gnn(x, rules, activation_matrix, return_selection=True)

            # 计算损失
            loss, loss_dict = self.gnn.compute_loss(logits, y, rule_scores, self.target_sparsity)

            # 反向传播
            loss.backward()
            self.optimizer.step()

            # 早停检查
            if loss.item() < best_loss:
                best_loss = loss.item()
                patience_counter = 0
                # 保存最佳选择
                with torch.no_grad():
                    selection_probs = torch.sigmoid(rule_scores).cpu().numpy()
                    best_selection = selection_probs
            else:
                patience_counter += 1

            if patience_counter >= patience:
                if verbose:
                    print(f"   早停于epoch {epoch+1}")
                break

            if verbose and (epoch + 1) % 20 == 0:
                with torch.no_grad():
                    selection_probs = torch.sigmoid(rule_scores)
                    num_selected = (selection_probs > 0.5).sum().item()
                    acc = (logits.argmax(dim=1) == y).float().mean().item()
                print(f"   Epoch {epoch+1}: Loss={loss.item():.4f}, "
                      f"Acc={acc:.4f}, Selected={num_selected}/{len(rules)}")

        # 最终选择
        self.selection_scores = best_selection if best_selection is not None else np.zeros(len(rules))

        # ========== 类别平衡的规则选择策略 ==========
        # 确保少数类和多数类规则都被保留

        target_total = max(3, int(len(rules) * self.target_sparsity))

        # 计算每个类别应该保留的规则数（按比例分配，但确保少数类有足够规则）
        if len(minority_rule_indices) > 0 and len(majority_rule_indices) > 0:
            # 至少保留30%的名额给少数类规则（或全部少数类规则如果数量少）
            min_minority_quota = max(1, min(len(minority_rule_indices), int(target_total * 0.4)))
            min_majority_quota = max(1, target_total - min_minority_quota)

            # 在少数类规则中选择得分最高的
            minority_scores = [(i, self.selection_scores[i]) for i in minority_rule_indices]
            minority_scores.sort(key=lambda x: x[1], reverse=True)
            selected_minority = [idx for idx, _ in minority_scores[:min_minority_quota]]

            # 在多数类规则中选择得分最高的
            majority_scores = [(i, self.selection_scores[i]) for i in majority_rule_indices]
            majority_scores.sort(key=lambda x: x[1], reverse=True)
            selected_majority = [idx for idx, _ in majority_scores[:min_majority_quota]]

            selected_indices = selected_minority + selected_majority

            if verbose:
                print(f"   类别平衡选择: 少数类规则 {len(selected_minority)}条, 多数类规则 {len(selected_majority)}条")
        else:
            # 只有单一类别的规则，直接按分数选择
            selected_indices = np.where(self.selection_scores > 0.5)[0].tolist()

            # 如果选择太少，至少保留top-k
            min_rules = max(3, int(len(rules) * 0.1))
            if len(selected_indices) < min_rules:
                selected_indices = np.argsort(self.selection_scores)[-min_rules:].tolist()

        self.selected_rules = [rules[i] for i in selected_indices]

        if verbose:
            # 统计选中规则的类别分布
            selected_minority_count = sum(1 for r in self.selected_rules if r.get('predicted_class', 0) == minority_class)
            selected_majority_count = len(self.selected_rules) - selected_minority_count
            print(f"\n>> 规则选择完成: {len(rules)} -> {len(self.selected_rules)} 条规则")
            print(f"   选中少数类规则: {selected_minority_count}条, 选中多数类规则: {selected_majority_count}条")
            print(f"   压缩率: {1 - len(self.selected_rules)/len(rules):.1%}")

        return self.selected_rules

    def get_selection_scores(self) -> np.ndarray:
        """获取规则选择分数"""
        return self.selection_scores if self.selection_scores is not None else np.array([])

    @torch.no_grad()
    def evaluate(self, sample_features: np.ndarray, labels: np.ndarray,
                 rules: List[Dict], activation_matrix: np.ndarray) -> Dict:
        """
        评估规则选择后的分类性能

        Args:
            sample_features: 样本特征
            labels: 标签
            rules: 规则列表
            activation_matrix: 激活矩阵

        Returns:
            metrics: 评估指标
        """
        self.gnn.eval()

        x = torch.tensor(sample_features, dtype=torch.float32, device=self.device)
        y = torch.tensor(labels, dtype=torch.long, device=self.device)

        logits, rule_scores, selected_mask = self.gnn(x, rules, activation_matrix, return_selection=True)

        preds = logits.argmax(dim=1)
        acc = (preds == y).float().mean().item()

        from sklearn.metrics import f1_score
        f1 = f1_score(y.cpu().numpy(), preds.cpu().numpy(), average='macro', zero_division=0)

        num_selected = (torch.sigmoid(rule_scores) > 0.5).sum().item() if len(rule_scores) > 0 else 0

        return {
            'accuracy': acc,
            'f1_macro': f1,
            'num_rules_original': len(rules),
            'num_rules_selected': num_selected,
            'compression_ratio': 1 - num_selected / len(rules) if len(rules) > 0 else 0
        }



