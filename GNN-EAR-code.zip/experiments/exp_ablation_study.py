"""
Experiment 4.3: GNN-EAR 消融实验.

"""

import argparse
import os
import sys
import time
import traceback

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from experiments.exp_utils import (
    METRICS,
    N_FOLDS,
    REPRESENTATIVE_DATASETS,
    SEEDS,
    compute_summary,
    prepare_data,
    run_full_rg_gnn_earc,
    save_results_csv,
    setup_experiment_env,
)


ABLATION_VARIANTS = {
    'Full': {
        'description': 'Full GNN-EAR',
        'lambda_rule': 0.3,
        'use_ds_fusion': True,
        'enable_rule_selection': True,
        'num_synthetic_override': None,
    },
    'Variant-A': {
        'description': r'w/o $\mathcal{L}_{rule}$',
        'lambda_rule': 0.0,
        'use_ds_fusion': True,
        'enable_rule_selection': True,
        'num_synthetic_override': None,
    },
    'Variant-B': {
        'description': 'w/o Rule Selection',
        'lambda_rule': 0.3,
        'use_ds_fusion': True,
        'enable_rule_selection': False,
        'num_synthetic_override': None,
    },
    'Variant-C': {
        'description': 'w/o Decision Fusion (alpha*=1)',
        'lambda_rule': 0.3,
        'use_ds_fusion': False,
        'enable_rule_selection': True,
        'num_synthetic_override': None,
    },
    'Variant-D': {
        'description': 'w/o Oversampling',
        'lambda_rule': 0.3,
        'use_ds_fusion': True,
        'enable_rule_selection': True,
        'num_synthetic_override': 0,
    },
}


VARIANT_DISPLAY_NAMES = {
    'Full': 'Full Model',
    'Variant-A': r'w/o $\mathcal{L}_{rule}$',
    'Variant-B': 'w/o Rule Selection',
    'Variant-C': 'w/o Decision Fusion',
    'Variant-D': 'w/o Oversampling',
}


def _to_serializable_scalar(value):

    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, (str, int, float, bool)):
        return value
    return None


def build_ablation_record(dataset_name, variant_name, variant_config,
                          repeat_idx, fold, seed, data_dict, results):

    record = {
        'dataset': dataset_name,
        'variant': variant_name,
        'variant_label': VARIANT_DISPLAY_NAMES.get(variant_name, variant_name),
        'variant_description': variant_config['description'],
        'repeat': repeat_idx,
        'fold': fold,
        'seed': seed,
        'imbalance_ratio': data_dict['imbalance_ratio'],
    }

    for key, value in results.items():
        scalar_value = _to_serializable_scalar(value)
        if scalar_value is not None:
            record[key] = scalar_value

    for metric in METRICS:
        record.setdefault(metric, 0.0)
    record.setdefault('accuracy', 0.0)
    return record


def collect_coverage(summary_df, datasets, variants):

    coverage_records = []
    complete_datasets = []

    for dataset_name in datasets:
        dataset_complete = True
        for variant_name in variants:
            mask = (
                (summary_df['dataset'] == dataset_name) &
                (summary_df['variant'] == variant_name)
            )
            completed = int(len(summary_df[mask]) > 0)
            coverage_records.append({
                'dataset': dataset_name,
                'variant': variant_name,
                'variant_label': VARIANT_DISPLAY_NAMES.get(variant_name, variant_name),
                'completed': completed,
            })
            dataset_complete = dataset_complete and bool(completed)

        if dataset_complete:
            complete_datasets.append(dataset_name)

    return pd.DataFrame(coverage_records), complete_datasets


def generate_metadata_summary(results_df):

    numeric_cols = [
        col for col in [
            'best_alpha',
            'n_rules_stage1',
            'n_rules_fusion_raw',
            'n_rules_final',
            'n_rules_minority',
            'n_rules_majority',
            'rule_selection_target_keep',
        ]
        if col in results_df.columns
    ]

    string_cols = [
        col for col in [
            'rule_selection_status',
            'rule_selection_target_source',
        ]
        if col in results_df.columns
    ]

    if not numeric_cols and not string_cols:
        return None

    group_cols = ['dataset', 'variant', 'variant_label']
    grouped = results_df.groupby(group_cols)

    if numeric_cols:
        summary = grouped[numeric_cols].agg(['mean', 'std']).round(4)
        summary.columns = [f'{col[0]}_{col[1]}' for col in summary.columns]
        summary = summary.reset_index()
    else:
        summary = grouped.size().reset_index(name='run_count')

    if {'n_rules_fusion_raw_mean', 'n_rules_final_mean'}.issubset(summary.columns):
        denom = summary['n_rules_fusion_raw_mean'].replace(0, np.nan)
        compression = 1.0 - (summary['n_rules_final_mean'] / denom)
        summary['rule_compression_ratio_mean'] = (
            compression.replace([np.inf, -np.inf], np.nan).round(4)
        )

    for col in string_cols:
        values_df = grouped[col].agg(
            lambda values: ','.join(sorted(set(str(v) for v in values if pd.notna(v))))
        ).reset_index(name=f'{col}_values')
        summary = summary.merge(values_df, on=group_cols, how='left')

    return summary


def run_ablation_study(datasets=None, n_repeats=10, n_folds=5,
                       output_dir='./experiments/results/ablation'):

    if datasets is None:
        datasets = REPRESENTATIVE_DATASETS

    if n_repeats > len(SEEDS):
        raise ValueError(f"n_repeats={n_repeats} exceeds available seeds ({len(SEEDS)})")
    if n_folds < 2:
        raise ValueError(f"n_folds must be >= 2, got {n_folds}")

    device, timestamp = setup_experiment_env(output_dir)

    variants = list(ABLATION_VARIANTS.keys())
    seeds = SEEDS[:n_repeats]
    total = len(datasets) * len(variants) * n_repeats * n_folds
    current = 0
    all_results = []

    print(f"\n{'=' * 80}")
    print("Experiment 4.3: Ablation Study")
    print(f"Datasets: {datasets}")
    print(f"Variants: {variants}")
    print(f"Total runs: {total}")
    print(f"{'=' * 80}\n")

    start_time = time.time()

    for dataset_name in datasets:
        print(f"\n{'#' * 60}")
        print(f"# Dataset: {dataset_name}")
        print(f"{'#' * 60}")

        for repeat_idx, seed in enumerate(seeds):
            for fold in range(n_folds):
                try:
                    data_dict = prepare_data(
                        dataset_name, fold, seed, device, n_folds=n_folds
                    )
                except Exception as exc:
                    print(f"  Data loading failed: {exc}")
                    continue

                for variant_name in variants:
                    current += 1
                    progress = f"[{current}/{total}]"
                    variant_config = ABLATION_VARIANTS[variant_name]

                    try:
                        results, _, _ = run_full_rg_gnn_earc(
                            data_dict, device, seed,
                            lambda_rule=variant_config['lambda_rule'],
                            use_ds_fusion=variant_config['use_ds_fusion'],
                            enable_rule_selection=variant_config['enable_rule_selection'],
                            num_synthetic_override=variant_config['num_synthetic_override'],
                        )

                        record = build_ablation_record(
                            dataset_name=dataset_name,
                            variant_name=variant_name,
                            variant_config=variant_config,
                            repeat_idx=repeat_idx,
                            fold=fold,
                            seed=seed,
                            data_dict=data_dict,
                            results=results,
                        )
                        all_results.append(record)
                        print(
                            f"  {progress} {variant_name:12s} | {dataset_name:15s} | "
                            f"F1m={record['f1_macro']:.4f} GM={record['gmean']:.4f}"
                        )
                    except Exception as exc:
                        print(f"  {progress} {variant_name} | {dataset_name} | failed: {str(exc)[:120]}")
                        traceback.print_exc()
                        continue

                if all_results:
                    temp_df = pd.DataFrame(all_results)
                    temp_df.to_csv(
                        os.path.join(output_dir, f'results_temp_{timestamp}.csv'),
                        index=False
                    )

    elapsed = time.time() - start_time
    print(f"\nAblation study finished in {elapsed / 3600:.1f} hours")

    if not all_results:
        print("Warning: no successful ablation results were produced.")
        return None

    results_df = save_results_csv(
        all_results,
        os.path.join(output_dir, f'complete_results_{timestamp}.csv')
    )

    summary = compute_summary(results_df, group_cols=['dataset', 'variant'])
    summary.to_csv(os.path.join(output_dir, f'summary_{timestamp}.csv'), index=False)

    coverage_df, complete_datasets = collect_coverage(summary, datasets, variants)
    coverage_path = os.path.join(output_dir, f'coverage_{timestamp}.csv')
    coverage_df.to_csv(coverage_path, index=False)

    metadata_summary = generate_metadata_summary(results_df)
    if metadata_summary is not None:
        metadata_summary.to_csv(
            os.path.join(output_dir, f'metadata_summary_{timestamp}.csv'),
            index=False
        )

    print(f"\n{'=' * 80}")
    print("Ablation Summary")
    print(f"{'=' * 80}")

    dataset_ir = results_df.groupby('dataset')['imbalance_ratio'].mean().to_dict()
    for dataset_name in datasets:
        ds_summary = summary[summary['dataset'] == dataset_name]
        if len(ds_summary) == 0:
            continue

        print(f"\n  {dataset_name} (IR={dataset_ir.get(dataset_name, float('nan')):.1f}):")
        full_row = ds_summary[ds_summary['variant'] == 'Full']

        for variant_name in variants:
            variant_row = ds_summary[ds_summary['variant'] == variant_name]
            if len(variant_row) == 0:
                continue

            row = variant_row.iloc[0]
            line = f"    {variant_name:12s}: "
            for metric in METRICS:
                mean_val = row[f'{metric}_mean']
                std_val = row[f'{metric}_std']
                if len(full_row) > 0 and variant_name != 'Full':
                    full_mean = full_row[f'{metric}_mean'].values[0]
                    delta = mean_val - full_mean
                    sign = '+' if delta >= 0 else ''
                    line += f"{metric}={mean_val:.4f} ({sign}{delta:.4f}) "
                else:
                    line += f"{metric}={mean_val:.4f}±{std_val:.4f} "
            print(line)

    missing_rows = coverage_df[coverage_df['completed'] == 0]
    if len(missing_rows) > 0:
        print(f"\n[WARN] Incomplete ablation coverage detected. Details saved to: {coverage_path}")
        for _, row in missing_rows.iterrows():
            print(f"       - missing: {row['dataset']} / {row['variant']}")

    if complete_datasets:
        print(f"\nComplete datasets for Table II / Figure 1: {complete_datasets}")
    else:
        print("\n[WARN] No dataset completed all variants; Table II will fall back to available rows.")

    latex_table = generate_table_II(
        summary, variants, datasets, complete_datasets=complete_datasets
    )
    latex_path = os.path.join(output_dir, f'table_II_{timestamp}.tex')
    with open(latex_path, 'w', encoding='utf-8') as file_obj:
        file_obj.write(latex_table)
    print(f"\nTable II saved to: {latex_path}")

    try:
        generate_ablation_bar_chart(
            summary, variants, datasets,
            os.path.join(output_dir, f'ablation_bar_chart_{timestamp}.pdf'),
            complete_datasets=complete_datasets,
        )
    except Exception as exc:
        print(f"Bar chart generation failed: {exc}")

    return results_df


def generate_table_II(summary_df, variants, datasets, complete_datasets=None):

    if complete_datasets:
        table_datasets = list(complete_datasets)
    else:
        table_datasets = [
            ds for ds in datasets
            if len(summary_df[summary_df['dataset'] == ds]) > 0
        ]

    omitted_datasets = [ds for ds in datasets if ds not in table_datasets]
    caption = (
        "Ablation study results on representative datasets. "
        "Each entry reports mean and standard deviation over completed runs; "
        "values in parentheses denote the change relative to the full model."
    )
    if omitted_datasets:
        caption += " Datasets with incomplete variant coverage are omitted from the condensed table."

    latex = (
        r"\begin{table}[htbp]" "\n"
        r"\centering" "\n"
        f"\\caption{{{caption}}}\n"
        r"\label{tab:ablation}" "\n"
        r"\resizebox{\linewidth}{!}{%" "\n"
        r"\begin{tabular}{ll" + ("c" * len(METRICS)) + r"}" "\n"
        r"\toprule" "\n"
        "Dataset & Variant & " + " & ".join([
            {'f1_macro': '$F1_{macro}$', 'f1_minority': '$F1_{min}$',
             'auc': 'AUC', 'gmean': 'G-Mean'}[metric]
            for metric in METRICS
        ]) + r" \\" + "\n"
        r"\midrule" "\n"
    )

    for dataset_name in table_datasets:
        ds_data = summary_df[summary_df['dataset'] == dataset_name]
        if len(ds_data) == 0:
            continue

        full_data = ds_data[ds_data['variant'] == 'Full']
        first_row = True

        for variant_name in variants:
            variant_data = ds_data[ds_data['variant'] == variant_name]
            if len(variant_data) == 0:
                continue

            ds_label = dataset_name if first_row else ""
            first_row = False
            row = f"{ds_label:15s} & {VARIANT_DISPLAY_NAMES.get(variant_name, variant_name):22s}"

            for metric in METRICS:
                mean_val = variant_data[f'{metric}_mean'].values[0]
                std_val = variant_data[f'{metric}_std'].values[0]
                cell = f"${mean_val:.3f}_{{\\pm{std_val:.3f}}}$"
                if variant_name != 'Full' and len(full_data) > 0:
                    full_mean = full_data[f'{metric}_mean'].values[0]
                    delta = mean_val - full_mean
                    sign = '+' if delta >= 0 else ''
                    cell += f" ({sign}{delta:.3f})"
                row += f" & {cell}"

            row += r" \\" + "\n"
            latex += row

        latex += r"\midrule" + "\n"

    latex += (
        r"\bottomrule" "\n"
        r"\end{tabular}%" "\n"
        r"}" "\n"
        r"\end{table}" "\n"
    )
    return latex


def generate_ablation_bar_chart(summary_df, variants, datasets, save_path, complete_datasets=None):

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    plot_datasets = list(complete_datasets) if complete_datasets else [
        ds for ds in datasets
        if len(summary_df[summary_df['dataset'] == ds]) > 0
    ]
    if not plot_datasets:
        raise ValueError("No ablation data available for plotting.")

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    title = 'Ablation Study Results'
    if complete_datasets and len(complete_datasets) < len(datasets):
        title += ' (Complete Datasets Only)'
    fig.suptitle(title, fontsize=16, fontweight='bold')

    colors = ['#2196F3', '#FF9800', '#4CAF50', '#F44336', '#9C27B0']

    for ax_idx, metric in enumerate(METRICS):
        ax = axes[ax_idx // 2][ax_idx % 2]

        metric_label = {
            'f1_macro': 'F1-Macro',
            'f1_minority': 'F1-Minority',
            'auc': 'AUC',
            'gmean': 'G-Mean',
        }.get(metric, metric)

        x = np.arange(len(plot_datasets))
        width = 0.15
        n_variants = len(variants)

        for variant_idx, variant_name in enumerate(variants):
            means = []
            stds = []
            for dataset_name in plot_datasets:
                mask = (
                    (summary_df['dataset'] == dataset_name) &
                    (summary_df['variant'] == variant_name)
                )
                subset = summary_df[mask]
                if len(subset) > 0:
                    means.append(subset[f'{metric}_mean'].values[0])
                    stds.append(subset[f'{metric}_std'].values[0])
                else:
                    means.append(np.nan)
                    stds.append(np.nan)

            offset = (variant_idx - n_variants / 2 + 0.5) * width
            ax.bar(
                x + offset, means, width, yerr=stds,
                label=VARIANT_DISPLAY_NAMES.get(variant_name, variant_name),
                color=colors[variant_idx % len(colors)],
                alpha=0.85,
                capsize=2,
            )

        ax.set_xlabel('Dataset')
        ax.set_ylabel(metric_label)
        ax.set_title(metric_label)
        ax.set_xticks(x)
        ax.set_xticklabels(plot_datasets, rotation=30, ha='right', fontsize=8)
        ax.legend(fontsize=7, loc='lower left')
        ax.grid(axis='y', alpha=0.3)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Ablation bar chart saved to: {save_path}")


def main():
    parser = argparse.ArgumentParser(description='Experiment 4.3: Ablation Study')
    parser.add_argument(
        '--datasets', nargs='+', default=None,
        help='Dataset list. Default uses the representative datasets.'
    )
    parser.add_argument(
        '--n_repeats', type=int, default=5,
        help='Number of repeated runs (default: 5).'
    )
    parser.add_argument(
        '--n_folds', type=int, default=N_FOLDS,
        help=f'Number of CV folds (default: {N_FOLDS}).'
    )
    parser.add_argument(
        '--output_dir', type=str, default='./experiments/results/ablation',
        help='Output directory.'
    )
    parser.add_argument(
        '--quick', action='store_true',
        help='Quick smoke test mode.'
    )

    args = parser.parse_args()

    if args.quick:
        args.datasets = args.datasets or ['ecoli1', 'yeast3']
        args.n_repeats = 2
        args.n_folds = 3

    run_ablation_study(
        datasets=args.datasets,
        n_repeats=args.n_repeats,
        n_folds=args.n_folds,
        output_dir=args.output_dir,
    )


if __name__ == "__main__":
    main()
