"""
主控脚本 - 顺序运行所有实验

"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import argparse
import time
from datetime import datetime


def run_main_comparison(args):
    """运行实验4.2: 主对比实验"""
    from experiments.exp_main_comparison import run_main_comparison as _run

    kwargs = {
        'output_dir': os.path.join(args.output_base, 'main_comparison'),
        'n_repeats': args.n_repeats,
        'n_folds': args.n_folds,
    }
    if args.datasets:
        kwargs['datasets'] = args.datasets

    return _run(**kwargs)


def run_ablation(args):
    """运行实验4.3: 消融实验"""
    from experiments.exp_ablation_study import run_ablation_study

    kwargs = {
        'output_dir': os.path.join(args.output_base, 'ablation'),
        'n_repeats': args.n_repeats,
        'n_folds': args.n_folds,
    }
    if args.datasets:
        kwargs['datasets'] = args.datasets

    return run_ablation_study(**kwargs)


def run_sensitivity(args):
    """运行实验4.4: 超参数敏感性分析"""
    from experiments.exp_hyperparameter_sensitivity import run_sensitivity_analysis

    kwargs = {
        'output_dir': os.path.join(args.output_base, 'sensitivity'),
        'n_repeats': args.n_repeats,
        'n_folds': args.n_folds,
    }
    if args.datasets:
        kwargs['datasets'] = args.datasets

    return run_sensitivity_analysis(**kwargs)

# 实验注册表
EXPERIMENTS = {
    'main': {
        'name': '4.2 主对比实验',
        'func': run_main_comparison,
        'description': 'GNN-EAR vs 8种基线方法在14个KEEL数据集上的全面对比'
    },
    'ablation': {
        'name': '4.3 消融实验',
        'func': run_ablation,
        'description': '4种降级变体的模块贡献量化'
    },
    'sensitivity': {
        'name': '4.4 超参数敏感性',
        'func': run_sensitivity,
        'description': 'α*融合权重和λ_rule规则惩罚的敏感性分析'
    }
}


def main():
    parser = argparse.ArgumentParser(
        description='GNN-EAR 完整实验套件',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python run_all_experiments.py                          # 运行全部实验
  python run_all_experiments.py --quick                  # 快速测试（少量数据集和重复）
  python run_all_experiments.py --skip-main              # 跳过主对比实验
  python run_all_experiments.py --skip-main --skip-viz   # 只运行消融和敏感性
  python run_all_experiments.py --only ablation          # 只运行消融实验
  python run_all_experiments.py --only main sensitivity  # 只运行主对比和敏感性
  python run_all_experiments.py --datasets ecoli1 yeast3 # 指定数据集
        """
    )

    parser.add_argument('--output_base', type=str,
                        default='./experiments/results',
                        help='实验结果根目录')
    parser.add_argument('--n_repeats', type=int, default=10,
                        help='重复次数（默认10）')
    parser.add_argument('--n_folds', type=int, default=5,
                        help='交叉验证折数（默认5）')
    parser.add_argument('--datasets', nargs='+', default=None,
                        help='指定数据集（覆盖每个实验的默认选择）')

    # 跳过选项
    parser.add_argument('--skip-main', action='store_true',
                        help='跳过实验4.2（主对比实验）')
    parser.add_argument('--skip-ablation', action='store_true',
                        help='跳过实验4.3（消融实验）')
    parser.add_argument('--skip-sensitivity', action='store_true',
                        help='跳过实验4.4（敏感性分析）')

    # 仅运行选项
    parser.add_argument('--only', nargs='+', default=None,
                        choices=list(EXPERIMENTS.keys()),
                        help='仅运行指定的实验')

    # 快速模式
    parser.add_argument('--quick', action='store_true',
                        help='快速测试模式（2个数据集, 2次重复, 3折）')

    args = parser.parse_args()

    # 快速模式覆盖
    if args.quick:
        args.n_repeats = 2
        args.n_folds = 3
        if args.datasets is None:
            args.datasets = ['ecoli1', 'yeast3']

    # 确定要运行的实验
    if args.only:
        experiments_to_run = args.only
    else:
        experiments_to_run = []
        if not args.skip_main:
            experiments_to_run.append('main')
        if not args.skip_ablation:
            experiments_to_run.append('ablation')
        if not args.skip_sensitivity:
            experiments_to_run.append('sensitivity')
        if not args.skip_viz:
            experiments_to_run.append('visualization')

    if not experiments_to_run:
        print("没有选择任何实验。使用 --help 查看选项。")
        return

    # 打印实验计划
    print(f"\n{'='*80}")
    print(f"GNN-EAR 完整实验套件")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*80}")
    print(f"\n计划运行 {len(experiments_to_run)} 个实验:")
    for key in experiments_to_run:
        exp = EXPERIMENTS[key]
        print(f"  [{key:13s}] {exp['name']}: {exp['description']}")
    print(f"\n设置: n_repeats={args.n_repeats}, n_folds={args.n_folds}")
    if args.datasets:
        print(f"数据集: {args.datasets}")
    if args.quick:
        print("⚡ 快速测试模式")
    print(f"输出目录: {args.output_base}")
    print(f"{'='*80}\n")

    # 逐个运行实验
    total_start = time.time()
    experiment_times = {}

    for key in experiments_to_run:
        exp = EXPERIMENTS[key]
        print(f"\n{'#'*80}")
        print(f"# 开始: {exp['name']}")
        print(f"# {exp['description']}")
        print(f"{'#'*80}\n")

        exp_start = time.time()
        try:
            exp['func'](args)
            exp_elapsed = time.time() - exp_start
            experiment_times[key] = exp_elapsed
            print(f"\n✓ {exp['name']} 完成 (耗时: {exp_elapsed/60:.1f}分钟)")
        except Exception as e:
            exp_elapsed = time.time() - exp_start
            experiment_times[key] = exp_elapsed
            print(f"\n✗ {exp['name']} 失败: {str(e)}")
            import traceback
            traceback.print_exc()

    # 打印总结
    total_elapsed = time.time() - total_start
    print(f"\n{'='*80}")
    print(f"实验套件运行完毕")
    print(f"{'='*80}")
    print(f"\n耗时统计:")
    for key, elapsed in experiment_times.items():
        status = "✓" if elapsed > 0 else "✗"
        print(f"  {status} {EXPERIMENTS[key]['name']:20s}: {elapsed/60:.1f}分钟")
    print(f"  {'总计':22s}: {total_elapsed/60:.1f}分钟 ({total_elapsed/3600:.1f}小时)")
    print(f"\n结果保存在: {os.path.abspath(args.output_base)}")
    print(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    main()

