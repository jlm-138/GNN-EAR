"""
基线方法实现模块
实现experiments.md中Section 4.1.2定义的7种基线方法的简化版本

包含:
1. GCN / GAT: 标准图神经网络（下界）
2. ReNode: 拓扑感知节点重加权
3. TAM: 拓扑感知边际损失
4. GraphSMOTE: 标准潜在空间过采样（无规则约束）
5. GraphENS: 邻居感知自我网络合成
6. GraphSHA: 困难样本合成
7. EARC-only: 纯证据关联规则分类器（在exp_utils中实现）

注意: ReNode, TAM, GraphENS, GraphSHA 为简化实现，
      保留核心思想但不完全复现原论文全部细节。
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score)

from config import Config
from src.utils import set_seed
from src.models import build_encoder, MLPDecoder, Classifier, EdgePredictor
from src.core import RuleGuidedGraphSMOTE, RuleLoss, CombinedLoss
from src.training import Trainer

from experiments.exp_utils import calculate_gmean


# ==================== 通用基线训练框架 ====================

class BaselineTrainer:
    """通用基线模型训练器"""

    def __init__(self, encoder, classifier, device='cuda'):
        self.encoder = encoder.to(device)
        self.classifier = classifier.to(device)
        self.device = device
        self.optimizer = None

    def setup_optimizer(self, lr=0.001, weight_decay=5e-4):
        params = list(self.encoder.parameters()) + list(self.classifier.parameters())
        self.optimizer = torch.optim.Adam(params, lr=lr, weight_decay=weight_decay)

    def compute_loss(self, logits, labels, train_mask, **kwargs):
        """标准交叉熵损失（子类可覆盖）"""
        return F.cross_entropy(logits[train_mask], labels[train_mask])

    def train_epoch(self, x, edge_index, labels, train_mask, **kwargs):
        self.encoder.train()
        self.classifier.train()

        h = self.encoder(x, edge_index)
        logits = self.classifier(h)
        loss = self.compute_loss(logits, labels, train_mask, embeddings=h, **kwargs)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    @torch.no_grad()
    def evaluate(self, x, edge_index, labels, mask, minority_class=None):
        self.encoder.eval()
        self.classifier.eval()

        h = self.encoder(x, edge_index)
        logits = self.classifier(h)
        probs = F.softmax(logits, dim=-1)

        preds = logits[mask].argmax(dim=1).cpu().numpy()
        labels_np = labels[mask].cpu().numpy()
        probs_np = probs[mask].cpu().numpy()
        n_classes = logits.shape[1]

        f1_macro = f1_score(labels_np, preds, average='macro', zero_division=0)
        f1_minority_val = 0.0
        if minority_class is not None:
            f1_minority_val = f1_score(labels_np, preds, labels=[minority_class],
                                       average='macro', zero_division=0)
        gmean = calculate_gmean(labels_np, preds)

        try:
            if n_classes == 2:
                auc = roc_auc_score(labels_np, probs_np[:, 1])
            else:
                auc = roc_auc_score(labels_np, probs_np, multi_class='ovr', average='macro')
        except Exception:
            auc = 0.5

        return {
            'f1_macro': f1_macro,
            'f1_minority': f1_minority_val,
            'auc': auc,
            'gmean': gmean,
            'accuracy': accuracy_score(labels_np, preds)
        }

    def train(self, x, edge_index, labels, train_mask, val_mask,
              minority_class=None, num_epochs=200, patience=20, **kwargs):
        best_val_f1 = 0.0
        patience_counter = 0
        best_state = None

        for epoch in range(num_epochs):
            loss = self.train_epoch(x, edge_index, labels, train_mask, **kwargs)

            if (epoch + 1) % 10 == 0:
                val_metrics = self.evaluate(x, edge_index, labels, val_mask, minority_class)
                if val_metrics['f1_macro'] > best_val_f1:
                    best_val_f1 = val_metrics['f1_macro']
                    patience_counter = 0
                    best_state = {
                        'encoder': {k: v.clone() for k, v in self.encoder.state_dict().items()},
                        'classifier': {k: v.clone() for k, v in self.classifier.state_dict().items()}
                    }
                else:
                    patience_counter += 1
                    if patience_counter >= patience // 10:
                        break

        # 恢复最佳模型
        if best_state is not None:
            self.encoder.load_state_dict(best_state['encoder'])
            self.classifier.load_state_dict(best_state['classifier'])


# ==================== ReNode: 拓扑感知节点重加权 ====================

class ReNodeTrainer(BaselineTrainer):
    """
    ReNode
    """

    def compute_loss(self, logits, labels, train_mask, embeddings=None, **kwargs):
        pass


# ==================== TAM: 拓扑感知边际损失 ====================

class TAMTrainer(BaselineTrainer):
    """
    TAM
    """

    def compute_loss(self, logits, labels, train_mask, embeddings=None,
                     edge_index=None, **kwargs):
        pass

    def train_epoch(self, x, edge_index, labels, train_mask, **kwargs):
        pass


# ==================== GraphSMOTE: 标准图过采样（无规则约束）====================

def run_graphsmote_baseline(data_dict, device, random_seed):
    """
    GraphSMOTE
    使用完整的GraphSMOTE流程，但不加规则一致性约束和证据融合
    即 λ_rule=0, USE_DS_FUSION=False
    """
    from experiments.exp_utils import run_full_rg_gnn_earc
    results, _, _ = run_full_rg_gnn_earc(
        data_dict, device, random_seed,
        lambda_rule=0.0,       # 无规则约束
        use_ds_fusion=False,   # 无证据融合
        enable_rule_selection=False
    )
    return {
        'f1_macro': results['gnn_f1_macro'],
        'f1_minority': results['gnn_f1_minority'],
        'auc': results['gnn_auc'],
        'gmean': results['gnn_gmean'],
        'accuracy': results['accuracy'],
    }


# ==================== GraphENS: 邻居感知自我网络合成 ====================

class GraphENSTrainer(BaselineTrainer):
    """
    GraphENS
    """

    def train(self, x, edge_index, labels, train_mask, val_mask,
              minority_class=None, num_epochs=200, patience=20, **kwargs):
        pass



# ==================== GraphSHA: 困难样本合成 ====================

class GraphSHATrainer(BaselineTrainer):
    """
    GraphSHA
    """

    def train(self, x, edge_index, labels, train_mask, val_mask,
              minority_class=None, num_epochs=200, patience=20, **kwargs):
        pass


# ==================== 统一的基线运行接口 ====================

def run_baseline(method_name, data_dict, device, random_seed):
    """
    统一接口：运行指定的基线方法

    Args:
        method_name: 方法名称 ('GCN', 'GAT', 'ReNode', 'TAM', 'GraphSMOTE', 'GraphENS', 'GraphSHA', 'EARC')
        data_dict: prepare_data返回的数据字典
        device: 计算设备
        random_seed: 随机种子

    Returns:
        results: 包含 f1_macro, f1_minority, auc, gmean 的字典
    """
    set_seed(random_seed)

    x = data_dict['x']
    y = data_dict['y']
    edge_index = data_dict['edge_index']
    train_mask = data_dict['train_mask']
    val_mask = data_dict['val_mask']
    test_mask = data_dict['test_mask']
    minority_class = data_dict['minority_class']
    n_classes = data_dict['n_classes']
    n_features = data_dict['n_features']

    if method_name == 'GraphSMOTE':
        return run_graphsmote_baseline(data_dict, device, random_seed)

    if method_name == 'EARC':
        from experiments.exp_utils import run_earc_only
        return run_earc_only(data_dict, device, random_seed)

    if method_name in ['GCN', 'GAT']:
        from experiments.exp_utils import run_baseline_gnn_only
        return run_baseline_gnn_only(data_dict, device, random_seed, gnn_type=method_name)

    # 为 ReNode, TAM, GraphENS, GraphSHA 构建编码器和分类器
    gnn_type = 'GCN'  # 所有拓扑/增强方法都使用GCN作为骨干
    encoder = build_encoder(
        gnn_type=gnn_type, in_dim=n_features,
        hidden_dim=Config.HIDDEN_DIM, embedding_dim=Config.EMBEDDING_DIM,
        num_layers=Config.NUM_GNN_LAYERS, num_heads=Config.NUM_HEADS,
        dropout=Config.DROPOUT
    )
    classifier_model = Classifier(
        embedding_dim=Config.EMBEDDING_DIM, num_classes=n_classes,
        hidden_dim=Config.HIDDEN_DIM // 2
    )

    if method_name == 'ReNode':
        trainer = ReNodeTrainer(encoder, classifier_model, device)
    elif method_name == 'TAM':
        trainer = TAMTrainer(encoder, classifier_model, device)
    elif method_name == 'GraphENS':
        trainer = GraphENSTrainer(encoder, classifier_model, device)
    elif method_name == 'GraphSHA':
        trainer = GraphSHATrainer(encoder, classifier_model, device)
    else:
        raise ValueError(f"未知的基线方法: {method_name}")

    trainer.setup_optimizer(lr=Config.LEARNING_RATE, weight_decay=Config.WEIGHT_DECAY)
    trainer.train(x, edge_index, y, train_mask, val_mask,
                  minority_class=minority_class,
                  num_epochs=Config.NUM_EPOCHS, patience=Config.PATIENCE)

    results = trainer.evaluate(x, edge_index, y, test_mask, minority_class)
    return results

