"""
基线方法实现模块
实现experiments.md中Section 4.1.2定义的7种基线方法的简化版本

包含:
1. GCN / GAT: 标准图神经网络（下界）
2. ReNode: 拓扑感知节点重加权
3. TAM: 拓扑感知边际损失
4. GraphSMOTE: 标准潜在空间过采样（无规则约束）
5. GraphENS: 邻居感知自我网络合成
6. GraphSHA: 困难样本合成
7. EARC-only: 纯证据关联规则分类器（在exp_utils中实现）

注意: ReNode, TAM, GraphENS, GraphSHA 为简化实现，
      保留核心思想但不完全复现原论文全部细节。
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score)

from config import Config
from src.utils import set_seed
from src.models import build_encoder, MLPDecoder, Classifier, EdgePredictor
from src.core import RuleGuidedGraphSMOTE, RuleLoss, CombinedLoss
from src.training import Trainer

from experiments.exp_utils import calculate_gmean


# ==================== 通用基线训练框架 ====================

class BaselineTrainer:
    """通用基线模型训练器"""

    def __init__(self, encoder, classifier, device='cuda'):
        self.encoder = encoder.to(device)
        self.classifier = classifier.to(device)
        self.device = device
        self.optimizer = None

    def setup_optimizer(self, lr=0.001, weight_decay=5e-4):
        params = list(self.encoder.parameters()) + list(self.classifier.parameters())
        self.optimizer = torch.optim.Adam(params, lr=lr, weight_decay=weight_decay)

    def compute_loss(self, logits, labels, train_mask, **kwargs):
        """标准交叉熵损失（子类可覆盖）"""
        return F.cross_entropy(logits[train_mask], labels[train_mask])

    def train_epoch(self, x, edge_index, labels, train_mask, **kwargs):
        self.encoder.train()
        self.classifier.train()

        h = self.encoder(x, edge_index)
        logits = self.classifier(h)
        loss = self.compute_loss(logits, labels, train_mask, embeddings=h, **kwargs)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    @torch.no_grad()
    def evaluate(self, x, edge_index, labels, mask, minority_class=None):
        self.encoder.eval()
        self.classifier.eval()

        h = self.encoder(x, edge_index)
        logits = self.classifier(h)
        probs = F.softmax(logits, dim=-1)

        preds = logits[mask].argmax(dim=1).cpu().numpy()
        labels_np = labels[mask].cpu().numpy()
        probs_np = probs[mask].cpu().numpy()
        n_classes = logits.shape[1]

        f1_macro = f1_score(labels_np, preds, average='macro', zero_division=0)
        f1_minority_val = 0.0
        if minority_class is not None:
            f1_minority_val = f1_score(labels_np, preds, labels=[minority_class],
                                       average='macro', zero_division=0)
        gmean = calculate_gmean(labels_np, preds)

        try:
            if n_classes == 2:
                auc = roc_auc_score(labels_np, probs_np[:, 1])
            else:
                auc = roc_auc_score(labels_np, probs_np, multi_class='ovr', average='macro')
        except Exception:
            auc = 0.5

        return {
            'f1_macro': f1_macro,
            'f1_minority': f1_minority_val,
            'auc': auc,
            'gmean': gmean,
            'accuracy': accuracy_score(labels_np, preds)
        }

    def train(self, x, edge_index, labels, train_mask, val_mask,
              minority_class=None, num_epochs=200, patience=20, **kwargs):
        best_val_f1 = 0.0
        patience_counter = 0
        best_state = None

        for epoch in range(num_epochs):
            loss = self.train_epoch(x, edge_index, labels, train_mask, **kwargs)

            if (epoch + 1) % 10 == 0:
                val_metrics = self.evaluate(x, edge_index, labels, val_mask, minority_class)
                if val_metrics['f1_macro'] > best_val_f1:
                    best_val_f1 = val_metrics['f1_macro']
                    patience_counter = 0
                    best_state = {
                        'encoder': {k: v.clone() for k, v in self.encoder.state_dict().items()},
                        'classifier': {k: v.clone() for k, v in self.classifier.state_dict().items()}
                    }
                else:
                    patience_counter += 1
                    if patience_counter >= patience // 10:
                        break

        # 恢复最佳模型
        if best_state is not None:
            self.encoder.load_state_dict(best_state['encoder'])
            self.classifier.load_state_dict(best_state['classifier'])


# ==================== ReNode: 拓扑感知节点重加权 ====================

class ReNodeTrainer(BaselineTrainer):
    """
    ReNode
    """

    def compute_loss(self, logits, labels, train_mask, embeddings=None, **kwargs):
        if embeddings is None:
            return F.cross_entropy(logits[train_mask], labels[train_mask])

        # 计算每个类别的质心
        train_labels = labels[train_mask]
        train_embeddings = embeddings[train_mask]
        unique_classes = torch.unique(train_labels)

        centroids = {}
        for c in unique_classes:
            class_mask = train_labels == c
            centroids[c.item()] = train_embeddings[class_mask].mean(dim=0)

        # 计算每个节点到最近异类质心的距离
        weights = torch.ones(train_mask.sum(), device=self.device)
        for i, (emb, label) in enumerate(zip(train_embeddings, train_labels)):
            min_dist = float('inf')
            for c, centroid in centroids.items():
                if c != label.item():
                    dist = torch.norm(emb - centroid).item()
                    min_dist = min(min_dist, dist)
            # 距离越近权重越高（边界样本更重要）
            weights[i] = 1.0 / (min_dist + 1e-6)

        # 归一化权重
        weights = weights / weights.sum() * len(weights)

        # 加权交叉熵
        per_sample_loss = F.cross_entropy(logits[train_mask], labels[train_mask], reduction='none')
        loss = (per_sample_loss * weights).mean()
        return loss


# ==================== TAM: 拓扑感知边际损失 ====================

class TAMTrainer(BaselineTrainer):
    """
    TAM
    """

    def compute_loss(self, logits, labels, train_mask, embeddings=None,
                     edge_index=None, **kwargs):
        if edge_index is None:
            return F.cross_entropy(logits[train_mask], labels[train_mask])

        train_indices = torch.where(train_mask)[0]
        train_labels = labels[train_mask]

        # 计算每个训练节点的局部类别同质性
        margins = torch.zeros(len(train_indices), device=self.device)

        for i, node_idx in enumerate(train_indices):
            # 找到该节点的邻居
            neighbors = edge_index[1][edge_index[0] == node_idx]
            if len(neighbors) == 0:
                margins[i] = 0.0
                continue

            # 计算邻居中同类别的比例
            node_label = labels[node_idx]
            same_class_ratio = (labels[neighbors] == node_label).float().mean()

            # 同质性越低，边际越大（保护异类邻居多的节点）
            margins[i] = 1.0 - same_class_ratio

        # 将边际应用到logits中：减小正确类别的logit
        adjusted_logits = logits[train_mask].clone()
        for i in range(len(train_indices)):
            correct_class = train_labels[i]
            adjusted_logits[i, correct_class] -= margins[i] * 0.5  # 缩放系数

        loss = F.cross_entropy(adjusted_logits, train_labels)
        return loss

    def train_epoch(self, x, edge_index, labels, train_mask, **kwargs):
        self.encoder.train()
        self.classifier.train()

        h = self.encoder(x, edge_index)
        logits = self.classifier(h)
        loss = self.compute_loss(logits, labels, train_mask,
                                  embeddings=h, edge_index=edge_index)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()


# ==================== GraphSMOTE: 标准图过采样（无规则约束）====================

def run_graphsmote_baseline(data_dict, device, random_seed):
    """
    GraphSMOTE
    """
    from experiments.exp_utils import run_full_rg_gnn_earc
    results, _, _ = run_full_rg_gnn_earc(
        data_dict, device, random_seed,
        lambda_rule=0.0,       # 无规则约束
        use_ds_fusion=False,   # 无证据融合
        enable_rule_selection=False
    )
    return {
        'f1_macro': results['gnn_f1_macro'],
        'f1_minority': results['gnn_f1_minority'],
        'auc': results['gnn_auc'],
        'gmean': results['gnn_gmean'],
        'accuracy': results['accuracy'],
    }


# ==================== GraphENS: 邻居感知自我网络合成 ====================

class GraphENSTrainer(BaselineTrainer):
    """
    GraphENS
    核心思想：通过显著性加权的ego-network混合来合成新的少数类节点
    """

    def train(self, x, edge_index, labels, train_mask, val_mask,
              minority_class=None, num_epochs=200, patience=20, **kwargs):
        """训练时在每个epoch进行邻居混合增强"""
        best_val_f1 = 0.0
        patience_counter = 0
        best_state = None

        # 预计算邻居信息
        adj_list = {}
        src, dst = edge_index[0].cpu().numpy(), edge_index[1].cpu().numpy()
        for s, d in zip(src, dst):
            if s not in adj_list:
                adj_list[s] = []
            adj_list[s].append(d)

        minority_mask = (labels == minority_class) & train_mask
        minority_indices = torch.where(minority_mask)[0]
        majority_indices = torch.where((labels != minority_class) & train_mask)[0]

        for epoch in range(num_epochs):
            self.encoder.train()
            self.classifier.train()

            # 原始前向传播
            h = self.encoder(x, edge_index)
            logits = self.classifier(h)

            # GraphENS增强：为少数类节点生成合成特征
            if len(minority_indices) > 0 and len(majority_indices) > 0:
                n_synthetic = min(len(majority_indices) - len(minority_indices), len(minority_indices) * 2)
                n_synthetic = max(1, n_synthetic)

                synthetic_h = []
                for _ in range(n_synthetic):
                    # 随机选择一个少数类节点
                    idx = minority_indices[np.random.randint(len(minority_indices))].item()
                    node_emb = h[idx]

                    # 获取邻居嵌入并加权混合
                    neighbors = adj_list.get(idx, [])
                    if len(neighbors) > 0:
                        # 随机选择一个同类邻居进行混合
                        same_class_neighbors = [n for n in neighbors if labels[n] == minority_class]
                        if len(same_class_neighbors) > 0:
                            mix_idx = same_class_neighbors[np.random.randint(len(same_class_neighbors))]
                        else:
                            mix_idx = neighbors[np.random.randint(len(neighbors))]
                        mix_emb = h[mix_idx]
                        lam = np.random.beta(2.0, 2.0)
                        synth = lam * node_emb + (1 - lam) * mix_emb
                    else:
                        synth = node_emb + torch.randn_like(node_emb) * 0.01
                    synthetic_h.append(synth)

                synthetic_h = torch.stack(synthetic_h)
                synthetic_logits = self.classifier(synthetic_h)
                synthetic_labels = torch.full((n_synthetic,), minority_class,
                                              dtype=torch.long, device=self.device)

                # 组合损失
                loss_original = F.cross_entropy(logits[train_mask], labels[train_mask])
                loss_synthetic = F.cross_entropy(synthetic_logits, synthetic_labels)
                loss = loss_original + 0.5 * loss_synthetic
            else:
                loss = F.cross_entropy(logits[train_mask], labels[train_mask])

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            if (epoch + 1) % 10 == 0:
                val_metrics = self.evaluate(x, edge_index, labels, val_mask, minority_class)
                if val_metrics['f1_macro'] > best_val_f1:
                    best_val_f1 = val_metrics['f1_macro']
                    patience_counter = 0
                    best_state = {
                        'encoder': {k: v.clone() for k, v in self.encoder.state_dict().items()},
                        'classifier': {k: v.clone() for k, v in self.classifier.state_dict().items()}
                    }
                else:
                    patience_counter += 1
                    if patience_counter >= patience // 10:
                        break

        if best_state is not None:
            self.encoder.load_state_dict(best_state['encoder'])
            self.classifier.load_state_dict(best_state['classifier'])


# ==================== GraphSHA: 困难样本合成 ====================

class GraphSHATrainer(BaselineTrainer):
    """
    GraphSHA
    核心思想：在决策边界附近生成更具挑战性的少数类合成样本
    """

    def train(self, x, edge_index, labels, train_mask, val_mask,
              minority_class=None, num_epochs=200, patience=20, **kwargs):
        best_val_f1 = 0.0
        patience_counter = 0
        best_state = None

        minority_mask = (labels == minority_class) & train_mask
        minority_indices = torch.where(minority_mask)[0]
        majority_mask = (labels != minority_class) & train_mask
        majority_indices = torch.where(majority_mask)[0]

        for epoch in range(num_epochs):
            self.encoder.train()
            self.classifier.train()

            h = self.encoder(x, edge_index)
            logits = self.classifier(h)

            if len(minority_indices) > 1 and len(majority_indices) > 0:
                # 计算类别原型
                minority_proto = h[minority_indices].mean(dim=0, keepdim=True)
                majority_proto = h[majority_indices].mean(dim=0, keepdim=True)

                # 找到靠近决策边界的少数类样本
                minority_embeddings = h[minority_indices]
                dist_to_majority = torch.norm(minority_embeddings - majority_proto, dim=1)

                # 选择距离多数类最近的样本（最难的样本）
                k_hard = min(max(2, len(minority_indices) // 2), len(minority_indices))
                _, hard_indices = torch.topk(dist_to_majority, k_hard, largest=False)
                hard_embeddings = minority_embeddings[hard_indices]

                # 在困难样本之间插值生成新的合成样本
                n_synthetic = min(len(majority_indices) - len(minority_indices),
                                  len(minority_indices) * 2)
                n_synthetic = max(1, n_synthetic)

                synthetic_h = []
                for _ in range(n_synthetic):
                    idx1, idx2 = np.random.choice(len(hard_embeddings), 2, replace=True)
                    lam = np.random.beta(1.0, 1.0)
                    # 偏向多数类方向移动（生成更难的样本）
                    synth = lam * hard_embeddings[idx1] + (1 - lam) * hard_embeddings[idx2]
                    # 轻微向多数类原型方向偏移
                    direction = (majority_proto.squeeze() - synth)
                    synth = synth + 0.1 * direction
                    synthetic_h.append(synth)

                synthetic_h = torch.stack(synthetic_h)
                synthetic_logits = self.classifier(synthetic_h)
                synthetic_labels = torch.full((n_synthetic,), minority_class,
                                              dtype=torch.long, device=self.device)

                loss_original = F.cross_entropy(logits[train_mask], labels[train_mask])
                loss_synthetic = F.cross_entropy(synthetic_logits, synthetic_labels)
                loss = loss_original + 0.5 * loss_synthetic
            else:
                loss = F.cross_entropy(logits[train_mask], labels[train_mask])

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            if (epoch + 1) % 10 == 0:
                val_metrics = self.evaluate(x, edge_index, labels, val_mask, minority_class)
                if val_metrics['f1_macro'] > best_val_f1:
                    best_val_f1 = val_metrics['f1_macro']
                    patience_counter = 0
                    best_state = {
                        'encoder': {k: v.clone() for k, v in self.encoder.state_dict().items()},
                        'classifier': {k: v.clone() for k, v in self.classifier.state_dict().items()}
                    }
                else:
                    patience_counter += 1
                    if patience_counter >= patience // 10:
                        break

        if best_state is not None:
            self.encoder.load_state_dict(best_state['encoder'])
            self.classifier.load_state_dict(best_state['classifier'])


# ==================== 统一的基线运行接口 ====================

def run_baseline(method_name, data_dict, device, random_seed):
    """
    统一接口：运行指定的基线方法

    Args:
        method_name: 方法名称 ('GCN', 'GAT', 'ReNode', 'TAM', 'GraphSMOTE', 'GraphENS', 'GraphSHA', 'EARC')
        data_dict: prepare_data返回的数据字典
        device: 计算设备
        random_seed: 随机种子

    Returns:
        results: 包含 f1_macro, f1_minority, auc, gmean 的字典
    """
    set_seed(random_seed)

    x = data_dict['x']
    y = data_dict['y']
    edge_index = data_dict['edge_index']
    train_mask = data_dict['train_mask']
    val_mask = data_dict['val_mask']
    test_mask = data_dict['test_mask']
    minority_class = data_dict['minority_class']
    n_classes = data_dict['n_classes']
    n_features = data_dict['n_features']

    if method_name == 'GraphSMOTE':
        return run_graphsmote_baseline(data_dict, device, random_seed)

    if method_name == 'EARC':
        from experiments.exp_utils import run_earc_only
        return run_earc_only(data_dict, device, random_seed)

    if method_name in ['GCN', 'GAT']:
        from experiments.exp_utils import run_baseline_gnn_only
        return run_baseline_gnn_only(data_dict, device, random_seed, gnn_type=method_name)

    # 为 ReNode, TAM, GraphENS, GraphSHA 构建编码器和分类器
    gnn_type = 'GCN'  # 所有拓扑/增强方法都使用GCN作为骨干
    encoder = build_encoder(
        gnn_type=gnn_type, in_dim=n_features,
        hidden_dim=Config.HIDDEN_DIM, embedding_dim=Config.EMBEDDING_DIM,
        num_layers=Config.NUM_GNN_LAYERS, num_heads=Config.NUM_HEADS,
        dropout=Config.DROPOUT
    )
    classifier_model = Classifier(
        embedding_dim=Config.EMBEDDING_DIM, num_classes=n_classes,
        hidden_dim=Config.HIDDEN_DIM // 2
    )

    if method_name == 'ReNode':
        trainer = ReNodeTrainer(encoder, classifier_model, device)
    elif method_name == 'TAM':
        trainer = TAMTrainer(encoder, classifier_model, device)
    elif method_name == 'GraphENS':
        trainer = GraphENSTrainer(encoder, classifier_model, device)
    elif method_name == 'GraphSHA':
        trainer = GraphSHATrainer(encoder, classifier_model, device)
    else:
        raise ValueError(f"未知的基线方法: {method_name}")

    trainer.setup_optimizer(lr=Config.LEARNING_RATE, weight_decay=Config.WEIGHT_DECAY)
    trainer.train(x, edge_index, y, train_mask, val_mask,
                  minority_class=minority_class,
                  num_epochs=Config.NUM_EPOCHS, patience=Config.PATIENCE)

    results = trainer.evaluate(x, edge_index, y, test_mask, minority_class)
    return results

