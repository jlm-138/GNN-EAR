"""
实验共享工具模块
提取keel_experiments.py中的公共函数，供所有实验脚本复用

包含:
- 常量定义（数据集列表、种子列表、代表性数据集）
- calculate_gmean: G-Mean计算
- run_single_fold: 完整单折实验流程（6阶段）
- generate_latex_table / generate_comparison_latex_table: LaTeX表格生成
- setup_experiment_env: 实验环境初始化
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import numpy as np
import pandas as pd
import json
from datetime import datetime
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (accuracy_score, f1_score,
                             recall_score, roc_auc_score, confusion_matrix)
import warnings
warnings.filterwarnings('ignore')

from config import Config
from src.utils import set_seed
from src.data import DataLoader
from src.core import EARCClassifier, RuleGuidedGraphSMOTE, RuleLoss, CombinedLoss
from src.models import build_encoder, MLPDecoder, Classifier, EdgePredictor
from src.training import Trainer

# ==================== 常量定义 ====================

# 14个KEEL基准数据集
# KEEL_DATASETS = [
#     'ecoli1', 'ecoli2', 'ecoli3', 'glass0', 'glass1',
#     'yeast1', 'yeast3', 'yeast4', 'yeast5', 'yeast6',
#     'abalone9-18', 'page-blocks0', 'pima', 'vehicle0'
# ]

KEEL_DATASETS = [
    'balance', 'cleveland-0_vs_4', 'glass', 'glass0', 'haberman', 'hayes-roth', 'new-thyroid',
    'new-thyroid1', 'newthyroid2', 'page-blocks-1-3_vs_4', 'poker', 'segment0', 'shuttle-6_vs_2-3', 'vowel0', 'wine',
    'winequality-red-8_vs_6', 'winequality-white-3_vs_7', 'winequality-white-9_vs_4', 'wisconsin', 'pima', 'vehicle0',
    'yeast1', 'ecoli1', 'ecoli2', 'ecoli3'
]

# 10个随机种子（用于重复实验）
SEEDS = [42, 142, 242, 342, 842, 542, 642, 742, 442, 942]

# 代表性数据集（覆盖不同不平衡率级别）
# ecoli1(IR≈3.4, 低), yeast3(IR≈8.1, 中), page-blocks0(IR≈8.8, 中高), abalone9-18(IR≈16.4, 高)
# REPRESENTATIVE_DATASETS = ['ecoli1', 'yeast3', 'page-blocks0', 'abalone9-18']
# REPRESENTATIVE_DATASETS = ['cleveland-0_vs_4', 'haberman', 'new-thyroid', 'vowel0']
# REPRESENTATIVE_DATASETS = ['newthyroid2', 'poker', 'shuttle-6_vs_2-3']
# REPRESENTATIVE_DATASETS = ['cleveland-0_vs_4', 'winequality-white-3_vs_7']
REPRESENTATIVE_DATASETS = ['cleveland', 'winequality-white']

# 评估指标列表
METRICS = ['f1_macro', 'f1_minority', 'auc', 'gmean']

# 默认折数
N_FOLDS = 5


def setup_experiment_env(output_dir):
    """初始化实验环境"""
    os.makedirs(output_dir, exist_ok=True)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    print(f"实验环境: 设备={device}, 输出目录={output_dir}")
    return device, timestamp


def calculate_gmean(y_true, y_pred):
    """计算G-Mean（几何平均数）"""
    cm = confusion_matrix(y_true, y_pred)
    if cm.shape[0] == 2:
        tn, fp, fn, tp = cm.ravel()
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        gmean = np.sqrt(sensitivity * specificity)
    else:
        recalls = []
        for i in range(cm.shape[0]):
            recall = cm[i, i] / cm[i, :].sum() if cm[i, :].sum() > 0 else 0
            recalls.append(recall)
        gmean = np.prod(recalls) ** (1.0 / len(recalls))
    return gmean


def _count_rules_by_class(rules, n_classes=None):
    """统计各类别规则数量。"""
    counts = {}
    for rule in rules:
        cls = int(rule.get('predicted_class', 0))
        counts[cls] = counts.get(cls, 0) + 1
    if n_classes is not None:
        for c in range(int(n_classes)):
            counts.setdefault(c, 0)
    return counts


def _normalize_target_sparsity(target_sparsity):
    """规范化目标稀疏率，兼容 50(%) 与 0.5 两种输入。"""
    try:
        sparsity = float(target_sparsity)
    except Exception:
        sparsity = 0.5

    if sparsity > 1.0:
        # 兼容把百分比(如50)当成比例传入的场景
        if sparsity <= 100.0:
            sparsity = sparsity / 100.0
        else:
            sparsity = 1.0

    return float(np.clip(sparsity, 0.0, 1.0))


def _compute_target_keep(num_rules, target_sparsity):
    """根据规则总数和稀疏率计算目标保留数。"""
    if num_rules <= 0:
        return 0

    sparsity = _normalize_target_sparsity(target_sparsity)
    target_keep = max(3, int(num_rules * sparsity))
    target_keep = min(num_rules, max(1, target_keep))

    # 当明确启用压缩(s<1)且规则数>1时，至少减少1条，避免“看起来筛选了但数量不变”。
    if sparsity < 1.0 and num_rules > 1 and target_keep >= num_rules:
        target_keep = num_rules - 1

    return int(target_keep)


def _compute_adaptive_target_keep(num_rules, rule_scores, binary_activation=None):
    """自适应估计规则保留数（无需手工指定压缩比例）。"""
    if num_rules <= 0:
        return 0, {
            'source': 'adaptive',
            'elbow_keep': 0,
            'quality_keep': 0,
            'redundancy': 0.0,
        }

    if num_rules == 1:
        return 1, {
            'source': 'adaptive',
            'elbow_keep': 1,
            'quality_keep': 1,
            'redundancy': 0.0,
        }

    scores = np.asarray(rule_scores, dtype=float)
    if scores.size != num_rules:
        scores = np.pad(scores[:num_rules], (0, max(0, num_rules - scores.size)), constant_values=0.0)

    sorted_scores = np.sort(scores)[::-1]
    drops = sorted_scores[:-1] - sorted_scores[1:]
    elbow_keep = int(np.argmax(drops) + 1) if drops.size > 0 else max(1, num_rules // 2)

    # 质量门限：保留高于 65 分位的规则。
    quality_thr = float(np.quantile(scores, 0.65)) if num_rules > 2 else float(np.min(scores))
    quality_keep = int(np.sum(scores >= quality_thr))
    quality_keep = max(1, quality_keep)

    # 结合拐点与质量信号得到初始目标。
    target = int(round(0.55 * elbow_keep + 0.45 * quality_keep))

    redundancy = 0.0
    if binary_activation is not None and num_rules > 1:
        sample_rule_n = min(num_rules, 20)
        top_indices = np.argsort(-scores)[:sample_rule_n]
        pairs = 0
        sim_sum = 0.0
        for i in range(len(top_indices)):
            a_idx = top_indices[i]
            a_vec = binary_activation[:, a_idx]
            for j in range(i + 1, len(top_indices)):
                b_idx = top_indices[j]
                b_vec = binary_activation[:, b_idx]
                inter = np.sum(np.minimum(a_vec, b_vec))
                union = np.sum(np.maximum(a_vec, b_vec))
                sim_sum += float(inter / (union + 1e-12))
                pairs += 1
        if pairs > 0:
            redundancy = sim_sum / pairs

    # 冗余高则压缩更多，冗余低则放宽少量规则。
    if redundancy >= 0.80:
        target = int(round(target * 0.80))
    elif redundancy <= 0.35:
        target = int(round(target * 1.10))

    lower = max(3, int(np.ceil(0.20 * num_rules)))
    upper = max(lower, int(np.ceil(0.70 * num_rules)))
    if num_rules > 1:
        upper = min(upper, num_rules - 1)
    target = int(np.clip(target, lower, upper))

    return target, {
        'source': 'adaptive',
        'elbow_keep': int(elbow_keep),
        'quality_keep': int(quality_keep),
        'redundancy': float(redundancy),
    }


def _fallback_select_rules(rules, target_keep, minority_class):
    """规则筛选异常时的确定性降级策略：按置信度排序并保证少数类覆盖。"""
    if not rules:
        return []

    target_keep = min(len(rules), max(1, int(target_keep)))

    scored = []
    for idx, rule in enumerate(rules):
        conf = float(rule.get('confidence', 0.0))
        support = float(rule.get('support', 0.0))
        score = 0.8 * conf + 0.2 * support
        scored.append((idx, score))

    ranked = [i for i, _ in sorted(scored, key=lambda x: x[1], reverse=True)]
    selected = ranked[:target_keep]

    minority_candidates = [
        i for i in ranked
        if int(rules[i].get('predicted_class', -1)) == int(minority_class)
    ]
    if minority_candidates and not any(
        int(rules[i].get('predicted_class', -1)) == int(minority_class)
        for i in selected
    ):
        selected[-1] = minority_candidates[0]

    selected = list(dict.fromkeys(selected))
    while len(selected) < target_keep:
        for idx in ranked:
            if idx not in selected:
                selected.append(idx)
            if len(selected) >= target_keep:
                break

    return [rules[i] for i in selected]


def prepare_data(dataset_name, fold_idx, random_seed, device, n_folds=N_FOLDS):
    """
    准备数据：加载数据、交叉验证划分、转换为张量

    Returns:
        data_dict: 包含所有数据和元信息的字典
    """
    # 使用项目根目录的绝对路径，避免依赖当前工作目录
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    data_path = os.path.join(project_root, 'datas')
    loader = DataLoader(dataset_name, data_path, graph_metric=Config.GRAPH_METRIC)
    features, labels, adj_matrix = loader.load(knn_k=Config.KNN_K)

    unique, counts = np.unique(labels, return_counts=True)
    minority_class = unique[np.argmin(counts)]
    imbalance_ratio = counts.max() / counts.min()
    n_classes = len(unique)

    if int(n_folds) < 2:
        raise ValueError(f"n_folds must be >= 2, got {n_folds}")
    if int(fold_idx) < 0 or int(fold_idx) >= int(n_folds):
        raise ValueError(f"fold_idx must be in [0, {n_folds - 1}], got {fold_idx}")

    # 交叉验证划分
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_seed)
    splits = list(skf.split(features, labels))
    train_val_idx, test_idx = splits[fold_idx]

    # 训练/验证划分
    train_val_labels = labels[train_val_idx]
    inner_skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_seed)
    inner_splits = list(inner_skf.split(train_val_idx, train_val_labels))
    train_inner_idx, val_inner_idx = inner_splits[0]

    train_idx = train_val_idx[train_inner_idx]
    val_idx = train_val_idx[val_inner_idx]

    # 创建mask
    train_mask = torch.zeros(len(labels), dtype=torch.bool)
    val_mask = torch.zeros(len(labels), dtype=torch.bool)
    test_mask = torch.zeros(len(labels), dtype=torch.bool)
    train_mask[train_idx] = True
    val_mask[val_idx] = True
    test_mask[test_idx] = True
    train_mask = train_mask.to(device)
    val_mask = val_mask.to(device)
    test_mask = test_mask.to(device)

    # 转换为张量
    x = torch.FloatTensor(features).to(device)
    y = torch.LongTensor(labels).to(device)
    edge_index = torch.LongTensor(np.array(np.where(adj_matrix > 0))).to(device)

    return {
        'features': features, 'labels': labels, 'adj_matrix': adj_matrix,
        'x': x, 'y': y, 'edge_index': edge_index,
        'train_mask': train_mask, 'val_mask': val_mask, 'test_mask': test_mask,
        'train_idx': train_idx, 'val_idx': val_idx, 'test_idx': test_idx,
        'minority_class': minority_class, 'imbalance_ratio': imbalance_ratio,
        'n_classes': n_classes, 'n_features': features.shape[1],
        'n_samples': len(labels),
        'n_minority': int(counts.min()), 'n_majority': int(counts.max())
    }


def unified_rule_selection(rules, sample_embeddings, activation_matrix, labels,
                           minority_class, target_sparsity=None, selection_mode='adaptive', verbose=False,
                           return_metadata=False):
    """
    统一规则选择 - 基于主模型GNN编码器的嵌入进行规则选择
    """
    if len(rules) == 0:
        metadata = {
            'num_rules': 0,
            'selected_count': 0,
            'fallback_used': False,
            'fallback_reason': 'no_input_rules',
            'target_total': 0,
        }
        return ([], metadata) if return_metadata else []

    num_rules = len(rules)
    num_samples = sample_embeddings.shape[0]

    sample_size = min(500, num_samples)
    if sample_size > 1:
        sampled_idx = np.random.choice(num_samples, sample_size, replace=False)
        sampled_emb = sample_embeddings[sampled_idx]
        pairwise_dists = np.linalg.norm(sampled_emb[:, None, :] - sampled_emb[None, :, :], axis=2)
        nonzero_pairwise = pairwise_dists[pairwise_dists > 0]
        global_median_dist = np.median(nonzero_pairwise) + 1e-8 if nonzero_pairwise.size > 0 else 1.0
    else:
        global_median_dist = 1.0

    unique_classes, class_counts = np.unique(labels, return_counts=True)
    class_count_map = dict(zip(unique_classes, class_counts))

    rule_scores = np.zeros(num_rules)
    rule_purity = np.zeros(num_rules)
    rule_compactness = np.zeros(num_rules)
    rule_class_coverage = np.zeros(num_rules)

    for r_idx, rule in enumerate(rules):
        activated_mask = activation_matrix[:, r_idx] > 0
        activated_weights = activation_matrix[:, r_idx]
        if not np.any(activated_mask):
            continue
        activated_embeddings = sample_embeddings[activated_mask]
        activated_labels = labels[activated_mask]
        activated_strengths = activated_weights[activated_mask]
        predicted_class = rule.get('predicted_class', 0)

        correct_class_mask = activated_labels == predicted_class
        purity = np.sum(activated_strengths[correct_class_mask]) / (np.sum(activated_strengths) + 1e-8)
        rule_purity[r_idx] = purity

        if len(activated_embeddings) > 1:
            centroid = np.mean(activated_embeddings, axis=0)
            distances = np.linalg.norm(activated_embeddings - centroid, axis=1)
            normalized_spread = np.mean(distances) / global_median_dist
            compactness = 1.0 / (1.0 + normalized_spread)
        else:
            compactness = 1.0
        rule_compactness[r_idx] = compactness

        n_class_total = class_count_map.get(predicted_class, 1)
        n_correct_activated = np.sum(correct_class_mask)
        class_coverage = n_correct_activated / n_class_total
        rule_class_coverage[r_idx] = class_coverage

    rule_confidence = np.array([r.get('confidence', 0.0) for r in rules])

    def _safe_minmax(arr):
        rng = arr.max() - arr.min()
        if rng < 1e-12:
            return np.ones_like(arr) * 0.5
        return (arr - arr.min()) / rng

    norm_purity = _safe_minmax(rule_purity)
    norm_compact = _safe_minmax(rule_compactness)
    norm_coverage = _safe_minmax(rule_class_coverage)
    norm_conf = _safe_minmax(rule_confidence)
    rule_scores = 0.35 * norm_purity + 0.15 * norm_compact + 0.15 * norm_coverage + 0.35 * norm_conf

    binary_activation = (activation_matrix > 0).astype(np.float32)

    def _jaccard_similarity(vec_a, vec_b):
        intersection = np.sum(np.minimum(vec_a, vec_b))
        union = np.sum(np.maximum(vec_a, vec_b))
        return intersection / (union + 1e-12)

    mode = str(selection_mode or 'adaptive').strip().lower()
    fixed_sparsity = _normalize_target_sparsity(0.5 if target_sparsity is None else target_sparsity)

    if mode == 'fixed':
        target_total = _compute_target_keep(num_rules, fixed_sparsity)
        target_source = 'fixed_sparsity'
        adaptive_meta = {'source': target_source, 'elbow_keep': 0, 'quality_keep': 0, 'redundancy': 0.0}
    elif mode == 'hybrid':
        adaptive_keep, adaptive_meta = _compute_adaptive_target_keep(
            num_rules, rule_scores, binary_activation=binary_activation)
        fixed_keep = _compute_target_keep(num_rules, fixed_sparsity)
        target_total = min(adaptive_keep, fixed_keep)
        target_source = 'hybrid_min'
    else:
        target_total, adaptive_meta = _compute_adaptive_target_keep(
            num_rules, rule_scores, binary_activation=binary_activation)
        target_source = 'adaptive'
    minority_rule_indices = [i for i, r in enumerate(rules) if r.get('predicted_class') == minority_class]
    majority_rule_indices = [i for i, r in enumerate(rules) if r.get('predicted_class') != minority_class]

    n_minority_total = class_count_map.get(minority_class, 1)
    n_majority_total = sum(v for k, v in class_count_map.items() if k != minority_class)
    ir = n_majority_total / (n_minority_total + 1e-8)
    minority_quota_ratio = np.clip(0.4 + 0.02 * (ir - 2), 0.4, 0.6)

    def _greedy_select_with_redundancy(indices, scores, quota, activation_bin, redundancy_threshold=0.8):
        sorted_pairs = sorted([(i, scores[i]) for i in indices], key=lambda x: x[1], reverse=True)
        selected = []
        for idx, score in sorted_pairs:
            if len(selected) >= quota:
                break
            is_redundant = False
            for sel_idx in selected:
                sim = _jaccard_similarity(activation_bin[:, idx], activation_bin[:, sel_idx])
                if sim > redundancy_threshold:
                    is_redundant = True
                    break
            if not is_redundant:
                selected.append(idx)
        return selected

    selected_indices = []
    fallback_used = False
    fallback_reason = ''
    if minority_rule_indices and majority_rule_indices:
        min_minority_quota = max(1, min(len(minority_rule_indices), int(target_total * minority_quota_ratio)))
        min_majority_quota = max(1, min(len(majority_rule_indices), target_total - min_minority_quota))
        selected_minority = _greedy_select_with_redundancy(
            minority_rule_indices, rule_scores, min_minority_quota, binary_activation)
        selected_majority = _greedy_select_with_redundancy(
            majority_rule_indices, rule_scores, min_majority_quota, binary_activation)
        selected_indices = selected_minority + selected_majority
    else:
        all_indices = minority_rule_indices or majority_rule_indices
        selected_indices = _greedy_select_with_redundancy(
            all_indices, rule_scores, target_total, binary_activation)

    selected_indices = list(dict.fromkeys(selected_indices))

    # 保底策略：避免规则筛选后为空，优先每类至少保留一条高分规则。
    if len(selected_indices) == 0:
        fallback_used = True
        fallback_reason = 'empty_after_greedy'
        class_to_indices = {}
        for i, rule in enumerate(rules):
            cls = int(rule.get('predicted_class', 0))
            class_to_indices.setdefault(cls, []).append(i)

        for class_indices in class_to_indices.values():
            best_idx = max(class_indices, key=lambda idx: rule_scores[idx])
            selected_indices.append(best_idx)

    target_keep = min(num_rules, max(1, target_total))
    if len(selected_indices) < target_keep:
        ranked_indices = np.argsort(-rule_scores).tolist()
        for idx in ranked_indices:
            if idx not in selected_indices:
                selected_indices.append(idx)
            if len(selected_indices) >= target_keep:
                break

    # 最终硬截断，避免异常路径导致超过目标保留数。
    if len(selected_indices) > target_keep:
        ranked_indices = np.argsort(-rule_scores).tolist()
        selected_set = set(selected_indices)
        selected_indices = [idx for idx in ranked_indices if idx in selected_set][:target_keep]

    selected_rules = [rules[i] for i in selected_indices]
    selected_counts = _count_rules_by_class(selected_rules)
    metadata = {
        'num_rules': num_rules,
        'selected_count': len(selected_rules),
        'fallback_used': fallback_used,
        'fallback_reason': fallback_reason,
        'target_total': target_total,
        'target_sparsity_used': fixed_sparsity,
        'target_source': target_source,
        'selection_mode': mode,
        'adaptive_signals': adaptive_meta,
        'selected_counts_by_class': selected_counts,
    }

    if verbose:
        n_minority_selected = sum(1 for r in selected_rules if r.get('predicted_class') == minority_class)
        print(f"  规则选择: {num_rules} -> {len(selected_rules)} (IR={ir:.1f})")

    return (selected_rules, metadata) if return_metadata else selected_rules


def run_full_rg_gnn_earc(data_dict, device, random_seed,
                          lambda_rule=None, use_ds_fusion=None,
                          enable_rule_selection=None, num_synthetic_override=None,
                          forced_alpha=None):
    """
    运行完整的GNN-EAR流程（6阶段）

    Args:
        data_dict: prepare_data返回的数据字典
        device: 计算设备
        random_seed: 随机种子
        lambda_rule: 覆盖规则一致性损失权重（None使用Config默认值）
        use_ds_fusion: 覆盖是否使用DS融合（None使用Config默认值）
        enable_rule_selection: 覆盖是否启用规则选择（None使用Config默认值）
        num_synthetic_override: 覆盖生成样本数（0=禁用过采样）
        forced_alpha: 强制使用特定alpha值（跳过网格搜索）

    Returns:
        results: 实验结果字典
    """
    set_seed(random_seed)

    features = data_dict['features']
    labels = data_dict['labels']
    x = data_dict['x']
    y = data_dict['y']
    edge_index = data_dict['edge_index']
    train_mask = data_dict['train_mask']
    val_mask = data_dict['val_mask']
    test_mask = data_dict['test_mask']
    train_idx = data_dict['train_idx']
    minority_class = data_dict['minority_class']
    n_classes = data_dict['n_classes']
    n_features = data_dict['n_features']

    # 参数覆盖
    _lambda_rule = lambda_rule if lambda_rule is not None else Config.LAMBDA_RULE
    _use_ds_fusion = use_ds_fusion if use_ds_fusion is not None else Config.USE_DS_FUSION
    _enable_rule_selection = enable_rule_selection if enable_rule_selection is not None else getattr(Config, 'ENABLE_RULE_SELECTION', False)

    # 日志前缀（缩进，保持与主实验的树状结构对齐）
    _P = "  │        "  # 阶段内子行前缀

    # ===== 阶段1: EARC规则挖掘 =====
    import time as _time
    _t1 = _time.time()
    train_features = features[train_idx]
    train_labels = labels[train_idx]

    earc = EARCClassifier(
        num_fuzzy_sets=Config.NUM_FUZZY_SETS,
        min_support=Config.MIN_SUPPORT,
        min_confidence=Config.MIN_CONFIDENCE,
        max_rule_length=Config.MAX_RULE_LENGTH,
        top_k_rules=Config.TOP_K_RULES,
        support_decay=getattr(Config, 'SUPPORT_DECAY', 1.0),
        min_support_floor=getattr(Config, 'MIN_SUPPORT_FLOOR', 0.0),
        enable_rule_selection=False
    )
    earc.fit(train_features, train_labels, minority_class=minority_class, device=device)
    constraints = earc.get_constraints()
    grouped_constraints = earc.get_grouped_constraints()
    print(f"\n{_P}[1/6] EARC规则挖掘  {len(earc.rules)}条规则, {len(constraints)}个约束 ({_time.time()-_t1:.1f}s)")

    # ===== 阶段2: 构建模型 =====
    _t2 = _time.time()
    encoder = build_encoder(
        gnn_type=Config.GNN_TYPE, in_dim=n_features,
        hidden_dim=Config.HIDDEN_DIM, embedding_dim=Config.EMBEDDING_DIM,
        num_layers=Config.NUM_GNN_LAYERS, num_heads=Config.NUM_HEADS,
        dropout=Config.DROPOUT
    )
    decoder = MLPDecoder(
        embedding_dim=Config.EMBEDDING_DIM, hidden_dim=Config.DECODER_HIDDEN_DIM,
        output_dim=n_features, num_layers=Config.DECODER_NUM_LAYERS,
        dropout=Config.DROPOUT
    )
    classifier = Classifier(
        embedding_dim=Config.EMBEDDING_DIM, num_classes=n_classes,
        hidden_dim=Config.HIDDEN_DIM // 2
    )
    edge_predictor = EdgePredictor(embedding_dim=Config.EMBEDDING_DIM, hidden_dim=64)

    model = RuleGuidedGraphSMOTE(
        encoder=encoder, decoder=decoder, classifier=classifier,
        edge_predictor=edge_predictor, smote_k=Config.SMOTE_K,
        interpolation_method=Config.INTERPOLATION_METHOD
    )
    _n_params = sum(p.numel() for p in model.parameters())
    print(f"{_P}[2/6] 构建模型      {Config.GNN_TYPE} {_n_params:,}参数 ({_time.time()-_t2:.1f}s)")

    # ===== 阶段3: 训练模型 =====
    _t3 = _time.time()
    rule_loss_fn = RuleLoss(constraints, grouped_constraints=grouped_constraints)
    combined_loss_fn = CombinedLoss(
        lambda_class=Config.LAMBDA_CLASS, lambda_recon=Config.LAMBDA_RECON,
        lambda_rule=_lambda_rule, lambda_edge=Config.LAMBDA_EDGE,
        class_weights=None
    )

    trainer = Trainer(model, rule_loss_fn, combined_loss_fn, device=device)
    trainer.setup_optimizer(learning_rate=Config.LEARNING_RATE, weight_decay=Config.WEIGHT_DECAY)

    # 计算合成样本数
    minority_count = (y[train_mask] == minority_class).sum().item()
    majority_count = (y[train_mask] != minority_class).sum().item()
    if num_synthetic_override is not None:
        num_synthetic = num_synthetic_override
    else:
        num_synthetic = max(0, int((majority_count * Config.SMOTE_RATIO) - minority_count))

    history = trainer.train(
        x=x, edge_index=edge_index, labels=y,
        train_mask=train_mask, val_mask=val_mask,
        minority_class=minority_class,
        num_epochs=Config.NUM_EPOCHS, num_synthetic=num_synthetic,
        patience=Config.PATIENCE, log_interval=50, save_path=None
    )
    print(f"{_P}[3/6] 训练完成      epoch={history['best_epoch']}/{Config.NUM_EPOCHS} 合成={num_synthetic} λ_rule={_lambda_rule} ({_time.time()-_t3:.1f}s)")

    # ===== 阶段4: 生成平衡数据集 =====
    _t4 = _time.time()
    if num_synthetic > 0:
        x_balanced, edge_index_balanced, y_balanced = model.generate_balanced_data(
            x=x, edge_index=edge_index, labels=y,
            minority_class=minority_class, balance_ratio=Config.SMOTE_RATIO
        )
        print(f"{_P}[4/6] 生成平衡数据   {x.shape[0]}->{x_balanced.shape[0]}样本 ({_time.time()-_t4:.1f}s)")
    else:
        x_balanced, edge_index_balanced, y_balanced = x, edge_index, y
        print(f"{_P}[4/6] 生成平衡数据   跳过(num_synthetic=0) ({_time.time()-_t4:.1f}s)")

    # ===== 阶段5: 测试集评估（GNN基础性能） =====
    _t5 = _time.time()
    test_metrics = trainer.evaluate(x, edge_index, y, test_mask, minority_class)

    y_true = y[test_mask].cpu().numpy()
    y_pred, y_probs = trainer.get_predictions(x, edge_index, y, minority_class)
    y_pred_test = y_pred[test_mask.cpu().numpy()]
    gmean = calculate_gmean(y_true, y_pred_test)

    gnn_f1_macro = test_metrics['f1_macro']
    gnn_f1_minority = test_metrics['f1_minority']
    gnn_auc = test_metrics['auc']
    print(f"{_P}[5/6] GNN基础评估   F1m={gnn_f1_macro:.4f} F1min={gnn_f1_minority:.4f} AUC={gnn_auc:.4f} ({_time.time()-_t5:.1f}s)")

    # ===== 阶段6: EARC融合推理 =====
    _t6 = _time.time()
    fusion_f1_macro = gnn_f1_macro
    fusion_f1_minority = gnn_f1_minority
    fusion_auc = gnn_auc
    fusion_gmean = gmean
    fusion_acc = test_metrics['acc']
    best_alpha = 1.0
    n_rules_stage1 = len(earc.rules)
    stage1_counts = _count_rules_by_class(earc.rules, n_classes=n_classes)

    n_rules_fusion_raw = n_rules_stage1
    fusion_raw_counts = dict(stage1_counts)
    n_rules_final = n_rules_stage1
    final_counts = dict(stage1_counts)

    n_rules_minority = stage1_counts.get(int(minority_class), 0)
    n_rules_majority = n_rules_final - n_rules_minority
    rule_selection_status = 'disabled' if not _enable_rule_selection else 'not_run'
    rule_selection_error = ''
    rule_selection_fallback = False
    rule_selection_fallback_reason = ''
    target_keep = n_rules_final
    target_keep_source = 'not_applicable'

    if _use_ds_fusion:
        _, gnn_probs = trainer.get_predictions(x, edge_index, y, minority_class)

        features_balanced = x_balanced.cpu().numpy()
        labels_balanced = y_balanced.cpu().numpy()

        earc_final = EARCClassifier(
            num_fuzzy_sets=Config.NUM_FUZZY_SETS,
            min_support=Config.MIN_SUPPORT * 0.5,
            min_confidence=Config.MIN_CONFIDENCE * 0.9,
            max_rule_length=Config.MAX_RULE_LENGTH,
            top_k_rules=Config.TOP_K_RULES,
            support_decay=getattr(Config, 'SUPPORT_DECAY', 1.0),
            min_support_floor=getattr(Config, 'MIN_SUPPORT_FLOOR', 0.0),
            enable_rule_selection=False
        )
        earc_final.fit(features_balanced, labels_balanced, minority_class=minority_class, device=device)
        n_rules_fusion_raw = len(earc_final.rules)
        fusion_raw_counts = _count_rules_by_class(earc_final.rules, n_classes=n_classes)
        selection_mode = getattr(Config, 'RULE_SELECTION_MODE', 'adaptive')
        target_sparsity = getattr(Config, 'RULE_SELECTION_TARGET_SPARSITY', None)
        target_keep = max(1, n_rules_fusion_raw - 1) if n_rules_fusion_raw > 1 else n_rules_fusion_raw
        target_keep_source = 'pre_default'

        # 规则选择
        # 先计算一次，保证异常分支也可重估规则可靠性。
        fuzzy_features_balanced = earc_final.fuzzifier.transform(features_balanced)
        if _enable_rule_selection and len(earc_final.rules) > 0:
            try:
                from src.core.hetero_graph import RuleSampleHeteroGraph
                from src.utils import build_knn_graph
                hetero_graph = RuleSampleHeteroGraph(
                    rules=earc_final.rules, fuzzy_features=fuzzy_features_balanced,
                    labels=labels_balanced, num_classes=n_classes
                )
                activation_matrix = hetero_graph.activation_matrix

                adj_balanced, _ = build_knn_graph(features_balanced, k=Config.KNN_K, metric=Config.GRAPH_METRIC)
                edge_index_balanced_new = torch.LongTensor(np.array(np.where(adj_balanced > 0))).to(device)

                model.eval()
                with torch.no_grad():
                    sample_embeddings = model.encoder(x_balanced, edge_index_balanced_new)

                selected_rules, selection_meta = unified_rule_selection(
                    rules=earc_final.rules,
                    sample_embeddings=sample_embeddings.cpu().numpy(),
                    activation_matrix=activation_matrix,
                    labels=labels_balanced, minority_class=minority_class,
                    target_sparsity=target_sparsity,
                    selection_mode=selection_mode,
                    verbose=False,
                    return_metadata=True
                )
                earc_final.rules = selected_rules
                target_keep = int(selection_meta.get('target_total', target_keep))
                target_keep_source = str(selection_meta.get('target_source', target_keep_source))
                earc_final.rule_reliability = earc_final._estimate_rule_reliability(
                    fuzzy_features_balanced, labels_balanced, selected_rules
                )
                # 更新少数类/多数类规则统计
                earc_final.minority_rules = [r for r in earc_final.rules if r.get('predicted_class', 0) == minority_class]
                earc_final.majority_rules = [r for r in earc_final.rules if r.get('predicted_class', 0) != minority_class]
                rule_selection_status = 'ok'
                rule_selection_fallback = bool(selection_meta.get('fallback_used', False))
                rule_selection_fallback_reason = selection_meta.get('fallback_reason', '')
            except Exception as e:
                rule_selection_status = 'error_fallback'
                rule_selection_error = str(e)
                earc_final.rules = _fallback_select_rules(
                    earc_final.rules, target_keep=target_keep, minority_class=minority_class
                )
                earc_final.rule_reliability = earc_final._estimate_rule_reliability(
                    fuzzy_features_balanced, labels_balanced, earc_final.rules
                )
                earc_final.minority_rules = [r for r in earc_final.rules if r.get('predicted_class', 0) == minority_class]
                earc_final.majority_rules = [r for r in earc_final.rules if r.get('predicted_class', 0) != minority_class]
                print(f"{_P}⚠  规则选择失败，已降级为确定性筛选: {rule_selection_error[:120]}")
        elif _enable_rule_selection:
            rule_selection_status = 'no_raw_rules'

        # 兜底硬约束：启用筛选且存在压缩空间时，最终规则数不应回到原始上限。
        if _enable_rule_selection and len(earc_final.rules) > 0 and target_keep < n_rules_fusion_raw:
            if len(earc_final.rules) > target_keep or len(earc_final.rules) == n_rules_fusion_raw:
                earc_final.rules = _fallback_select_rules(
                    earc_final.rules, target_keep=target_keep, minority_class=minority_class
                )
                earc_final.rule_reliability = earc_final._estimate_rule_reliability(
                    fuzzy_features_balanced, labels_balanced, earc_final.rules
                )
                earc_final.minority_rules = [r for r in earc_final.rules if r.get('predicted_class', 0) == minority_class]
                earc_final.majority_rules = [r for r in earc_final.rules if r.get('predicted_class', 0) != minority_class]
                if rule_selection_status == 'ok':
                    rule_selection_status = 'ok_hard_cap'

        n_rules_final = len(earc_final.rules)
        final_counts = _count_rules_by_class(earc_final.rules, n_classes=n_classes)
        n_rules_minority = final_counts.get(int(minority_class), 0)
        n_rules_majority = n_rules_final - n_rules_minority

        # 融合推理
        val_indices = val_mask.cpu().numpy()
        test_indices = test_mask.cpu().numpy()
        val_labels = y[val_mask].cpu().numpy()
        test_labels = y[test_mask].cpu().numpy()

        val_features = features[val_indices]
        test_features = features[test_indices]
        val_gnn_probs = gnn_probs[val_indices]
        test_gnn_probs = gnn_probs[test_indices]

        def get_earc_probs(dataset_features):
            probs = []
            dataset_fuzzy = earc_final.fuzzifier.transform(dataset_features)
            for i in range(len(dataset_features)):
                mass = earc_final.evidential_reasoner.compute_mass_from_rules(
                    dataset_fuzzy[i], earc_final.rules, dataset_fuzzy
                )
                belief = mass[:-1]
                ignorance = mass[-1]
                p_prob = belief + ignorance / n_classes
                p_sum = p_prob.sum()
                if p_sum > 1e-8:
                    p_prob = p_prob / p_sum
                else:
                    p_prob = np.ones(n_classes) / n_classes
                probs.append(p_prob)
            return np.array(probs)

        val_earc_probs = get_earc_probs(val_features)
        test_earc_probs = get_earc_probs(test_features)

        if forced_alpha is not None:
            best_alpha = forced_alpha
        else:
            # ========== 改进的加权融合策略（与keel_experiments.py一致） ==========
            # 两阶段策略：
            # 阶段A: 在验证集上网格搜索最佳 alpha（综合评分 = 0.6*F1 + 0.4*MinorityF1）
            # 阶段B: 如果最佳 alpha 过于偏向 GNN (≥0.9)，根据 EARC 在少数类上的
            #        相对优势动态保留最小规则权重（在可接受的性能下降内）

            # 首先评估纯GNN和纯EARC的性能
            gnn_val_preds = np.argmax(val_gnn_probs, axis=1)
            earc_val_preds = np.argmax(val_earc_probs, axis=1)

            gnn_val_f1 = f1_score(val_labels, gnn_val_preds, average='macro')
            earc_val_f1 = f1_score(val_labels, earc_val_preds, average='macro')

            # 计算GNN和EARC在少数类上的召回率
            gnn_minority_recall = recall_score(val_labels, gnn_val_preds,
                                               labels=[minority_class], average='macro', zero_division=0)
            earc_minority_recall = recall_score(val_labels, earc_val_preds,
                                                labels=[minority_class], average='macro', zero_division=0)

            # ===== 阶段A: 网格搜索最佳 alpha =====
            best_alpha = 0.5
            best_combined_score = -1.0
            best_val_f1 = -1.0
            best_minority_f1 = -1.0

            alpha_candidates = np.linspace(0.0, 1.0, 21)

            for alpha in alpha_candidates:
                fused_val = alpha * val_gnn_probs + (1.0 - alpha) * val_earc_probs
                pred_val = np.argmax(fused_val, axis=1)

                val_f1 = f1_score(val_labels, pred_val, average='macro')
                minority_f1 = f1_score(val_labels, pred_val, labels=[minority_class],
                                       average='macro', zero_division=0)

                combined_score = 0.6 * val_f1 + 0.4 * minority_f1

                if combined_score > best_combined_score:
                    best_combined_score = combined_score
                    best_val_f1 = val_f1
                    best_minority_f1 = minority_f1
                    best_alpha = alpha

            # ===== 阶段B: 最小规则权重保障 =====
            # 当 alpha >= 0.9 时，检查 EARC 是否对少数类有互补价值
            # 如果 EARC 在少数类召回率上有优势，则在可接受的 F1 下降容忍度内
            # 保留一定的规则权重
            if best_alpha >= 0.9:
                earc_advantage = earc_minority_recall - gnn_minority_recall
                earc_relative = earc_val_f1 / (gnn_val_f1 + 1e-8)

                # 容忍度 = 2% 基础 + EARC少数类优势的一半（越有优势越容忍）
                tolerance = 0.02 + max(0, earc_advantage) * 0.5

                # 根据 EARC 相对性能确定尝试的规则权重
                if earc_relative >= 0.85:
                    candidate_rule_weights = [0.20, 0.15, 0.10, 0.05]
                elif earc_relative >= 0.70:
                    candidate_rule_weights = [0.15, 0.10, 0.05]
                else:
                    candidate_rule_weights = [0.10, 0.05]

                for rule_weight in candidate_rule_weights:
                    test_alpha = 1.0 - rule_weight
                    fused_val = test_alpha * val_gnn_probs + (1.0 - test_alpha) * val_earc_probs
                    pred_val = np.argmax(fused_val, axis=1)
                    test_f1 = f1_score(val_labels, pred_val, average='macro')

                    f1_drop = gnn_val_f1 - test_f1
                    if f1_drop <= tolerance:
                        best_alpha = test_alpha
                        best_val_f1 = test_f1
                        break

        # 测试集融合
        final_probs = best_alpha * test_gnn_probs + (1.0 - best_alpha) * test_earc_probs
        fusion_preds = np.argmax(final_probs, axis=1)

        fusion_acc = accuracy_score(test_labels, fusion_preds)
        fusion_f1_macro = f1_score(test_labels, fusion_preds, average='macro')
        fusion_f1_minority = f1_score(test_labels, fusion_preds, labels=[minority_class],
                                      average='macro', zero_division=0)
        fusion_gmean = calculate_gmean(test_labels, fusion_preds)

        try:
            if n_classes == 2:
                fusion_auc = roc_auc_score(test_labels, final_probs[:, 1])
            else:
                fusion_auc = roc_auc_score(test_labels, final_probs, multi_class='ovr', average='macro')
        except Exception:
            fusion_auc = gnn_auc

    _t6_elapsed = _time.time() - _t6
    if _use_ds_fusion:
        _gain = fusion_f1_macro - gnn_f1_macro
        _sign = '+' if _gain >= 0 else ''
        print(f"{_P}[6/6] DS证据融合    α*={best_alpha:.2f} F1m={fusion_f1_macro:.4f}({_sign}{_gain:.4f}) ({_t6_elapsed:.1f}s)")
    else:
        print(f"{_P}[6/6] DS证据融合    跳过(use_ds_fusion=False) ({_t6_elapsed:.1f}s)")

    results = {
        'f1_macro': fusion_f1_macro,
        'f1_minority': fusion_f1_minority,
        'auc': fusion_auc,
        'gmean': fusion_gmean,
        'gnn_f1_macro': gnn_f1_macro,
        'gnn_f1_minority': gnn_f1_minority,
        'gnn_auc': gnn_auc,
        'gnn_gmean': gmean,
        'best_alpha': best_alpha,
        'best_epoch': history['best_epoch'],
        'n_rules': n_rules_final,
        'n_rules_stage1': n_rules_stage1,
        'n_rules_fusion_raw': n_rules_fusion_raw,
        'n_rules_final': n_rules_final,
        'n_rules_minority': n_rules_minority,
        'n_rules_majority': n_rules_majority,
        'rule_selection_status': rule_selection_status,
        'rule_selection_error': rule_selection_error,
        'rule_selection_fallback': int(rule_selection_fallback),
        'rule_selection_fallback_reason': rule_selection_fallback_reason,
        'rule_selection_mode': str(getattr(Config, 'RULE_SELECTION_MODE', 'adaptive')),
        'rule_selection_target_keep': int(target_keep),
        'rule_selection_target_source': target_keep_source,
        'rule_counts_stage1_json': json.dumps({str(k): int(v) for k, v in stage1_counts.items()}, sort_keys=True),
        'rule_counts_fusion_raw_json': json.dumps({str(k): int(v) for k, v in fusion_raw_counts.items()}, sort_keys=True),
        'rule_counts_final_json': json.dumps({str(k): int(v) for k, v in final_counts.items()}, sort_keys=True),
        'accuracy': fusion_acc,
    }

    for cls_idx in range(int(n_classes)):
        results[f'rule_count_stage1_cls_{cls_idx}'] = int(stage1_counts.get(cls_idx, 0))
        results[f'rule_count_fusion_raw_cls_{cls_idx}'] = int(fusion_raw_counts.get(cls_idx, 0))
        results[f'rule_count_final_cls_{cls_idx}'] = int(final_counts.get(cls_idx, 0))

    return results, model, trainer


def run_baseline_gnn_only(data_dict, device, random_seed, gnn_type='GCN'):
    """
    运行基线GNN模型（纯GCN/GAT，无过采样、无规则）

    Args:
        data_dict: prepare_data返回的数据字典
        device: 计算设备
        random_seed: 随机种子
        gnn_type: GNN类型 ('GCN' 或 'GAT')

    Returns:
        results: 实验结果字典
    """
    set_seed(random_seed)

    x = data_dict['x']
    y = data_dict['y']
    edge_index = data_dict['edge_index']
    train_mask = data_dict['train_mask']
    val_mask = data_dict['val_mask']
    test_mask = data_dict['test_mask']
    minority_class = data_dict['minority_class']
    n_classes = data_dict['n_classes']
    n_features = data_dict['n_features']

    encoder = build_encoder(
        gnn_type=gnn_type, in_dim=n_features,
        hidden_dim=Config.HIDDEN_DIM, embedding_dim=Config.EMBEDDING_DIM,
        num_layers=Config.NUM_GNN_LAYERS, num_heads=Config.NUM_HEADS,
        dropout=Config.DROPOUT
    )
    decoder = MLPDecoder(
        embedding_dim=Config.EMBEDDING_DIM, hidden_dim=Config.DECODER_HIDDEN_DIM,
        output_dim=n_features, num_layers=Config.DECODER_NUM_LAYERS,
        dropout=Config.DROPOUT
    )
    classifier_model = Classifier(
        embedding_dim=Config.EMBEDDING_DIM, num_classes=n_classes,
        hidden_dim=Config.HIDDEN_DIM // 2
    )
    edge_predictor = EdgePredictor(embedding_dim=Config.EMBEDDING_DIM, hidden_dim=64)

    model = RuleGuidedGraphSMOTE(
        encoder=encoder, decoder=decoder, classifier=classifier_model,
        edge_predictor=edge_predictor, smote_k=Config.SMOTE_K,
        interpolation_method=Config.INTERPOLATION_METHOD
    )

    # 使用空规则约束，标准交叉熵训练
    rule_loss_fn = RuleLoss([], grouped_constraints=[])
    combined_loss_fn = CombinedLoss(
        lambda_class=1.0, lambda_recon=0.0, lambda_rule=0.0, lambda_edge=0.0,
        class_weights=None
    )

    trainer = Trainer(model, rule_loss_fn, combined_loss_fn, device=device)
    trainer.setup_optimizer(learning_rate=Config.LEARNING_RATE, weight_decay=Config.WEIGHT_DECAY)

    history = trainer.train(
        x=x, edge_index=edge_index, labels=y,
        train_mask=train_mask, val_mask=val_mask,
        minority_class=minority_class,
        num_epochs=Config.NUM_EPOCHS, num_synthetic=0,
        patience=Config.PATIENCE, log_interval=50, save_path=None
    )

    test_metrics = trainer.evaluate(x, edge_index, y, test_mask, minority_class)
    y_true = y[test_mask].cpu().numpy()
    y_pred, _ = trainer.get_predictions(x, edge_index, y, minority_class)
    y_pred_test = y_pred[test_mask.cpu().numpy()]
    gmean = calculate_gmean(y_true, y_pred_test)

    return {
        'f1_macro': test_metrics['f1_macro'],
        'f1_minority': test_metrics['f1_minority'],
        'auc': test_metrics['auc'],
        'gmean': gmean,
        'accuracy': test_metrics['acc'],
    }


def run_earc_only(data_dict, device, random_seed):
    """
    运行纯EARC分类器（无GNN）

    Returns:
        results: 实验结果字典
    """
    set_seed(random_seed)

    features = data_dict['features']
    labels = data_dict['labels']
    train_idx = data_dict['train_idx']
    test_mask = data_dict['test_mask']
    minority_class = data_dict['minority_class']
    n_classes = data_dict['n_classes']
    y = data_dict['y']

    train_features = features[train_idx]
    train_labels = labels[train_idx]

    earc = EARCClassifier(
        num_fuzzy_sets=Config.NUM_FUZZY_SETS,
        min_support=Config.MIN_SUPPORT,
        min_confidence=Config.MIN_CONFIDENCE,
        max_rule_length=Config.MAX_RULE_LENGTH,
        top_k_rules=Config.TOP_K_RULES,
        enable_rule_selection=False
    )
    earc.fit(train_features, train_labels, minority_class=minority_class, device=device)

    test_indices = test_mask.cpu().numpy()
    test_features = features[test_indices]
    test_labels = labels[test_indices]

    # EARC Pignistic概率预测
    test_fuzzy = earc.fuzzifier.transform(test_features)
    probs = []
    for i in range(len(test_features)):
        mass = earc.evidential_reasoner.compute_mass_from_rules(
            test_fuzzy[i], earc.rules, test_fuzzy
        )
        belief = mass[:-1]
        ignorance = mass[-1]
        p_prob = belief + ignorance / n_classes
        p_sum = p_prob.sum()
        if p_sum > 1e-8:
            p_prob = p_prob / p_sum
        else:
            p_prob = np.ones(n_classes) / n_classes
        probs.append(p_prob)
    probs = np.array(probs)
    preds = np.argmax(probs, axis=1)

    f1_macro = f1_score(test_labels, preds, average='macro')
    f1_minority = f1_score(test_labels, preds, labels=[minority_class], average='macro', zero_division=0)
    gmean = calculate_gmean(test_labels, preds)

    try:
        if n_classes == 2:
            auc = roc_auc_score(test_labels, probs[:, 1])
        else:
            auc = roc_auc_score(test_labels, probs, multi_class='ovr', average='macro')
    except Exception:
        auc = 0.5

    return {
        'f1_macro': f1_macro,
        'f1_minority': f1_minority,
        'auc': auc,
        'gmean': gmean,
        'accuracy': accuracy_score(test_labels, preds),
    }


def generate_comparison_latex_table(summary_df, methods, caption="实验结果对比", label="tab:comparison"):
    """
    生成多方法对比的LaTeX表格

    Args:
        summary_df: DataFrame, columns=[dataset, method, metric_mean, metric_std]
        methods: 方法名列表
        caption: 表格标题
        label: 表格标签

    Returns:
        latex_str: LaTeX表格字符串
    """
    n_metrics = len(METRICS)
    latex = f"""\\begin{{table*}}[htbp]
\\centering
\\caption{{{caption}}}
\\label{{{label}}}
\\resizebox{{\\textwidth}}{{!}}{{%
\\begin{{tabular}}{{l{'c' * (len(methods) * n_metrics)}}}
\\toprule
"""

    # 表头 - 方法名
    header1 = "Dataset"
    for m in methods:
        header1 += f" & \\multicolumn{{{n_metrics}}}{{c}}{{{m}}}"
    header1 += r" \\" + "\n"

    # 表头 - 指标名
    header2 = ""
    for m in methods:
        for metric in METRICS:
            header2 += f" & {metric}"
    header2 += r" \\" + "\n"

    latex += header1
    latex += f"\\cmidrule(lr){{2-{1 + len(methods) * n_metrics}}}\n"
    latex += header2
    latex += "\\midrule\n"

    datasets = summary_df['dataset'].unique()
    for ds in datasets:
        row = f"{ds:15s}"
        for method in methods:
            for metric in METRICS:
                mask = (summary_df['dataset'] == ds) & (summary_df['method'] == method)
                subset = summary_df[mask]
                if len(subset) > 0:
                    mean_val = subset[f'{metric}_mean'].values[0]
                    std_val = subset[f'{metric}_std'].values[0]
                    row += f" & ${mean_val:.3f}_{{\\pm{std_val:.3f}}}$"
                else:
                    row += " & -"
        row += r" \\" + "\n"
        latex += row

    latex += """\\bottomrule
\\end{tabular}%
}
\\end{table*}
"""
    return latex


def save_results_csv(results_list, output_path):
    """保存结果列表为CSV"""
    df = pd.DataFrame(results_list)
    df.to_csv(output_path, index=False)
    print(f"结果已保存: {output_path}")
    return df


def compute_summary(results_df, group_cols=None):
    """计算分组统计摘要"""
    if group_cols is None:
        group_cols = ['dataset', 'method']
    agg_dict = {}
    for metric in METRICS:
        agg_dict[metric] = ['mean', 'std']
    if 'accuracy' in results_df.columns:
        agg_dict['accuracy'] = ['mean', 'std']

    summary_prefixes = (
        'n_rules',
        'rule_count_stage1_cls_',
        'rule_count_fusion_raw_cls_',
        'rule_count_final_cls_',
    )
    for col in results_df.columns:
        if col in group_cols:
            continue
        if col.startswith(summary_prefixes) and pd.api.types.is_numeric_dtype(results_df[col]):
            agg_dict[col] = ['mean', 'std']

    summary = results_df.groupby(group_cols).agg(agg_dict).round(4)
    # 扁平化列名
    summary.columns = [f'{col[0]}_{col[1]}' for col in summary.columns]
    summary = summary.reset_index()
    return summary

