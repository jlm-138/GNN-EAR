"""
实验4.4: 超参数敏感性分析

实验设计:
1. 双源融合权重 α* ∈ [0.0, 1.0] 的影响
   - 控制GNN预测与EARC证据推理的权衡
   - 遍历α*从0.0到1.0（步长0.1），强制使用特定值

2. 规则一致性惩罚 λ_rule ∈ [0.0, 1.0] 的影响
   - 控制潜在空间生成器的规则约束强度
   - 需要重新训练模型

- 在4个代表性数据集上运行
- 5折分层交叉验证 × 10次重复

输出:
- experiments/results/sensitivity/  目录下:
  - alpha_results_{timestamp}.csv         : α*扫描结果
  - lambda_rule_results_{timestamp}.csv   : λ_rule扫描结果
  - summary_{timestamp}.csv               : 汇总统计
  - sensitivity_alpha_{timestamp}.pdf     : α*敏感性折线图
  - sensitivity_lambda_rule_{timestamp}.pdf : λ_rule敏感性折线图
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import argparse
import time
import traceback
import numpy as np
import pandas as pd
from datetime import datetime

from experiments.exp_utils import (
    REPRESENTATIVE_DATASETS, SEEDS, N_FOLDS, METRICS,
    setup_experiment_env, prepare_data, run_full_rg_gnn_earc,
    save_results_csv, compute_summary
)

# α* 扫描值
ALPHA_VALUES = np.linspace(0.0, 1.0, 11)  # [0.0, 0.1, 0.2, ..., 1.0]

# λ_rule 扫描值
LAMBDA_RULE_VALUES = np.linspace(0.0, 1.0, 11)  # [0.0, 0.1, 0.2, ..., 1.0]


def run_alpha_sensitivity(datasets, seeds, n_folds, device, output_dir, timestamp):
    """
    运行α*（融合权重）敏感性分析

    α*控制GNN与EARC的融合比例:
    - α*=0: 纯EARC
    - α*=1: 纯GNN
    - α*=0.6~0.8: 通常最优区间
    """
    print(f"\n{'='*60}")
    print(f"α* 融合权重敏感性分析")
    print(f"扫描范围: {ALPHA_VALUES}")
    print(f"{'='*60}")

    all_results = []
    total = len(datasets) * len(ALPHA_VALUES) * len(seeds) * n_folds
    current = 0

    for dataset_name in datasets:
        print(f"\n  数据集: {dataset_name}")

        for repeat_idx, seed in enumerate(seeds):
            for fold in range(n_folds):
                try:
                    data_dict = prepare_data(dataset_name, fold, seed, device)
                except Exception as e:
                    print(f"    数据加载失败: {e}")
                    continue

                # 对每个α值，训练一次完整模型，但在融合时强制使用指定α
                for alpha in ALPHA_VALUES:
                    current += 1
                    try:
                        results, _, _ = run_full_rg_gnn_earc(
                            data_dict, device, seed,
                            forced_alpha=alpha
                        )

                        record = {
                            'dataset': dataset_name,
                            'param_name': 'alpha',
                            'param_value': float(alpha),
                            'repeat': repeat_idx,
                            'fold': fold,
                            'seed': seed,
                        }
                        for metric in METRICS:
                            record[metric] = results.get(metric, 0.0)
                        record['accuracy'] = results.get('accuracy', 0.0)

                        all_results.append(record)

                        if alpha in [0.0, 0.5, 1.0]:
                            print(f"    [{current}/{total}] α={alpha:.1f}: "
                                  f"F1m={record['f1_macro']:.4f} F1min={record['f1_minority']:.4f}")

                    except Exception as e:
                        print(f"    [{current}/{total}] α={alpha:.1f} 失败: {str(e)[:60]}")
                        continue

    if all_results:
        results_df = save_results_csv(all_results,
                                       os.path.join(output_dir, f'alpha_results_{timestamp}.csv'))
        return results_df
    return None


def run_lambda_rule_sensitivity(datasets, seeds, n_folds, device, output_dir, timestamp):
    """
    运行λ_rule（规则一致性惩罚）敏感性分析

    λ_rule控制规则约束强度:
    - λ_rule=0: 无规则约束（纯GraphSMOTE）
    - λ_rule过大: 过度约束生成器，多样性下降
    - λ_rule≈0.3: 通常最优
    """
    print(f"\n{'='*60}")
    print(f"λ_rule 规则一致性惩罚敏感性分析")
    print(f"扫描范围: {LAMBDA_RULE_VALUES}")
    print(f"{'='*60}")

    all_results = []
    total = len(datasets) * len(LAMBDA_RULE_VALUES) * len(seeds) * n_folds
    current = 0

    for dataset_name in datasets:
        print(f"\n  数据集: {dataset_name}")

        for repeat_idx, seed in enumerate(seeds):
            for fold in range(n_folds):
                try:
                    data_dict = prepare_data(dataset_name, fold, seed, device)
                except Exception as e:
                    print(f"    数据加载失败: {e}")
                    continue

                for lambda_val in LAMBDA_RULE_VALUES:
                    current += 1
                    try:
                        # 每个λ_rule值需要重新训练模型
                        results, _, _ = run_full_rg_gnn_earc(
                            data_dict, device, seed,
                            lambda_rule=float(lambda_val)
                        )

                        record = {
                            'dataset': dataset_name,
                            'param_name': 'lambda_rule',
                            'param_value': float(lambda_val),
                            'repeat': repeat_idx,
                            'fold': fold,
                            'seed': seed,
                        }
                        for metric in METRICS:
                            record[metric] = results.get(metric, 0.0)
                        record['accuracy'] = results.get('accuracy', 0.0)

                        all_results.append(record)

                        if lambda_val in [0.0, 0.3, 0.5, 1.0]:
                            print(f"    [{current}/{total}] λ={lambda_val:.1f}: "
                                  f"F1m={record['f1_macro']:.4f} F1min={record['f1_minority']:.4f}")

                    except Exception as e:
                        print(f"    [{current}/{total}] λ={lambda_val:.1f} 失败: {str(e)[:60]}")
                        continue

    if all_results:
        results_df = save_results_csv(all_results,
                                       os.path.join(output_dir, f'lambda_rule_results_{timestamp}.csv'))
        return results_df
    return None


def generate_sensitivity_plot(results_df, param_name, param_values, datasets, save_path):
    """
    生成敏感性分析折线图

    Args:
        results_df: 实验结果DataFrame
        param_name: 参数名 ('alpha' 或 'lambda_rule')
        param_values: 参数值列表
        datasets: 数据集列表
        save_path: 图片保存路径
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    param_label = {
        'alpha': r'$\alpha^*$ (Fusion Weight)',
        'lambda_rule': r'$\lambda_{rule}$ (Rule Consistency Penalty)'
    }.get(param_name, param_name)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle(f'Hyperparameter Sensitivity: {param_label}', fontsize=14, fontweight='bold')

    colors = ['#2196F3', '#FF9800', '#4CAF50', '#F44336']
    markers = ['o', 's', '^', 'D']

    plot_metrics = ['f1_macro', 'f1_minority']
    metric_labels = ['$F1_{macro}$', '$F1_{minority}$']

    for ax_idx, (metric, metric_label) in enumerate(zip(plot_metrics, metric_labels)):
        ax = axes[ax_idx]

        for ds_idx, ds in enumerate(datasets):
            ds_data = results_df[results_df['dataset'] == ds]
            if len(ds_data) == 0:
                continue

            means = []
            stds = []
            for val in param_values:
                val_data = ds_data[np.abs(ds_data['param_value'] - val) < 1e-6]
                if len(val_data) > 0:
                    means.append(val_data[metric].mean())
                    stds.append(val_data[metric].std())
                else:
                    means.append(0)
                    stds.append(0)

            means = np.array(means)
            stds = np.array(stds)

            ax.plot(param_values, means, marker=markers[ds_idx % len(markers)],
                    color=colors[ds_idx % len(colors)], label=ds, linewidth=2,
                    markersize=6)
            ax.fill_between(param_values, means - stds, means + stds,
                           alpha=0.15, color=colors[ds_idx % len(colors)])

        ax.set_xlabel(param_label, fontsize=12)
        ax.set_ylabel(metric_label, fontsize=12)
        ax.set_title(f'{metric_label} vs. {param_label}')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.set_xlim([param_values[0] - 0.05, param_values[-1] + 0.05])

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"敏感性折线图已保存: {save_path}")


def run_sensitivity_analysis(datasets=None, n_repeats=10, n_folds=5,
                             output_dir='./experiments/results/sensitivity',
                             skip_alpha=False, skip_lambda=False):
    """
    运行完整超参数敏感性分析

    Args:
        datasets: 数据集列表
        n_repeats: 重复次数
        n_folds: 折数
        output_dir: 输出目录
        skip_alpha: 是否跳过α扫描
        skip_lambda: 是否跳过λ扫描
    """
    if datasets is None:
        datasets = REPRESENTATIVE_DATASETS

    device, timestamp = setup_experiment_env(output_dir)
    seeds = SEEDS[:n_repeats]

    print(f"\n{'='*80}")
    print(f"实验4.4: 超参数敏感性分析")
    print(f"数据集: {datasets}")
    print(f"{'='*80}\n")

    start_time = time.time()
    all_dfs = []

    # ===== 1. α* 扫描 =====
    if not skip_alpha:
        alpha_df = run_alpha_sensitivity(datasets, seeds, n_folds, device, output_dir, timestamp)
        if alpha_df is not None:
            all_dfs.append(alpha_df)
            try:
                generate_sensitivity_plot(alpha_df, 'alpha', ALPHA_VALUES, datasets,
                                          os.path.join(output_dir, f'sensitivity_alpha_{timestamp}.pdf'))
            except Exception as e:
                print(f"α*图表生成失败: {e}")
    else:
        print("跳过α*扫描")

    # ===== 2. λ_rule 扫描 =====
    if not skip_lambda:
        lambda_df = run_lambda_rule_sensitivity(datasets, seeds, n_folds, device, output_dir, timestamp)
        if lambda_df is not None:
            all_dfs.append(lambda_df)
            try:
                generate_sensitivity_plot(lambda_df, 'lambda_rule', LAMBDA_RULE_VALUES, datasets,
                                          os.path.join(output_dir, f'sensitivity_lambda_rule_{timestamp}.pdf'))
            except Exception as e:
                print(f"λ_rule图表生成失败: {e}")
    else:
        print("跳过λ_rule扫描")

    # ===== 汇总 =====
    if all_dfs:
        combined_df = pd.concat(all_dfs, ignore_index=True)
        combined_df.to_csv(os.path.join(output_dir, f'summary_{timestamp}.csv'), index=False)

    elapsed = time.time() - start_time
    print(f"\n敏感性分析完成! 耗时: {elapsed/3600:.1f}小时")


def main():
    parser = argparse.ArgumentParser(description='实验4.4: 超参数敏感性分析')
    parser.add_argument('--datasets', nargs='+', default=None,
                        help='数据集列表')
    parser.add_argument('--n_repeats', type=int, default=10,
                        help='重复次数')
    parser.add_argument('--n_folds', type=int, default=5,
                        help='交叉验证折数')
    parser.add_argument('--output_dir', type=str,
                        default='./experiments/results/sensitivity',
                        help='输出目录')
    parser.add_argument('--skip_alpha', action='store_true',
                        help='跳过α*扫描')
    parser.add_argument('--skip_lambda', action='store_true',
                        help='跳过λ_rule扫描')
    parser.add_argument('--quick', action='store_true',
                        help='快速测试模式')

    args = parser.parse_args()

    if args.quick:
        args.datasets = args.datasets or ['ecoli1', 'yeast3']
        args.n_repeats = 2
        args.n_folds = 3

    run_sensitivity_analysis(
        datasets=args.datasets,
        n_repeats=args.n_repeats,
        n_folds=args.n_folds,
        output_dir=args.output_dir,
        skip_alpha=args.skip_alpha,
        skip_lambda=args.skip_lambda
    )


if __name__ == "__main__":
    main()
