"""
实验模块
包含GNN-EAR框架的完整学术实验套件

实验结构:
- exp_main_comparison.py    : 4.2节 主实验 - 与8种基线方法的对比
- exp_ablation_study.py     : 4.3节 消融实验 - 4种降级变体
- exp_hyperparameter_sensitivity.py : 4.4节 超参数敏感性分析
- run_all_experiments.py    : 主控脚本 - 顺序运行所有实验
"""

