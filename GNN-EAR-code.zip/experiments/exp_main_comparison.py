"""
实验4.2: 主实验 - GNN-EAR与基线方法的全面对比分析

对应 experiments.md Section 4.2 "Main Results and Comparative Analysis"

实验设计:
- 9种方法: GNN-EAR, GCN, GAT, ReNode, TAM, GraphSMOTE, GraphENS, GraphSHA, EARC
- 14个KEEL基准数据集
- 5折分层交叉验证 × 10次随机种子重复
- 4个评估指标: F1-macro, F1-minority, AUC, G-Mean

输出:
- experiments/results/main_comparison/  目录下:
  - complete_results_{timestamp}.csv    : 每次实验的完整结果
  - summary_{timestamp}.csv             : 分组统计摘要（均值±标准差）
  - table_I_{timestamp}.tex             : LaTeX对比表格（Table I）
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import argparse
import time
import traceback
import numpy as np
import pandas as pd
from datetime import datetime

from experiments.exp_utils import (
    KEEL_DATASETS, SEEDS, N_FOLDS, METRICS,
    setup_experiment_env, prepare_data, run_full_rg_gnn_earc,
    save_results_csv, compute_summary
)
from experiments.baselines import run_baseline

# 所有对比方法
ALL_METHODS = [
    'GNN-EAR',  # 我们的方法
    'GCN',           # 标准GCN
    'GAT',           # 标准GAT
    'ReNode',        # 拓扑感知节点重加权
    'TAM',           # 拓扑感知边际损失
    'GraphSMOTE',    # 标准图过采样
    'GraphENS',      # 邻居感知自我网络合成
    'GraphSHA',      # 困难样本合成
    'EARC',          # 纯EARC分类器
]

# 方法类别标签（用于日志显示）
METHOD_TAGS = {
    'GNN-EAR': '★ Ours  ',
    'GCN':         '  Base  ',
    'GAT':         '  Base  ',
    'ReNode':      '  Topo  ',
    'TAM':         '  Topo  ',
    'GraphSMOTE':  '  Aug   ',
    'GraphENS':    '  Aug   ',
    'GraphSHA':    '  Aug   ',
    'EARC':        '  Symb  ',
}


def _format_elapsed(seconds):
    """格式化时间为 Xh Ym Zs"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    if h > 0:
        return f"{h}h{m:02d}m{s:02d}s"
    elif m > 0:
        return f"{m}m{s:02d}s"
    else:
        return f"{s}s"


def run_single_method_fold(method, data_dict, device, random_seed):
    """
    运行单个方法在单折上的实验

    Returns:
        results: 包含 f1_macro, f1_minority, auc, gmean 的字典
    """
    if method == 'GNN-EAR':
        # 显式传入所有关键参数，确保GNN-EAR完整流程启用：
        #   lambda_rule=0.3  : 启用规则一致性损失约束GraphSMOTE生成
        #   use_ds_fusion=True : 启用Dempster-Shafer证据融合（GNN+EARC双源推理）
        #   enable_rule_selection=True : 启用异构图规则自动选择优化
        #   num_synthetic_override=None : 自动计算过采样数（完全平衡）
        #   forced_alpha=None : 在验证集上自适应搜索最佳融合权重α*
        results, _, _ = run_full_rg_gnn_earc(
            data_dict, device, random_seed,
            lambda_rule=0.3,
            use_ds_fusion=True,
            enable_rule_selection=True,
            num_synthetic_override=None,
            forced_alpha=None
        )
        return results
    else:
        return run_baseline(method, data_dict, device, random_seed)


def run_main_comparison(datasets=None, methods=None, n_repeats=10, n_folds=5,
                        output_dir='./experiments/results/main_comparison'):
    """
    运行主对比实验

    Args:
        datasets: 数据集列表（None=全部14个）
        methods: 方法列表（None=全部9个）
        n_repeats: 重复次数
        n_folds: 交叉验证折数
        output_dir: 输出目录
    """
    if datasets is None:
        datasets = KEEL_DATASETS
    if methods is None:
        methods = ALL_METHODS

    device, timestamp = setup_experiment_env(output_dir)

    seeds = SEEDS[:n_repeats]
    total_experiments = len(datasets) * len(methods) * n_repeats * n_folds
    total_folds = len(datasets) * n_repeats * n_folds
    current = 0
    current_fold_global = 0
    all_results = []
    n_success = 0
    n_fail = 0

    # ==================== 实验开始横幅 ====================
    print(f"\n{'█'*80}")
    print(f"█{'':^78s}█")
    print(f"█{'实验 4.2: 主对比实验 (Main Comparative Analysis)':^78s}█")
    print(f"█{'':^78s}█")
    print(f"{'█'*80}")
    print(f"\n  ┌─ 实验配置 ─────────────────────────────────────────────┐")
    print(f"  │  数据集:     {len(datasets)} 个 KEEL 基准数据集{' '*25}│")
    print(f"  │  对比方法:   {len(methods)} 种 (含 GNN-EAR){' '*22}│")
    print(f"  │  交叉验证:   {n_folds}-fold × {n_repeats} repeats = {n_repeats * n_folds} runs/method/dataset │")
    print(f"  │  总实验数:   {total_experiments:,} 次单方法评估{' '*22}│")
    print(f"  │  评估指标:   F1-macro, F1-minority, AUC, G-Mean{' '*6}│")
    print(f"  │  计算设备:   {device}{' '*(43-len(device))}│")
    print(f"  │  输出目录:   {output_dir[:40]+'...' if len(output_dir)>40 else output_dir}{' '*(43-min(len(output_dir),40)-(3 if len(output_dir)>40 else 0))}│")
    print(f"  └──────────────────────────────────────────────────────────┘")
    print(f"\n  方法列表:")
    for m in methods:
        tag = METHOD_TAGS.get(m, '       ')
        print(f"    [{tag}] {m}")
    print()

    global_start = time.time()

    # ==================== 数据集级大循环 ====================
    for ds_idx, dataset_name in enumerate(datasets):
        ds_start = time.time()

        print(f"\n{'━'*80}")
        print(f"  📂 数据集 [{ds_idx+1}/{len(datasets)}]: {dataset_name}")
        print(f"{'━'*80}")

        ds_results_count = 0

        for repeat_idx, seed in enumerate(seeds):
            for fold in range(n_folds):
                current_fold_global += 1

                # ---------- 数据加载 ----------
                print(f"\n  ┌─ 第 {repeat_idx+1}/{n_repeats} 轮, 第 {fold+1}/{n_folds} 折 "
                      f"(seed={seed}) "
                      f"[全局折 {current_fold_global}/{total_folds}] ─┐")

                try:
                    data_dict = prepare_data(dataset_name, fold, seed, device)
                except Exception as e:
                    print(f"  │  ❌ 数据加载失败: {e}")
                    print(f"  └─ 跳过此折 {'─'*50}┘")
                    continue

                # 只在首折打印数据集元信息
                if repeat_idx == 0 and fold == 0:
                    print(f"  │  📊 数据概况: {data_dict['n_samples']} 样本, "
                          f"{data_dict['n_features']} 特征, "
                          f"IR={data_dict['imbalance_ratio']:.1f}:1 "
                          f"(少数类 {data_dict['n_minority']}  vs 多数类 {data_dict['n_majority']})")

                print(f"  │  训练/验证/测试: "
                      f"{data_dict['train_mask'].sum().item()}/{data_dict['val_mask'].sum().item()}/{data_dict['test_mask'].sum().item()}")
                print(f"  │")

                # ---------- 逐方法运行 ----------
                fold_best_method = None
                fold_best_f1 = -1.0

                for m_idx, method in enumerate(methods):
                    current += 1
                    tag = METHOD_TAGS.get(method, '       ')

                    # 进度百分比和ETA
                    elapsed_total = time.time() - global_start
                    if current > 1:
                        avg_per_exp = elapsed_total / (current - 1)
                        eta_seconds = avg_per_exp * (total_experiments - current)
                        eta_str = _format_elapsed(eta_seconds)
                    else:
                        eta_str = "计算中..."

                    pct = current / total_experiments * 100
                    progress_bar = '█' * int(pct // 5) + '░' * (20 - int(pct // 5))
                    print(f"  │  [{progress_bar}] {pct:5.1f}%  "
                          f"({current}/{total_experiments})  ETA {eta_str}")

                    method_start = time.time()
                    print(f"  │  {tag} ▶ {method} ...", end='', flush=True)

                    try:
                        result = run_single_method_fold(method, data_dict, device, seed)
                        method_elapsed = time.time() - method_start

                        record = {
                            'dataset': dataset_name,
                            'method': method,
                            'repeat': repeat_idx,
                            'fold': fold,
                            'seed': seed,
                            'imbalance_ratio': data_dict['imbalance_ratio'],
                            'n_samples': data_dict['n_samples'],
                            'n_minority': data_dict['n_minority'],
                            'n_majority': data_dict['n_majority'],
                        }
                        for metric in METRICS:
                            record[metric] = result.get(metric, 0.0)
                        record['accuracy'] = result.get('accuracy', 0.0)

                        # GNN-EAR特有字段
                        if method == 'GNN-EAR':
                            record['best_alpha'] = result.get('best_alpha', 1.0)
                            record['n_rules'] = result.get('n_rules', 0)
                            record['n_rules_stage1'] = result.get('n_rules_stage1', 0)
                            record['n_rules_fusion_raw'] = result.get('n_rules_fusion_raw', 0)
                            record['n_rules_final'] = result.get('n_rules_final', 0)
                            record['n_rules_minority'] = result.get('n_rules_minority', 0)
                            record['n_rules_majority'] = result.get('n_rules_majority', 0)
                            record['rule_selection_status'] = result.get('rule_selection_status', '')
                            record['rule_selection_error'] = result.get('rule_selection_error', '')
                            record['rule_selection_fallback'] = result.get('rule_selection_fallback', 0)
                            record['rule_selection_fallback_reason'] = result.get('rule_selection_fallback_reason', '')
                            record['rule_selection_mode'] = result.get('rule_selection_mode', '')
                            record['rule_selection_target_keep'] = result.get('rule_selection_target_keep', 0)
                            record['rule_selection_target_source'] = result.get('rule_selection_target_source', '')
                            record['rule_counts_stage1_json'] = result.get('rule_counts_stage1_json', '{}')
                            record['rule_counts_fusion_raw_json'] = result.get('rule_counts_fusion_raw_json', '{}')
                            record['rule_counts_final_json'] = result.get('rule_counts_final_json', '{}')
                            record['gnn_f1_macro'] = result.get('gnn_f1_macro', 0.0)
                            record['gnn_f1_minority'] = result.get('gnn_f1_minority', 0.0)
                            for k, v in result.items():
                                if k.startswith('rule_count_stage1_cls_') or k.startswith('rule_count_fusion_raw_cls_') or k.startswith('rule_count_final_cls_'):
                                    record[k] = v

                        all_results.append(record)
                        n_success += 1
                        ds_results_count += 1

                        # 追踪此折最佳
                        if record['f1_macro'] > fold_best_f1:
                            fold_best_f1 = record['f1_macro']
                            fold_best_method = method

                        # 结果输出行
                        f1m = record['f1_macro']
                        f1min = record['f1_minority']
                        auc_val = record['auc']
                        gm = record['gmean']

                        # GNN-EAR 额外显示融合详情
                        extra = ""
                        if method == 'GNN-EAR':
                            alpha = result.get('best_alpha', 1.0)
                            n_rules = result.get('n_rules_final', result.get('n_rules', 0))
                            n_rules_raw = result.get('n_rules_fusion_raw', n_rules)
                            gnn_only = result.get('gnn_f1_macro', 0.0)
                            gain = f1m - gnn_only
                            sign = '+' if gain >= 0 else ''
                            extra = f"  α*={alpha:.2f} rules={n_rules_raw}->{n_rules} 融合增益={sign}{gain:.4f}"

                        print(f" ✓ {_format_elapsed(method_elapsed):>8s}"
                              f"  F1m={f1m:.4f} F1min={f1min:.4f} AUC={auc_val:.4f} GM={gm:.4f}"
                              f"{extra}")

                    except Exception as e:
                        method_elapsed = time.time() - method_start
                        n_fail += 1
                        print(f" ✗ {_format_elapsed(method_elapsed):>8s}  失败: {str(e)[:60]}")
                        traceback.print_exc()
                        continue

                # ---------- 折小结 ----------
                if fold_best_method:
                    print(f"  │")
                    print(f"  │  🏆 本折最佳: {fold_best_method} (F1m={fold_best_f1:.4f})")
                print(f"  └{'─'*58}┘")

                # 实时保存
                if all_results:
                    temp_df = pd.DataFrame(all_results)
                    temp_df.to_csv(os.path.join(output_dir, f'results_temp_{timestamp}.csv'), index=False)

        # ---------- 数据集小结 ----------
        ds_elapsed = time.time() - ds_start
        print(f"\n  📋 {dataset_name} 小结 (耗时 {_format_elapsed(ds_elapsed)})")
        print(f"     完成 {ds_results_count} 次实验")

        if all_results:
            ds_records = [r for r in all_results if r['dataset'] == dataset_name]
            if ds_records:
                ds_df = pd.DataFrame(ds_records)
                print(f"     {'方法':15s}  {'F1-macro':>10s}  {'F1-minority':>12s}  {'AUC':>8s}  {'G-Mean':>8s}")
                print(f"     {'─'*15}  {'─'*10}  {'─'*12}  {'─'*8}  {'─'*8}")
                for method in methods:
                    m_df = ds_df[ds_df['method'] == method]
                    if len(m_df) > 0:
                        f1m_mean = m_df['f1_macro'].mean()
                        f1min_mean = m_df['f1_minority'].mean()
                        auc_mean = m_df['auc'].mean()
                        gm_mean = m_df['gmean'].mean()
                        marker = " ★" if method == 'GNN-EAR' else "  "
                        print(f"    {marker}{method:15s}  {f1m_mean:10.4f}  {f1min_mean:12.4f}  {auc_mean:8.4f}  {gm_mean:8.4f}")

    # ==================== 全局总结 ====================
    total_elapsed = time.time() - global_start
    print(f"\n{'█'*80}")
    print(f"█{'':^78s}█")
    print(f"█{'实验完成！':^76s}█")
    print(f"█{'':^78s}█")
    print(f"{'█'*80}")
    print(f"\n  ⏱  总耗时: {_format_elapsed(total_elapsed)}")
    print(f"  ✓  成功: {n_success}  ✗ 失败: {n_fail}  (共 {n_success + n_fail}/{total_experiments})")

    if not all_results:
        print("\n  ⚠  警告: 没有成功的实验结果")
        return None

    # ===== 保存完整结果 =====
    results_df = save_results_csv(all_results, os.path.join(output_dir, f'complete_results_{timestamp}.csv'))

    # ===== 生成统计摘要 =====
    summary = compute_summary(results_df, group_cols=['dataset', 'method'])
    summary.to_csv(os.path.join(output_dir, f'summary_{timestamp}.csv'), index=False)

    # ===== 打印总体排名 =====
    print(f"\n{'═'*80}")
    print(f"  📊 各方法在全部数据集上的平均表现 (均值 ± 标准差)")
    print(f"{'═'*80}")
    print(f"\n  {'排名':>4s}  {'方法':15s}  {'F1-macro':>14s}  {'F1-minority':>14s}  {'AUC':>14s}  {'G-Mean':>14s}")
    print(f"  {'─'*4}  {'─'*15}  {'─'*14}  {'─'*14}  {'─'*14}  {'─'*14}")

    # 按 F1-macro 均值排序
    method_avg = {}
    for method in methods:
        m_data = results_df[results_df['method'] == method]
        if len(m_data) > 0:
            method_avg[method] = {
                'f1_macro': (m_data['f1_macro'].mean(), m_data['f1_macro'].std()),
                'f1_minority': (m_data['f1_minority'].mean(), m_data['f1_minority'].std()),
                'auc': (m_data['auc'].mean(), m_data['auc'].std()),
                'gmean': (m_data['gmean'].mean(), m_data['gmean'].std()),
            }
    ranked = sorted(method_avg.items(), key=lambda x: x[1]['f1_macro'][0], reverse=True)

    for rank, (method, avgs) in enumerate(ranked, 1):
        marker = "★" if method == 'GNN-EAR' else " "
        f1m = f"{avgs['f1_macro'][0]:.4f}±{avgs['f1_macro'][1]:.4f}"
        f1min = f"{avgs['f1_minority'][0]:.4f}±{avgs['f1_minority'][1]:.4f}"
        auc_s = f"{avgs['auc'][0]:.4f}±{avgs['auc'][1]:.4f}"
        gm_s = f"{avgs['gmean'][0]:.4f}±{avgs['gmean'][1]:.4f}"
        print(f"  {marker}{rank:>3d}  {method:15s}  {f1m:>14s}  {f1min:>14s}  {auc_s:>14s}  {gm_s:>14s}")

    # ===== 逐数据集对比 =====
    print(f"\n{'═'*80}")
    print(f"  📋 各数据集详细对比")
    print(f"{'═'*80}")

    for dataset_name in datasets:
        ds_mask = summary['dataset'] == dataset_name
        ds_summary = summary[ds_mask]
        if len(ds_summary) == 0:
            continue

        # 找该数据集上各指标的最佳方法
        best_per_metric = {}
        for metric in METRICS:
            col = f'{metric}_mean'
            if col in ds_summary.columns:
                best_idx = ds_summary[col].idxmax()
                best_per_metric[metric] = ds_summary.loc[best_idx, 'method']

        print(f"\n  ── {dataset_name} ──")
        for _, row in ds_summary.iterrows():
            method = row['method']
            tag = METHOD_TAGS.get(method, '       ')
            line = f"    {tag} {method:15s}:"
            for metric in METRICS:
                mean_val = row[f'{metric}_mean']
                std_val = row[f'{metric}_std']
                is_best = (best_per_metric.get(metric) == method)
                mark = " ◀" if is_best else "  "
                line += f"  {metric}={mean_val:.4f}±{std_val:.4f}{mark}"
            print(line)

    # ===== 生成LaTeX Table I =====
    latex_table = generate_table_I(summary, methods, datasets)
    latex_path = os.path.join(output_dir, f'table_I_{timestamp}.tex')
    with open(latex_path, 'w', encoding='utf-8') as f:
        f.write(latex_table)

    print(f"\n{'─'*80}")
    print(f"  💾 输出文件:")
    print(f"     完整结果:   {os.path.join(output_dir, f'complete_results_{timestamp}.csv')}")
    print(f"     统计摘要:   {os.path.join(output_dir, f'summary_{timestamp}.csv')}")
    print(f"     LaTeX表格:  {latex_path}")
    print(f"{'─'*80}\n")

    return results_df


def generate_table_I(summary_df, methods, datasets):
    """
    生成Table I: 完整对比结果LaTeX表格
    每个数据集一行，每个方法的4个指标
    最佳结果加粗显示
    """
    latex = r"""\begin{table*}[htbp]
\centering
\caption{Classification performance comparison on 14 KEEL benchmark datasets. The best result for each dataset-metric pair is shown in \textbf{bold}. Results are reported as mean$\pm$std over 10 runs with 5-fold cross-validation.}
\label{tab:main_results}
\resizebox{\textwidth}{!}{%
\begin{tabular}{l""" + "c" * len(methods) + r"""}
\toprule
"""

    # 为每个指标生成一个子表
    for metric in METRICS:
        metric_label = {
            'f1_macro': '$F1_{macro}$',
            'f1_minority': '$F1_{minority}$',
            'auc': 'AUC',
            'gmean': 'G-Mean'
        }.get(metric, metric)

        latex += r"\midrule" + "\n"
        latex += r"\multicolumn{" + str(len(methods) + 1) + r"}{c}{\textbf{" + metric_label + r"}} \\" + "\n"
        latex += r"\midrule" + "\n"

        # 方法名表头
        header = "Dataset"
        for m in methods:
            short_name = m.replace('GNN-EAR', '\\textbf{Ours}')
            header += f" & {short_name}"
        header += r" \\" + "\n"
        latex += header

        for ds in datasets:
            row = f"{ds:15s}"
            # 找每个方法的结果
            values = []
            for method in methods:
                mask = (summary_df['dataset'] == ds) & (summary_df['method'] == method)
                subset = summary_df[mask]
                if len(subset) > 0:
                    mean_val = subset[f'{metric}_mean'].values[0]
                    std_val = subset[f'{metric}_std'].values[0]
                    values.append((mean_val, std_val))
                else:
                    values.append((None, None))

            # 找最佳值
            valid_means = [v[0] for v in values if v[0] is not None]
            best_val = max(valid_means) if valid_means else None

            for mean_val, std_val in values:
                if mean_val is None:
                    row += " & -"
                elif best_val is not None and abs(mean_val - best_val) < 1e-4:
                    row += f" & $\\mathbf{{{mean_val:.3f}}}_{{\\pm{std_val:.3f}}}$"
                else:
                    row += f" & ${mean_val:.3f}_{{\\pm{std_val:.3f}}}$"

            row += r" \\" + "\n"
            latex += row

    latex += r"""\bottomrule
\end{tabular}%
}
\end{table*}
"""
    return latex


def main():
    parser = argparse.ArgumentParser(description='实验4.2: 主对比实验')
    parser.add_argument('--datasets', nargs='+', default=None,
                        help='数据集列表（默认全部14个KEEL数据集）')
    parser.add_argument('--methods', nargs='+', default=None,
                        help='方法列表（默认全部9种方法）')
    parser.add_argument('--n_repeats', type=int, default=5,
                        help='重复次数（默认5）')
    parser.add_argument('--n_folds', type=int, default=5,
                        help='交叉验证折数（默认5）')
    parser.add_argument('--output_dir', type=str,
                        default='./experiments/results/main_comparison',
                        help='输出目录')
    parser.add_argument('--quick', action='store_true',
                        help='快速测试模式（2个数据集, 2次重复, 3折）')

    args = parser.parse_args()

    if args.quick:
        args.datasets = args.datasets or ['ecoli1', 'yeast3']
        args.n_repeats = 2
        args.n_folds = 3

    run_main_comparison(
        datasets=args.datasets,
        methods=args.methods,
        n_repeats=args.n_repeats,
        n_folds=args.n_folds,
        output_dir=args.output_dir
    )


if __name__ == "__main__":
    main()

