"""
配置模块
包含系统所有超参数和配置选项
"""

from .config import Config

__all__ = ['Config']

