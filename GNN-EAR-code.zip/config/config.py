"""
配置文件
包含GNN-EAR系统的所有超参数和配置选项
"""

class Config:
    """系统配置类"""

    # ==================== 数据集配置 ====================
    DATASET_NAME = 'ecoli1'  # 数据集名称: 'ecoli1', 'wine', 'segment0', 'custom'
    DATA_PATH = './datas/'  # 数据路径
    IMBALANCE_RATIO = 0.1  # 不平衡比例（少数类占比）

    # ==================== 图构建配置 ====================
    KNN_K = 5  # k-NN构图的k值
    GRAPH_METRIC = 'cosine'  # 图构建的距离度量: 'cosine', 'euclidean'

    # ==================== EARC规则挖掘配置 ====================
    # 模糊化参数
    NUM_FUZZY_SETS = 3  # 每个特征的模糊集数量 (Low, Medium, High)
    FUZZY_TYPE = 'triangular'  # 模糊隶属函数类型: 'triangular', 'gaussian'

    # Apriori算法参数
    MIN_SUPPORT = 0.005  # 最小支持度（降低以获得更多规则）
    MIN_CONFIDENCE = 0.35  # 最小置信度（平衡质量和数量）
    MAX_RULE_LENGTH = 3  # 最大规则长度

    # 规则筛选参数
    RULE_PRUNING_THRESHOLD = 0.9  # 规则剪枝阈值
    TOP_K_RULES = 50  # 保留的最优规则数量

    # 双向规则挖掘（同时学习多数类和少数类规则）
    BIDIRECTIONAL_RULES = True  # 是否启用双向规则挖掘

    # ==================== 规则自动选择优化配置 ====================
    ENABLE_RULE_SELECTION = True  # 是否启用异构图神经网络规则自动选择
    RULE_SELECTION_MODE = 'adaptive'  # 规则筛选模式: 'adaptive'|'fixed'|'hybrid'
    RULE_SELECTION_TARGET_SPARSITY = 0.5  # fixed/hybrid 模式下的兼容参数
    RULE_SELECTION_EPOCHS = 100  # 规则选择优化的训练轮数
    RULE_SELECTION_HIDDEN_DIM = 64  # 规则选择GNN的隐藏层维度
    RULE_SELECTION_SPARSITY_WEIGHT = 0.1  # 稀疏性正则化权重

    # ==================== GNN编码器配置 ====================
    GNN_TYPE = 'GCN'  # GNN类型: 'GCN', 'GAT', 'GraphSAGE'
    HIDDEN_DIM = 128  # 隐藏层维度
    EMBEDDING_DIM = 64  # 嵌入空间维度
    NUM_GNN_LAYERS = 2  # GNN层数
    DROPOUT = 0.5  # Dropout率

    # GAT特定参数
    NUM_HEADS = 4  # 注意力头数（仅用于GAT）

    # ==================== GraphSMOTE配置 ====================
    SMOTE_K = 5  # SMOTE的k近邻数
    SMOTE_RATIO = 1.0  # 过采样比例（1.0=完全平衡，实验证明效果最好）
    INTERPOLATION_METHOD = 'linear'  # 插值方法: 'linear', 'gaussian'

    # ==================== 解码器配置 ====================
    DECODER_HIDDEN_DIM = 128  # 解码器隐藏层维度
    DECODER_NUM_LAYERS = 2  # 解码器层数

    # ==================== 损失函数配置 ====================
    LAMBDA_CLASS = 1.0  # 分类损失权重
    LAMBDA_RECON = 0.5  # 重构损失权重
    LAMBDA_RULE = 0.3  # 规则一致性损失权重
    LAMBDA_EDGE = 0.2  # 边预测损失权重

    # ==================== 训练配置 ====================
    LEARNING_RATE = 0.001  # 学习率
    WEIGHT_DECAY = 5e-4  # 权重衰减
    NUM_EPOCHS = 200  # 训练轮数
    BATCH_SIZE = 32  # 批大小
    PATIENCE = 20  # 早停耐心值

    # ==================== 证据理论融合配置 ====================
    ALPHA = 0.3  # GNN与EARC融合的权重参数（GNN权重，规则权重为1-ALPHA）
    USE_DS_FUSION = True  # 是否使用Dempster-Shafer证据融合

    # ==================== 实验配置 ====================
    RANDOM_SEED = 42  # 随机种子
    NUM_SPLITS = 5  # 交叉验证折数
    TEST_RATIO = 0.2  # 测试集比例
    VAL_RATIO = 0.1  # 验证集比例

    # ==================== 输出配置 ====================
    SAVE_MODEL = True  # 是否保存模型
    MODEL_SAVE_PATH = './checkpoints/'  # 模型保存路径
    RESULT_SAVE_PATH = './results/'  # 结果保存路径
    LOG_INTERVAL = 10  # 日志打印间隔
    VERBOSE = True  # 是否输出详细信息

    # ==================== 可视化配置 ====================
    VISUALIZE = True  # 是否可视化
    TSNE_PERPLEXITY = 30  # t-SNE困惑度
    FIG_SIZE = (10, 8)  # 图像大小

    # ==================== 设备配置 ====================
    DEVICE = 'cuda'  # 计算设备: 'cuda', 'cpu'

    @classmethod
    def print_config(cls):
        """打印当前配置"""
        print("=" * 60)
        print("GNN-EAR 系统配置")
        print("=" * 60)
        for key, value in cls.__dict__.items():
            if not key.startswith('_') and not callable(value):
                print(f"{key}: {value}")
        print("=" * 60)